/* Daisy workbench, Processes tab: a clickable map of the processes of the Daisy model (after Fig. 1 of the Daisy paper): water on the surface, in the soil matrix,
   biopores and drains, heat and ice, nitrogen and carbon pools, photosynthesis and crop growth. Click a box to read what Daisy does there and to draw the figures
   of that process from the logs of your own run (a scenario, an experiment, a run with all process logs, or logs loaded in the Files tab). */
'use strict';
(() => {
  const D = DaisyUI, IO = window.DaisyIO, esc = D.esc, K = () => D.kit;
  const st = { sel: 'water', src: null };
  // colours of the groups, a spectral set
  const GC = { drive: '#5e4fa2', water: '#3288bd', heat: '#66c2a5', nitrogen: '#e6c200', carbon: '#f46d43', crop: '#4d9221' };
  const GN = { drive: 'Drivers', water: 'Water', heat: 'Heat', nitrogen: 'Nitrogen', carbon: 'Carbon and organic matter', crop: 'Crop' };
  // heat: depth-time map of the first depth variable of a log; line: columns against time
  const P = [
    { id: 'bio', g: 'drive', n: 'Weather and bioclimate', x: 20, y: 20, w: 190, h: 56, d: 'Daisy reads daily or hourly weather (air temperature, global radiation, precipitation, reference evapotranspiration and, if available, wind and vapour pressure) and the Bioclimate module splits the energy and water between canopy, litter, snow, pond and soil. The potential evapotranspiration is shared out by the cover of each layer.', par: 'Bioclimate FAO56_daily | default, weather file, snow, canopy, litter, pond',
      figs: [{ log: 'Daily-Bioclimate', t: 'Air temperature', c: ['daily_air_temperature'] }, { log: 'Daily-Bioclimate', t: 'Rain, potential and actual evapotranspiration', c: ['rain', 'total_ep', 'total_ea'] }, { log: 'Daily-Bioclimate', t: 'Irrigation reaching the canopy and the soil surface', c: ['irrigation_overhead', 'irrigation_surface'] }] },
    { id: 'snow', g: 'water', n: 'Snowpack', x: 20, y: 100, w: 190, h: 50, d: 'Precipitation falls as snow below the threshold temperature and builds a snowpack that holds liquid water, ages, compacts and melts; melt water percolates and, when the soil below is frozen, can run off or pond.', par: 'Snow | the snow depth, content, liquid water content, evaporation and percolation',
      figs: [{ log: 'Daily-Snow', t: 'Snowpack content and liquid water', c: ['Snowpack content', 'Snowpack liquid water content'] }, { log: 'Daily-Snow', t: 'Snow depth', c: ['Snow Depth'] }, { log: 'Daily-Snow', t: 'Evaporation from and percolation through the snowpack', c: ['Evaporation from snowpack', 'Percolation from snowpack'] }] },
    { id: 'surf', g: 'water', n: 'Canopy, litter and ponded water', x: 20, y: 174, w: 190, h: 56, d: 'Rain and irrigation are intercepted by the canopy and the litter layer and evaporate from them; what passes goes to the surface pond. The pond infiltrates into the matrix, the biopores (tertiary infiltration) or runs off. Tillage resets the surface.', par: 'Bioclimate and SurfaceWater | canopy and litter capacity, pond, infiltration, runoff',
      figs: [{ log: 'Daily-SurfaceWater', t: 'Precipitation and irrigation', c: ['Precipitation', 'Overhead irrigation', 'Surface irrigation'] }, { log: 'Daily-SurfaceWater', t: 'Water held in the canopy, litter and pond', c: ['Canopy', 'Litter', 'Pond'] }, { log: 'Daily-SurfaceWater', t: 'Infiltration and runoff', c: ['Matrix infiltration', 'Tertiary infiltration', 'Runoff'] }, { log: 'Daily-SurfaceWater', t: 'Evaporation from the layers', c: ['Canopy evaporation', 'Litter evaporation', 'Pond evaporation', 'Soil evaporation'] }] },
    { id: 'water', g: 'water', n: 'Soil water (Richards equation)', x: 250, y: 20, w: 200, h: 56, d: 'Water in the matrix moves by the one-dimensional Richards equation, with hydraulic properties from the horizons (retention curve and conductivity). Root uptake is the sink and evaporation the surface boundary; the bottom boundary can be free drainage, a groundwater table or a lysimeter.', par: 'Groundwater | Richards equation, Horizon hydraulic, bottom boundary',
      figs: [{ log: 'Daily-Theta', t: 'Water content over depth and time', heat: 1 }, { log: 'Daily-pF', t: 'Soil water suction (pF) over depth and time', heat: 1 }, { log: 'Daily-MatrixFlux', t: 'Water flux in the matrix over depth and time', heat: 1 }] },
    { id: 'pore', g: 'water', n: 'Biopores (preferential flow)', x: 250, y: 100, w: 200, h: 50, d: 'Part of the water and solutes moves through biopores that bypass the matrix, filled from the surface pond and exchanging with the matrix along the way. This is the source of fast leaching of nitrate and pesticide.', par: 'Biopore matrix | the flux in the pores and the exchange with the matrix',
      figs: [{ log: 'Daily-BioporeFlux', t: 'Water flux in the biopores over depth and time', heat: 1 }] },
    { id: 'drain', g: 'water', n: 'Drains and groundwater', x: 250, y: 174, w: 200, h: 56, d: 'Tile drains are a sink in the layers at the drain depth, when the soil there is saturated; drained water takes nitrate with it. A groundwater table or a lysimeter bottom boundary closes the water balance at the bottom.', par: 'Drain | the drain depth, spacing and the sink in each layer',
      figs: [{ log: 'Daily-DrainSink', t: 'Sink of the drains over depth and time', heat: 1 }] },
    { id: 'temp', g: 'heat', n: 'Soil heat and ice', x: 490, y: 20, w: 190, h: 56, d: 'Heat moves by conduction and with the water flux; the surface boundary comes from the energy balance of the bioclimate. When the temperature falls below the freezing point part of the water turns to ice, which blocks the flow and releases latent heat.', par: 'Soil heat | thermal conductivity and capacity, freezing, ice content',
      figs: [{ log: 'Daily-SoilTemp', t: 'Soil temperature over depth and time', heat: 1 }, { log: 'Daily-SoilIce', t: 'Ice content over depth and time', heat: 1 }] },
    { id: 'no3', g: 'nitrogen', n: 'Nitrate (solute transport)', x: 490, y: 100, w: 190, h: 50, d: 'Nitrate moves with the water by convection and dispersion and is taken up by roots; it is produced by nitrification and lost by denitrification, drains and leaching below the root zone.', par: 'Solute | nitrate in the soil solution, uptake, leaching',
      figs: [{ log: 'Daily-SNO3', t: 'Nitrate over depth and time', heat: 1 }, { log: 'Annual-FN', t: 'Annual nitrogen fluxes', annual: 1 }] },
    { id: 'nh4', g: 'nitrogen', n: 'Ammonium (sorbed and dissolved)', x: 490, y: 174, w: 190, h: 56, d: 'Ammonium comes from mineralisation and fertiliser; it is sorbed on the soil, nitrified to nitrate (the rate depends on the temperature, the water content and the pH) and taken up by plants.', par: 'Nitrification | sorption, the nitrification rate, plant uptake',
      figs: [{ log: 'Daily-NH4', t: 'Ammonium over depth and time', heat: 1 }] },
    { id: 'om', g: 'carbon', n: 'Organic matter pools (AOM, SMB, SOM)', x: 20, y: 290, w: 270, h: 70, d: 'Added organic matter (AOM1-3: crop residues, roots, manure) is decomposed by the soil microbial biomass (SMB1-2), which builds soil organic matter (SOM1-3) from slow to inert; each pool has a carbon and a nitrogen content with its own turnover and efficiency, and the C:N ratio decides whether nitrogen is mineralised or immobilised.', par: 'OrganicMatter | the pools, their turnover rates, efficiency and C:N ratios',
      figs: [{ log: 'Daily-OM', t: 'Carbon in SOM pools', c: ['SOM1-C', 'SOM2-C', 'SOM3-C'] }, { log: 'Daily-OM', t: 'Carbon in the microbial biomass', c: ['SMB1-C', 'SMB2-C'] }, { log: 'Daily-OM', t: 'Carbon in added organic matter', c: ['AOM1-C', 'AOM2-C', 'AOM3-C'] }, { log: 'Daily-OM', t: 'Nitrogen in the pools', c: ['SOM1-N', 'SOM2-N', 'SOM3-N', 'SMB1-N', 'SMB2-N', 'AOM1-N', 'AOM2-N', 'AOM3-N'] }] },
    { id: 'carbon', g: 'carbon', n: 'Carbon balance and residues', x: 330, y: 290, w: 220, h: 70, d: 'Carbon enters with the crop residues (shoot, root and stubble), fertiliser and manure and leaves as CO2 from the microbial pools and the plants; the balance shows how the soil carbon changes with the rotation and tillage.', par: 'Carbon balance | soil carbon, residues, respiration and the net change',
      figs: [{ log: 'Daily-CarbonBalance', t: 'Soil carbon', c: ['Soil_C'] }, { log: 'Daily-CarbonBalance', t: 'Carbon in SOM, microbes and added organic matter', c: ['SOM_C', 'SMB_C', 'AOM_C'] }, { log: 'Daily-CarbonBalance', t: 'Carbon in the crop organs', c: ['CLeaf', 'CStem', 'CSOrg', 'CRoot', 'CDead'] }, { log: 'Daily-CarbonBalance', t: 'Residues returned to the soil', c: ['Residuals_C_top', 'Residuals_C_root', 'Residuals_C_soil'] }] },
    { id: 'deni', g: 'nitrogen', n: 'Denitrification and N2O', x: 715, y: 100, w: 165, h: 56, d: 'In wet, carbon-rich soil nitrate is reduced to N2 and N2O; the rate follows the CO2 production, the water content and the temperature, with a potential rate and a redox part, and N2O also comes from nitrification.', par: 'Denitrification | potential rate, water and temperature factors, N2O fraction',
      figs: [{ log: 'Daily-Denitrification', t: 'Denitrification, actual and potential', c: ['Denitrification', 'Potential denitrification'] }, { log: 'Daily-Denitrification', t: 'CO2 production', c: ['CO2 production', 'CO2 production from fast pools'] }, { log: 'Daily-Denitrification', t: 'N2O from nitrification', c: ['N2O from Nitrification'] }] },
    { id: 'photo', g: 'crop', n: 'Photosynthesis and respiration', x: 20, y: 400, w: 240, h: 60, d: 'Canopy assimilation comes from the leaf area, the light, the temperature and the water and nitrogen stress; assimilate fills the pool, from which maintenance and growth respiration are paid and the rest is partitioned to the organs.', par: 'Crop | canopy assimilation, respiration, assimilate pool',
      figs: [{ log: 'Daily-Photosynthesis', t: 'Canopy assimilation and net photosynthesis', c: ['CanopyAss', 'PotCanopyAss', 'NetPhotosynthesis'] }, { log: 'Daily-Photosynthesis', t: 'Respiration of the roots and CO2 from the soil', c: ['RootRespiration', 'OM_CO2'] }, { log: 'Daily-CarbonBalance', t: 'Growth and maintenance respiration', c: ['GrowthRespiration', 'MaintRespiration'] }] },
    { id: 'crop', g: 'crop', n: 'Crop growth: leaf, stem, root, storage organ', x: 300, y: 400, w: 300, h: 60, d: 'The crop develops with the development stage (DS), leaf area index (LAI), height and rooting depth; dry matter and nitrogen are partitioned to leaf, stem, storage organ and root, under water and nitrogen stress; at harvest the storage organ leaves the field and the rest becomes residue.', par: 'Crop | development, partitioning, stress, root depth, harvest',
      figs: [{ log: 'Daily-CropProduction', t: 'Leaf area index', c: ['LAI'] }, { log: 'Daily-CropProduction', t: 'Crop height and rooting depth', c: ['Height', 'Depth'] }, { log: 'Daily-CropProduction', t: 'Dry matter of the organs', c: ['WLeaf', 'WStem', 'WSOrg', 'WRoot', 'WDead'] }, { log: 'Daily-CropProduction', t: 'Nitrogen in the organs', c: ['NLeaf', 'NStem', 'NSOrg', 'NRoot', 'NDead'] }, { log: 'Daily-CropProduction', t: 'Water and nitrogen stress (1 is no stress)', c: ['water_stress', 'nitrogen_stress'] }] }
  ];
  const byId = id => P.find(p => p.id === id);
  // Fig. 1 of the Daisy paper redrawn element by element: boxes are storages, solid lines flows, dashed lines flows out of the system, dotted lines information.
  // Blue is water, green and brown carbon, beige nitrogen. Boxes with a process id open that process; coordinates follow the figure.
  const BL = '#a8c4e0', LB = '#c4d8ee', GR = '#8cc35a', BE = '#e6dec6', LG = '#c9e08c', BR = '#c8861c', PG = '#b9e3a3';
  // opt: { marks: { F:{proc:[factor ids]}, R:{proc:[response ids]}, factors:[{id,ps}], resp:[ids] }, names:{id:text}, sel:proc|null, extra:true }
  function svg(opt) {
    opt = opt || {};
    const o = [], T = (x, y, t, a, sz, c, w, rot) => o.push('<text x="' + x + '" y="' + y + '" text-anchor="' + (a || 'middle') + '" font-size="' + (sz || 9.5) + '" fill="' + (c || '#111') + '"' + (w ? ' font-weight="' + w + '"' : '') + (rot ? ' transform="rotate(' + rot + ' ' + x + ' ' + y + ')"' : '') + ' font-family="Cambria,Georgia,serif" stroke="#fff" stroke-width="2.6" paint-order="stroke" stroke-linejoin="round" style="pointer-events:none">' + esc(t) + '</text>');
    const L = (pts, k) => { const dash = k === 'out' ? ' stroke-dasharray="5 3"' : k === 'info' ? ' stroke-dasharray="1.5 2.5"' : k === 'mod' ? ' stroke-dasharray="6 3 1.5 3"' : ''; o.push('<polyline points="' + pts.map(q => q.join(',')).join(' ') + '" fill="none" stroke="' + (k === 'blue' ? '#3b6fa5' : '#222') + '" stroke-width="' + (k === 'blue' ? 2.2 : 1.1) + '"' + dash + (k === 'none' ? '' : ' marker-end="url(#dzAr)"') + '/>'); };
    const sel = id => opt.sel === null ? false : id === (opt.sel || st.sel), pos = {};
    const box = (id, x, y, w, h, t, f, extra) => { extra = extra || {}; const fade = opt.emph && id && opt.emph.indexOf(id) < 0; if (fade) o.push('<g opacity="0.38">'); if (id) (pos[id] = pos[id] || []).push([x, y, w, h]); o.push('<g class="dzPb" data-p="' + (id || '') + '"' + (id ? ' style="cursor:pointer" tabindex="0" role="button" aria-label="' + esc(t) + '"' : '') + '><rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + (extra.rx == null ? 3 : extra.rx) + '" fill="' + f + '" stroke="' + (sel(id) ? '#d7191c' : '#555') + '" stroke-width="' + (sel(id) ? 2.6 : 0.8) + '"' + (extra.dash ? ' stroke-dasharray="4 3"' : '') + '/>' + (extra.half ? '<rect x="' + (x + w / 2) + '" y="' + y + '" width="' + w / 2 + '" height="' + h + '" rx="3" fill="' + extra.half + '"/><rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="3" fill="none" stroke="' + (sel(id) ? '#d7191c' : '#555') + '" stroke-width="' + (sel(id) ? 2.6 : 0.8) + '"/>' : '') + '</g>'); if (t) T(x + w / 2, y + h / 2 + 3.5, t, 'middle', extra.sz || 10, '#111', 600); if (fade) o.push('</g>'); };
    o.push('<defs><marker id="dzAr" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#222"/></marker><pattern id="dzDot" width="5" height="5" patternUnits="userSpaceOnUse"><rect width="5" height="5" fill="#e3edf8"/><circle cx="1.5" cy="1.5" r=".7" fill="#9db8d6"/><circle cx="4" cy="4" r=".7" fill="#9db8d6"/></pattern><pattern id="dzHat" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="6" height="6" fill="#fff"/><line x1="0" y1="0" x2="0" y2="6" stroke="#6a8fb8" stroke-width="2"/></pattern></defs>');
    // the ground and the bottom of the profile
    o.push('<line x1="150" y1="352" x2="900" y2="352" stroke="#c9a46a" stroke-width="1.2" stroke-dasharray="2 2"/><rect x="150" y="640" width="750" height="9" fill="url(#dzHat)"/>');
    // driving variables
    box('bio', 628, 30, 224, 32, '', '#fff', { dash: 1, rx: 6 }); T(740, 43, 'Driving variables', 'middle', 9.5); T(672, 56, 'Precipitation & Irrigation', 'middle', 9, '#111', 600); T(765, 56, 'Temperature', 'middle', 9, '#111', 600); T(820, 56, 'Light', 'middle', 9, '#111', 600);
    L([[628, 46], [300, 46], [300, 62]], 'none'); o.push('<circle cx="300" cy="67" r="5" fill="#7ea6d2" stroke="#333"/>'); T(262, 50, 'Snowfall', 'middle', 9); T(340, 50, 'Rainfall', 'middle', 9);
    L([[296, 70], [232, 70], [232, 120]]); L([[304, 70], [388, 70], [388, 120]]);
    // snow and intercepted water
    box('snow', 186, 122, 92, 26, 'Snowpack', BL); box('surf', 328, 122, 120, 26, 'Intercepted water', BL);
    L([[205, 120], [205, 82]], 'out'); T(178, 78, 'Evaporation', 'middle', 9); L([[418, 120], [418, 82]], 'out'); T(446, 86, 'Evaporation', 'middle', 9);
    L([[232, 148], [232, 298]]); T(190, 195, 'Percolation', 'middle', 9); L([[330, 135], [268, 135], [268, 298]]); T(300, 168, 'Throughfall', 'middle', 9); L([[388, 148], [388, 262], [290, 262], [290, 298]]); T(358, 222, 'Drip off', 'middle', 9); L([[216, 298], [216, 232]], 'out'); T(168, 236, 'Evaporation', 'middle', 9);
    // litter, pond and soil
    box('surf', 198, 300, 98, 13, 'Litter water', LB, { sz: 8.5 }); box('surf', 170, 334, 84, 13, 'Ponded water', LB, { sz: 8.5 }); L([[186, 334], [186, 288]], 'out'); T(142, 272, 'Evaporation', 'middle', 9);
    L([[225, 313], [225, 334]]); T(250, 326, 'Percolation', 'start', 9); L([[170, 340], [132, 340]], 'out'); T(116, 335, 'Runoff', 'middle', 9); L([[212, 347], [212, 368]]); T(166, 361, 'Infiltration', 'middle', 9);
    box('water', 168, 368, 104, 260, '', 'url(#dzDot)', { rx: 2 }); T(220, 408, 'Soil water', 'middle', 10, '#111', 700); T(220, 421, '(Richards Eq.)', 'middle', 9.5); T(220, 446, 'Solute transport', 'middle', 10, '#111', 700); T(220, 459, '(Advection-dispersion Eq.)', 'middle', 8.5);
    L([[262, 368], [262, 348]], 'out'); T(256, 362, 'Soil Evaporation', 'start', 8.5);
    box('pore', 284, 318, 5, 262, '', '#6fa0d0', { rx: 1 }); box('pore', 296, 318, 5, 262, '', '#6fa0d0', { rx: 1 }); T(312, 346, 'Biopore', 'start', 9); T(312, 357, 'flow', 'start', 9);
    o.push('<g class="dzPb" data-p="drain" style="cursor:pointer" tabindex="0" role="button" aria-label="Drain"><circle cx="268" cy="520" r="14" fill="' + BL + '" stroke="' + (sel('drain') ? '#d7191c' : '#555') + '" stroke-width="' + (sel('drain') ? 2.6 : 0.8) + '"/></g>'); T(268, 523, 'Drain', 'middle', 9.5, '#111', 600);
    L([[184, 642], [184, 628]]); T(116, 606, 'Capillary rise', 'middle', 9); L([[250, 628], [250, 642]], 'out'); T(238, 620, 'Percolation', 'end', 9);
    // nitrogen
    box('no3', 372, 420, 40, 26, 'NO₃⁻', BE); box('nh4', 344, 478, 60, 26, 'NH₄⁺', BE); box('nh4', 332, 516, 52, 26, 'NH₄⁺ sorbed', BE, { sz: 8 }); box('crop', 444, 342, 60, 26, 'Plant-N', BE); box('carbon', 592, 436, 60, 26, 'Org-N', BE);
    L([[372, 300], [372, 420]], 'none'); L([[376, 300], [376, 340]]); T(335, 288, 'Fertilization+', 'middle', 9); T(335, 299, 'Atm. Deposition', 'middle', 9); L([[340, 478], [340, 300]], 'out'); T(318, 262, 'Volatilization', 'middle', 9);
    L([[392, 420], [392, 392]], 'out'); T(364, 376, 'N₂O', 'middle', 9); L([[352, 400], [352, 380]], 'out'); T(336, 390, 'N₂O', 'middle', 9); L([[396, 420], [396, 370]]); T(392, 366, 'Denitri-', 'middle', 8.5); T(392, 376, 'fication', 'middle', 8.5);
    L([[388, 478], [388, 446]]); T(403, 464, 'Nitrification', 'start', 9); L([[413, 429], [443, 362]]); T(418, 396, 'Uptake', 'start', 9); L([[404, 484], [444, 366]], 'none');
    L([[592, 444], [413, 436]]); T(520, 450, 'Immobilization', 'middle', 9); L([[592, 462], [404, 490]]); T(500, 484, 'Mineralization', 'middle', 9); L([[384, 505], [384, 520]], 'none'); L([[388, 504], [388, 642]], 'out'); T(396, 560, 'Leaching', 'start', 9);
    L([[268, 534], [268, 548]], 'none'); L([[374, 520], [286, 520]], 'none');
    // plant
    L([[460, 342], [460, 258]]); L([[475, 342], [475, 200]]); L([[490, 342], [490, 116]]); L([[474, 368], [474, 398]]); T(482, 290, 'Harvest', 'middle', 9); L([[470, 284], [470, 250]], 'out'); T(432, 318, 'Symbiotic', 'start', 9); T(432, 328, 'Fixation', 'start', 9);
    box('crop', 444, 88, 60, 26, 'Storage Organ', LG, { half: BE, sz: 8.5 }); box('crop', 444, 172, 60, 26, 'Leaf', LG, { half: BE }); box('crop', 444, 232, 60, 26, 'Stem', LG, { half: BE }); box('crop', 444, 398, 60, 26, 'Root', LG, { half: BE });
    L([[458, 88], [458, 46]], 'out'); T(440, 40, 'Transpiration', 'middle', 9); L([[490, 88], [490, 46]], 'out'); T(497, 40, 'Harvest', 'middle', 9); L([[528, 88], [528, 70]], 'out'); T(528, 64, 'CO₂', 'middle', 9);
    box('photo', 548, 100, 24, 190, '', PG, { rx: 3 }); T(560, 195, 'Partitioning', 'middle', 10, '#111', 600, -90);
    L([[548, 108], [504, 101]]); L([[548, 190], [504, 186]]); L([[548, 250], [504, 246]]); L([[548, 288], [548, 298], [511, 298], [511, 408], [504, 408]]);
    box('photo', 590, 124, 100, 28, '', PG); T(640, 135, 'Maintenance', 'middle', 8.5, '#111', 600); T(640, 146, 'Respiration', 'middle', 8.5, '#111', 600); box('photo', 588, 186, 98, 24, 'Assimilate Pool', PG); box('photo', 712, 186, 92, 24, 'Photosynthesis', PG);
    L([[712, 198], [686, 198]]); L([[588, 198], [572, 198]]); L([[636, 186], [636, 154]]); L([[640, 128], [640, 100]], 'out'); T(640, 94, 'CO₂', 'middle', 9); L([[528, 150], [528, 130]], 'out'); T(528, 124, 'CO₂', 'middle', 9); L([[528, 232], [528, 212]], 'out'); T(528, 206, 'CO₂', 'middle', 9);
    L([[724, 62], [724, 186]], 'info'); T(716, 80, 'CO₂', 'end', 9); L([[770, 62], [770, 186]], 'info'); L([[816, 62], [796, 186]], 'info');
    box('photo', 842, 144, 76, 30, 'Canopy Structure', PG, { sz: 8, rx: 10 }); box('photo', 842, 186, 76, 30, 'Stress Factors', PG, { sz: 8, rx: 10 }); box('photo', 842, 228, 76, 30, 'Senescence', PG, { sz: 8, rx: 10 });
    L([[842, 160], [804, 190]], 'info'); L([[842, 201], [804, 199]], 'info'); L([[842, 243], [804, 208]], 'info');
    // residues
    box('carbon', 518, 342, 60, 26, 'Shoot Residues', LG, { sz: 8 }); box('carbon', 518, 408, 60, 26, 'Root Residues', LG, { sz: 8 });
    L([[504, 210], [530, 210], [530, 340]], 'none'); L([[504, 420], [518, 420]]); L([[578, 355], [614, 355], [614, 434]]); L([[578, 421], [610, 421], [610, 434]]); T(588, 392, 'Residuals +', 'middle', 8.5); T(588, 402, 'Rhizodeposition', 'middle', 8.5);
    // organic matter
    T(640, 296, 'Fertilization', 'middle', 9); T(640, 307, '(Org. Matter)', 'middle', 9); L([[650, 312], [716, 354]]); L([[650, 312], [830, 354]]); L([[650, 312], [650, 436]], 'none'); T(740, 322, 'Structural', 'middle', 9); T(740, 333, 'Organic input', 'middle', 9); T(850, 322, 'Metabolic', 'middle', 9); T(850, 333, 'Organic input', 'middle', 9); T(900, 346, 'Recalcitrant', 'middle', 9);
    box('om', 680, 357, 88, 26, 'AOM1', BR, { half: BE }); box('om', 790, 357, 88, 26, 'AOM1', BR, { half: BE }); box('om', 672, 440, 74, 24, 'SMB1', BR, { half: BE }); box('om', 774, 440, 74, 24, 'SMB2', BR, { half: BE }); box('om', 664, 492, 90, 46, 'SOM1', BR, { half: BE }); box('om', 774, 492, 90, 46, 'SOM2', BR, { half: BE }); box('om', 808, 552, 92, 28, 'SOM3 (inert)', BR, { half: BE, sz: 9 });
    L([[724, 383], [724, 440]]); L([[834, 383], [834, 440]]); L([[724, 383], [724, 410], [810, 410], [810, 440]]); L([[746, 452], [774, 452]]); L([[709, 464], [709, 492]]); L([[811, 464], [811, 492]]); L([[754, 515], [774, 515]]); L([[754, 505], [774, 505]]); L([[818, 538], [818, 552]]); L([[672, 452], [652, 452]]); L([[864, 452], [888, 452], [888, 520], [864, 520]], 'none');
    L([[690, 357], [690, 330]], 'out'); T(690, 324, 'CO₂', 'middle', 9); L([[792, 440], [792, 400]], 'out'); L([[760, 440], [760, 405]], 'out'); T(660, 480, 'CO₂', 'middle', 9); L([[690, 492], [690, 470]], 'out'); T(790, 485, 'CO₂', 'middle', 9); T(790, 304, 'CO₂', 'middle', 9); L([[790, 332], [790, 312]], 'out');
    // legend
    const lg = [['none', 'Inputs and movement of matter within modules.'], ['out', 'Outputs of matter.'], ['info', 'Exchange of information within modules.'], ['none2', 'Movement of matter between modules.'], ['mod', 'Exchange of information between modules.']];
    lg.forEach((l, i) => { const y = 590 + i * 11; o.push('<line x1="640" y1="' + y + '" x2="676" y2="' + y + '" stroke="#222" stroke-width="' + (l[0] === 'none2' ? 2 : 1) + '"' + (l[0] === 'out' ? ' stroke-dasharray="5 3"' : l[0] === 'info' ? ' stroke-dasharray="1.5 2.5"' : l[0] === 'mod' ? ' stroke-dasharray="6 3 1.5 3"' : '') + '/>'); T(682, y + 3, l[1], 'start', 8.5); }); T(640, 650, '(Not all flow of matter and information between modules are shown)', 'start', 8, '#444');
    // the processes of Daisy that Fig. 1 has no box for, so that none is hidden: they can be clicked and marked like the others
    box('temp', 108, 658, 210, 24, 'Soil heat and ice', LG, { sz: 9.5 }); box('deni', 330, 658, 230, 24, 'Denitrification and N2O', BE, { sz: 9.5 }); T(572, 674, 'also in Daisy, not a box of the map', 'start', 9, '#444');
    // what the experiment changes (orange) and what it measures (blue), drawn on the same map; arrows run from the changed process to the measured one
    let extraH = 0;
    if (opt.marks) {
      const M = opt.marks, nm = opt.names || {}, ctr = id => { const r = (pos[id] || [])[0]; return r ? [r[0] + r[2] / 2, r[1] + r[3] / 2] : null; }, top = [];
      const ring = (id, col, grow) => (pos[id] || []).forEach(r => o.push('<rect x="' + (r[0] - grow) + '" y="' + (r[1] - grow) + '" width="' + (r[2] + 2 * grow) + '" height="' + (r[3] + 2 * grow) + '" rx="5" fill="' + (col === '#e8710a' ? 'rgba(232,113,10,0.13)' : 'rgba(0,114,178,0.13)') + '" stroke="' + col + '" stroke-width="2.6" style="pointer-events:none"/>'));
      Object.keys(M.R || {}).forEach(id => ring(id, '#0072b2', 4)); Object.keys(M.F || {}).forEach(id => ring(id, '#e8710a', 2));
      o.push('<defs><marker id="dzAo" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#e8710a"/></marker></defs>');
      let na = 0; Object.keys(M.F || {}).forEach(a => Object.keys(M.R || {}).forEach(b => { const p = ctr(a), q = ctr(b); if (!p || !q || a === b || na > 5) return; na++; const mx = (p[0] + q[0]) / 2 + (q[1] - p[1]) * 0.18, my = (p[1] + q[1]) / 2 - (q[0] - p[0]) * 0.18; o.push('<path d="M' + p[0] + ',' + p[1] + ' Q' + mx + ',' + my + ' ' + q[0] + ',' + q[1] + '" fill="none" stroke="#e8710a" stroke-width="1.4" stroke-dasharray="7 4" marker-end="url(#dzAo)" opacity="0.55" style="pointer-events:none"/>'); }));
      const used = {}, badge = (id, col, txt) => { const r = (pos[id] || [])[0]; if (!r) return; const w = Math.max(16, txt.length * 5.6 + 9), off = used[id] || 0; used[id] = off + w + 2; const x = r[0] + r[2] - w + 4 - off, y = r[1] - 9; o.push('<g style="pointer-events:none"><rect x="' + x + '" y="' + y + '" width="' + w + '" height="14" rx="7" fill="' + col + '"/><text x="' + (x + w / 2) + '" y="' + (y + 10.5) + '" text-anchor="middle" font-size="9" fill="#fff" font-weight="700" font-family="Cambria,Georgia,serif">' + esc(txt) + '</text></g>'); };
      Object.keys(M.F || {}).forEach(id => M.F[id].forEach(f => badge(id, '#e8710a', (nm[f] || f).slice(0, 12))));
      Object.keys(M.R || {}).forEach(id => M.R[id].forEach(f => badge(id, '#0072b2', (nm[f] || f).slice(0, 12))));
      extraH = 108; const y0 = 702; o.push('<rect x="108" y="' + (y0 - 8) + '" width="814" height="' + (extraH - 4) + '" fill="#fff" stroke="#d6dae0"/>');
      o.push('<rect x="118" y="' + y0 + '" width="20" height="11" rx="3" fill="rgba(232,113,10,0.13)" stroke="#e8710a" stroke-width="2"/>'); T(144, y0 + 9, 'Changed in this experiment: ' + ((M.factors || []).map(f => nm[f.id] || f.id).join(', ') || 'nothing'), 'start', 9.5);
      o.push('<rect x="118" y="' + (y0 + 20) + '" width="20" height="11" rx="3" fill="rgba(0,114,178,0.13)" stroke="#0072b2" stroke-width="2"/>'); T(144, y0 + 29, 'Measured: ' + ((M.resp || []).map(f => nm[f] || f).join(', ') || 'nothing'), 'start', 9.5);
      o.push('<line x1="120" y1="' + (y0 + 46) + '" x2="150" y2="' + (y0 + 46) + '" stroke="#e8710a" stroke-width="1.8" stroke-dasharray="7 4" marker-end="url(#dzAo)"/>'); T(158, y0 + 49, 'from the process that is changed to the processes that answer (click a box to see the figures that depend on it)', 'start', 9);
    }
    extraH = extraH || 38;
    return '<svg viewBox="84 14 850 ' + (646 + extraH) + '" style="width:100%;max-width:1000px;height:auto;display:block;background:#fff;border:1px solid #d6dae0;border-radius:6px" role="img" aria-label="Schematic overview of the main processes in Daisy' + (opt.marks ? ', marked for this experiment' : '') + '">' + o.join('') + '</svg>';
  }
  function chips() { return '<div style="margin:6px 0;font-size:12px;color:#444">Also in Daisy, not drawn in Fig. 1: ' + ['temp', 'bio', 'deni'].map(id => '<button class="dzPc" data-p="' + id + '" style="margin-right:6px' + (st.sel === id ? ';font-weight:700;outline:2px solid #d7191c' : '') + '">' + esc(byId(id).n) + '</button>').join('') + '</div>'; }
  // the data the figures are drawn from: the last scenario run, the runs of the Experiments tab, or the logs in the Files list; nothing is drawn without them
  function sources() {
    const out = [], SU = window.DaisyScenUI, XU = window.DaisyExpUI;
    if (SU) SU.runs().forEach(r => out.push({ id: 'scen:' + r.id, label: 'Scenario run: ' + r.label, run: r }));
    if (XU) XU.runs().forEach(r => out.push({ id: 'exp:' + r.id, label: 'Experiment run: ' + r.id + ' ' + r.label, run: r }));
    const logs = {}; D.names().forEach(n => { const k = window.DaisyScen.logKey(n); if (k) logs[k] = D.S.logs[n]; }); if (Object.keys(logs).length) out.push({ id: 'files', label: 'Logs loaded in Files (' + Object.keys(logs).length + ' with Daisy names)', run: { id: 'files', label: 'Loaded logs', logs } });
    return out;
  }
  const cur = () => { const L = sources(); return L.find(x => x.id === st.src) || L[0] || null; };
  async function runNow(msg) {
    const SU = window.DaisyScenUI; if (!D.isDesk() || !window.swafl || !window.swafl.daisyJob) { msg.innerHTML = '<span style="color:#b3261e">Daisy itself runs in the desktop app. Here, load the logs of a Daisy run in the Files tab (or run the experiment folder anywhere, then load its logs), and the figures are drawn from them.</span>'; return; }
    msg.textContent = 'Daisy is running with your weather and soil and all the process logs...'; try { await SU.runStandard(); st.src = null; await detail(); } catch (e) { msg.innerHTML = '<span style="color:#b3261e">' + esc(e.message) + '</span>'; }
  }
  function html(arg) {
    if (arg && byId(arg)) st.sel = arg;
    return '<div class="dzcard"><b>The processes of the Daisy model</b> redrawn from Fig. 1 of the Daisy paper. Click a box (snowpack, intercepted water, litter, pond, soil water, biopores, drain, NO3, NH4, Plant-N, organs, residues, photosynthesis, AOM, SMB, SOM) to read what Daisy does there and to draw its figures from the logs of a standard run of the rotation.</div>' +
      (window.DaisyScenUI ? window.DaisyScenUI.strip() : '') + '<div id="dzPmap">' + svg() + '</div><div id="dzPchips">' + chips() + '</div><div id="dzPdet"></div>';
  }
  async function detail() {
    const p = byId(st.sel), box = document.getElementById('dzPdet'); if (!box) return;
    box.innerHTML = '<div class="dzcard"><h3 style="margin:0 0 6px;color:' + GC[p.g] + '">' + esc(p.n) + '</h3><div>' + esc(p.d) + '</div><div style="margin-top:6px;color:#555;font-size:12px">Daisy: ' + esc(p.par) + '</div><div id="dzPst" style="margin-top:6px;font-size:12px;color:#555">Reading the bundled results...</div></div><div id="dzPfigs"></div>';
    const figs = document.getElementById('dzPfigs'), msg = document.getElementById('dzPst'), L = sources(), me = cur();
    if (!me) { msg.innerHTML = 'No data to draw from yet. The figures of this process come from your own run: <button class="btn pri" id="dzPRun">Run Daisy with my data now</button> or load the logs of a Daisy run in the <a href="#" data-goto="files">Files</a> tab, or run a <a href="#" data-goto="scen">scenario</a> or an <a href="#" data-goto="exp">experiment</a> (tick this process under "What I am interested in").'; const b = document.getElementById('dzPRun'); if (b) b.onclick = () => runNow(msg); if (window.DaisyScenUI) window.DaisyScenUI.bindStrip(); document.querySelectorAll('#dzPst [data-goto]').forEach(a => a.onclick = ev => { ev.preventDefault(); D.show(a.dataset.goto); }); return; }
    const o = me.run.options; if (o && window.DaisyCite) window.DaisyCite.ctx = window.DaisyCite.describe(o, window.DaisyScen);
    msg.innerHTML = 'Drawn from <select id="dzPSrc">' + L.map(x => '<option value="' + esc(x.id) + '"' + (x.id === me.id ? ' selected' : '') + '>' + esc(x.label) + '</option>').join('') + '</select> <button class="btn" id="dzPRun">Run Daisy with my data and all process logs</button> <span id="dzPsum" class="pnote"></span>';
    document.getElementById('dzPSrc').onchange = e => { st.src = e.target.value; detail(); }; document.getElementById('dzPRun').onclick = () => runNow(document.getElementById('dzPsum'));
    const r = await drawFigs(p, figs, async k => me.run.logs[k] || null, () => st.sel !== p.id);
    if (r) document.getElementById('dzPsum').textContent = r.ok + ' figure' + (r.ok === 1 ? '' : 's') + (r.bad ? ', ' + r.bad + ' not drawn (this run did not write those logs: run again with the button, or tick the process under "What I am interested in" in Scenarios)' : '') + '.';
  }
  // draw the figure cards of one process into a host; getLog(key) gives the parsed log; stale() tells when to stop
  async function drawFigs(p, figs, getLog, stale, what) {
    let ok = 0, bad = 0;
    for (const f of p.figs) {
      if (stale()) return null; const card = document.createElement('div'); card.className = 'dzcard dzfig'; card.innerHTML = '<b>' + esc(f.t) + '</b> <button class="dzPng btn">Save PNG</button><div><canvas style="display:block;width:100%;margin-top:6px"></canvas></div><div class="dzPn" style="font-size:12px;color:#555"></div>'; figs.appendChild(card);
      const cv = card.querySelector('canvas'), note = card.querySelector('.dzPn'); card._jobs = []; if (window.DaisyFigKit) window.DaisyFigKit.attach(card, { name: 'daisy-' + p.id + '-' + f.log, redraw: () => card._jobs.forEach(j => j()) });
      try {
        const d = await getLog(f.log); if (stale()) return null; if (!d) throw new Error(f.log + ' was not written by this run');
        if (f.annual) { annual(cv, card, d, note, f.t); ok++; continue; }
        const span = new Date(d.time[0]).getUTCFullYear() + ' to ' + new Date(d.time[d.n - 1]).getUTCFullYear();
        if (f.heat) { const dc = IO.depthColumns(d), vs = Object.keys(dc); if (!vs.length) throw new Error('no depth columns in ' + f.log); const pal = { Theta: 'blues', h: 'pf', C: 'ylgn' };
          vs.slice(0, 2).forEach((v, k) => { const L = IO.depthLong(d, v); let c = cv; if (k) { c = document.createElement('canvas'); c.style.cssText = cv.style.cssText; { const dv = document.createElement('div'); dv.appendChild(c); card.insertBefore(dv, note); } } J(card, () => K().heat(c, L.t, L.z, L.v, { title: f.t + (vs.length > 1 ? ': ' + v : ''), time: true, unit: L.unit || v, pal: pal[v] || 'viridis', h: 300 })); }); note.textContent = span + '; ' + vs.slice(0, 2).join(', ') + '. Colour bar in ' + (d.units[dc[vs[0]][0].c] || 'model units') + '.'; ok++; continue; }
        const n = panels(cv, card, d, f.c, f.t, note, true); if (!n.drawn) throw new Error(n.zeros.length ? 'every selected column of ' + f.log + ' is zero in this run (' + n.zeros.join(', ') + '), so there is nothing to draw' : 'columns not in ' + f.log); note.textContent = span + '.' + (n.zeros.length ? ' Left out because they are zero throughout: ' + n.zeros.join(', ') + '.' : ''); ok++;
      } catch (e) { bad++; card.querySelectorAll('canvas').forEach(c => c.remove()); note.textContent = 'Not drawn: ' + e.message; }
    }
    return { ok, bad };
  }
  const J = (card, fn) => { (card._jobs = card._jobs || []).push(fn); fn(); };   // a drawing that can be repeated (editing the titles, saving at a higher resolution)
  // one panel for each unit that the columns have, so that a rate in mm and a content in kg N are never on one axis
  function panels(cv, card, d, cols, title, note, time) {
    const groups = {}, zeros = []; let any = false, xs = time ? d.time : d.data[0].map(Number);
    cols.forEach(c => { const j = IO.colIndex(d, c); if (j < 0) return; const y = d.data[j]; if (!y.some(isFinite)) return; if (!y.some(v => isFinite(v) && v !== 0)) { zeros.push(d.cols[j]); return; } const u = d.units[d.cols[j]] || ''; (groups[u] = groups[u] || []).push({ name: d.cols[j], x: xs, y, pts: !time, line: true }); });
    const keys = Object.keys(groups).slice(0, 4); keys.forEach((u, k) => { let c = cv; if (k) { c = document.createElement('canvas'); c.style.cssText = cv.style.cssText; { const dv = document.createElement('div'); dv.appendChild(c); card.insertBefore(dv, note); } } J(card, () => K().line(c, groups[u], { title: title + (keys.length > 1 ? (u ? ' (' + u + ')' : '') : ''), time, xint: !time, xt: time ? 'Year' : 'Year', yt: u || 'model units', h: time ? 250 : 270, zero: !time })); any = true; });
    return { drawn: any, zeros };
  }
  function annual(cv, card, d, note, title) {
    const cols = d.cols.slice(4); const n = panels(cv, card, d, cols, title, note, false); if (!n.drawn) throw new Error('every column is zero in this run'); note.textContent = 'Annual totals per season of the standard run (a season starts on 1 April; the label is the year in which it starts).' + (n.zeros.length ? ' Left out because they are zero throughout: ' + n.zeros.join(', ') + '.' : '');
  }
  function bind() {
    const map = document.getElementById('dzPmap'); const act = id => { if (!id || !byId(id)) return; st.sel = id; map.innerHTML = svg(); document.getElementById('dzPchips').innerHTML = chips(); wire(); detail(); };
    const wire = () => { document.querySelectorAll('.dzPc').forEach(b => b.onclick = () => act(b.dataset.p)); map.querySelectorAll('.dzPb[data-p]').forEach(g => { g.onclick = () => act(g.dataset.p); g.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); act(g.dataset.p); } }; }); };
    wire(); detail(); if (window.DaisyScenUI) window.DaisyScenUI.bindStrip();
  }
  // click on a process anywhere (experiment, scenario, SWAFL layer): what Daisy does there and its figures, drawn from the logs of the runs given
  // runs: [{ label, logs }]; the figures are those of the Processes tab
  async function detailInto(host, pid, runs, note) {
    const p = byId(pid); if (!p) { host.innerHTML = ''; return; } const mine = (runs || []).filter(r => r && r.logs); let pick = 0, seq = 0;
    host.innerHTML = '<div class="dzcard"><h3 style="margin:0 0 4px;color:' + GC[p.g] + '">' + esc(p.n) + '</h3><div>' + esc(p.d) + '</div><div class="pnote" style="margin-top:4px">Daisy: ' + esc(p.par) + '</div>' + (note ? '<div class="pnote" style="margin-top:4px">' + esc(note) + '</div>' : '') +
      '<div class="dzrow" style="margin-top:6px">' + (mine.length ? '<label>Figures of this process from run</label><select data-pd="run">' + mine.map((r, i) => '<option value="' + i + '">' + esc(r.label || r.id || 'run ' + (i + 1)) + '</option>').join('') + '</select>' : '<span class="pnote">No Daisy run is open yet. Run Daisy (a scenario or an experiment with the process logs) and the figures of this process are drawn here.</span>') + '</div><div data-pd="figs"></div></div>';
    const draw = async () => { const my = ++seq, fh = host.querySelector('[data-pd="figs"]'); if (!fh || !mine.length) return; fh.innerHTML = ''; const r = mine[pick]; await drawFigs(p, fh, async k => r.logs[k] || null, () => my !== seq); };
    const sel = host.querySelector('[data-pd="run"]'); if (sel) sel.onchange = () => { pick = +sel.value; draw(); }; draw();
  }
  window.DaisyProc = { PROCESSES: P, drawFigs, GC, svg, byId, detailInto };
  D.register('proc', { html, bind });
})();
