/* Field sketch: draw the field with the mouse (corners you can drag, sides you can type), place the water source and the
   inlet, choose the crop, the system and the pipe layout, answer the questions of each step, and the sketch becomes the
   inputs of the irrigation design, ready to run. Also the comparison of the three systems on the present field. */
'use strict';
const Sketch = (() => {
  let CW = 640, CH = 440; const GRID = 32;                          // canvas and grid square (px)
  const SC = [1, 2, 5, 10, 20, 25, 50, 100];
  const S = {                                                   // the sketch and the answers, kept while the program runs
    pts: [], src: null, inlet: null, scale: 10, mode: 'field', step: 0,
    L: 150, Wd: 100, slope: 0.3, slopeDir: 'run',
    srcType: 'well', lift: 12, supply: 30, hours: 16,
    crop: null, row: 0.75, plant: 0.3,
    soil: null, pan: false,
    sys: 'drip', sub: 'border', dep: 0, kind: 'inline', sprSys: 'solid', sprType: 'impact', dir: 'length',
    intv: 2, sprSs: 12, sprSl: 18, auto: false, pd: { main: 90, sub: 63, lat: 16 },
    objs: [], cad: [], cur: null, rect: null                              // greenhouses, plant beds, areas to irrigate, no-irrigation zones, plants and traps
  };
  const OBJ = { gh: ['Greenhouse / polytunnel', '#1E88E5', 'rect'], bed: ['Plant bed', '#8D6E63', 'rect'], irr: ['Area to irrigate', '#00897B', 'poly'], noirr: ['No-irrigation zone', '#C62828', 'poly'], plant: ['Plant / tree', '#2E7D32', 'pt'], trap: ['Monitoring trap', '#6A1B9A', 'pt'],
    main: ['Mainline pipe', '#0A246A', 'line'], sub: ['Submain pipe', '#1565C0', 'line'], lat: ['Lateral pipe', '#2E9BE0', 'line'], valve: ['Valve', '#F57C00', 'pt'], pump: ['Pump', '#AD1457', 'pt'], filter: ['Filter', '#00838F', 'pt'], tank: ['Tank', '#5D4037', 'pt'] };
  const PIPE_D = { main: 90, sub: 63, lat: 16 }, PIPE_OPTS = { main: [50, 63, 75, 90, 110, 125, 160, 200], sub: [40, 50, 63, 75, 90, 110, 125], lat: [12, 16, 20, 25, 32, 40, 50] }, PIPE_C = { main: 140, sub: 140, lat: 150 };
  const lineLen = P => { let t = 0; for (let i = 1; i < P.length; i++) t += m(len(P[i - 1], P[i])); return t; };
  const HIST = { u: [], r: [] };                                 // undo and redo (Ctrl+Z, Ctrl+Y)
  const snapS = () => JSON.stringify({ pts: S.pts, src: S.src, inlet: S.inlet, objs: S.objs, cad: S.cad });
  function pushH() { HIST.u.push(snapS()); if (HIST.u.length > 80) HIST.u.shift(); HIST.r = []; }
  function loadH(j) { const o = JSON.parse(j); S.pts = o.pts; S.src = o.src; S.inlet = o.inlet; S.objs = o.objs; S.cad = o.cad || []; S.cur = null; S.rect = null; if (window.SketchCAD) SketchCAD.reset(); }
  function undo() { if (S.cur && S.cur.pts.length) { S.cur.pts.pop(); if (!S.cur.pts.length) S.cur = null; draw(); return; } if (!HIST.u.length) return; HIST.r.push(snapS()); loadH(HIST.u.pop()); draw(); info(); }
  function redo() { if (!HIST.r.length) return; HIST.u.push(snapS()); loadH(HIST.r.pop()); draw(); info(); }
  let cv = null, drag = null, hover = null, cursor = null, edit = null, LIST = null, panning = null;
  const V = { z: 1, x: 0, y: 0 };                                // the view: zoom and the sketch point at the top left corner
  const toScr = p => ({ x: (p.x - V.x) * V.z, y: (p.y - V.y) * V.z });
  const len = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const m = px => px * S.scale / GRID, px = mm => mm * GRID / S.scale;    // pixels <-> metres
  const snap = v => Math.round(v / (GRID / 4)) * (GRID / 4);
  const fmt = (v, d) => (isFinite(v) ? (+v).toFixed(d == null ? 0 : d) : '-');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // ------------------------------------------------------------------ geometry of the field
  function geom() {
    const P = S.pts; if (P.length < 3) return null; let A = 0, per = 0, L = 0, ang = 0;
    for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length], d = len(a, b); A += a.x * b.y - b.x * a.y; per += d; if (d > L) { L = d; ang = Math.atan2(b.y - a.y, b.x - a.x); } }
    if (S.dir === 'across') ang += Math.PI / 2;
    const ux = Math.cos(ang), uy = Math.sin(ang); let lo = 1e9, hi = -1e9, wlo = 1e9, whi = -1e9;
    P.forEach(p => { const s = p.x * ux + p.y * uy, t = -p.x * uy + p.y * ux; lo = Math.min(lo, s); hi = Math.max(hi, s); wlo = Math.min(wlo, t); whi = Math.max(whi, t); });
    const inl = S.inlet || nearestOnEdge(S.src || P[0]).p, main = S.src ? m(len(S.src, inl)) : 0;
    return { area: m(m(Math.abs(A) / 2)), perim: m(per), run: m(hi - lo), wid: m(whi - wlo), main, ux, uy, lo, hi, wlo, whi, inl };
  }
  function nearestOnEdge(q) {
    const P = S.pts; let best = { d: 1e9, p: P[0] || q, i: 0 };
    for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length], dx = b.x - a.x, dy = b.y - a.y, L2 = dx * dx + dy * dy || 1, t = Math.max(0, Math.min(1, ((q.x - a.x) * dx + (q.y - a.y) * dy) / L2)), p = { x: a.x + t * dx, y: a.y + t * dy }, d = len(p, q); if (d < best.d) best = { d, p, i }; }
    return best;
  }
  function inside(x, y) { const P = S.pts; let c = false; for (let i = 0, j = P.length - 1; i < P.length; j = i++) { const a = P[i], b = P[j]; if ((a.y > y) !== (b.y > y) && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) c = !c; } return c; }
  function rectangle() {
    const Lp = px(S.L), Wp = px(S.Wd), k = Math.min(1, (CW - 120) / Lp, (CH - 110) / Wp);
    if (k < 1) { const ns = SC.find(v => px(S.L) * S.scale / v <= CW - 120 && px(S.Wd) * S.scale / v <= CH - 110) || 100; S.scale = Math.max(S.scale, ns); }
    const a = px(S.L), b = px(S.Wd), x0 = snap((CW - a) / 2), y0 = snap((CH - b) / 2 + 10);
    S.pts = [{ x: x0, y: y0 }, { x: x0 + a, y: y0 }, { x: x0 + a, y: y0 + b }, { x: x0, y: y0 + b }];
    if (!S.src) S.src = { x: Math.max(24, x0 - 70), y: y0 + b / 2 }; S.inlet = null;
  }

  // ------------------------------------------------------------------ drawing
  function draw() { draw0(); drawObjs(); if (window.SketchCAD) SketchCAD.draw(); }
  const cadOn = () => !!window.SketchCAD && String(S.mode).indexOf('cad:') === 0;
  function draw0() {
    if (!cv) return; const c = cv.getContext('2d'), k0 = cv.width / CW, vw = CW / V.z, vh = CH / V.z, w = V.x + vw, h = V.y + vh, x0 = V.x, y0 = V.y;
    c.setTransform(k0, 0, 0, k0, 0, 0); c.fillStyle = '#FBFBF8'; c.fillRect(0, 0, CW, CH);
    c.setTransform(k0 * V.z, 0, 0, k0 * V.z, -V.x * k0 * V.z, -V.y * k0 * V.z); c.strokeStyle = '#E6E4DC'; c.lineWidth = 1 / V.z;
    for (let x = Math.floor(x0 / GRID) * GRID; x <= w; x += GRID) { c.beginPath(); c.moveTo(x, y0); c.lineTo(x, h); c.stroke(); }
    for (let y = Math.floor(y0 / GRID) * GRID; y <= h; y += GRID) { c.beginPath(); c.moveTo(x0, y); c.lineTo(w, y); c.stroke(); }
    const P = S.pts, g = geom();
    if (P.length) {
      c.fillStyle = 'rgba(126,170,90,0.20)'; c.strokeStyle = '#2E7D32'; c.lineWidth = 2 / V.z; c.beginPath(); P.forEach((p, i) => i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y)); if (P.length > 2) c.closePath(); c.fill(); c.stroke();
    }
    if (g) layout(c, g);
    // corners and side lengths (click a length to type it)
    P.forEach((p, i) => { const on = hover && hover.t === 'pt' && hover.i === i; c.fillStyle = on ? '#C62828' : '#2E7D32'; c.beginPath(); c.arc(p.x, p.y, (on ? 7 : 5) / V.z, 0, Math.PI * 2); c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 1.5 / V.z; c.stroke(); });
    if (P.length > 1) P.forEach((p, i) => { if (P.length < 3 && i === P.length - 1) return; const q = P[(i + 1) % P.length], t = fmt(m(len(p, q))) + ' m', [mx, my] = sideLab(i); c.save(); c.translate(mx, my); c.scale(1 / V.z, 1 / V.z); c.font = 'bold 11px Tahoma,Arial,sans-serif'; const tw = c.measureText(t).width + 10; const on = hover && hover.t === 'side' && hover.i === i; c.fillStyle = on ? '#FFF4C2' : 'rgba(255,255,255,0.95)'; c.strokeStyle = on ? '#C62828' : '#9AA5B1'; c.lineWidth = 1; c.fillRect(-tw / 2, -9, tw, 18); c.strokeRect(-tw / 2 + 0.5, -8.5, tw - 1, 17); c.fillStyle = '#1B1F23'; c.textAlign = 'center'; c.fillText(t, 0, 4); c.restore(); c.textAlign = 'left'; });
    // water source and inlet
    if (S.src) { const on = hover && hover.t === 'src'; c.fillStyle = '#1F5FA8'; c.beginPath(); c.arc(S.src.x, S.src.y, (on ? 11 : 9) / V.z, 0, Math.PI * 2); c.fill(); c.fillStyle = '#fff'; c.font = 'bold ' + (10 / V.z) + 'px Tahoma,Arial,sans-serif'; c.textAlign = 'center'; c.fillText('W', S.src.x, S.src.y + 3.5 / V.z); c.fillStyle = '#1F5FA8'; c.font = 'bold ' + (10 / V.z) + 'px Tahoma,Arial,sans-serif'; c.fillText({ well: 'well', borehole: 'borehole', canal: 'canal', river: 'river', tank: 'pond or tank' }[S.srcType] || 'source', S.src.x, S.src.y + 22 / V.z); c.textAlign = 'left'; }
    if (g && S.src) { const on = hover && hover.t === 'inlet'; c.fillStyle = '#F2C230'; c.strokeStyle = '#5A4500'; c.lineWidth = 1.5 / V.z; c.beginPath(); c.rect(g.inl.x - (on ? 7 : 5) / V.z, g.inl.y - (on ? 7 : 5) / V.z, (on ? 14 : 10) / V.z, (on ? 14 : 10) / V.z); c.fill(); c.stroke(); }
    // the moving cursor: crosshair and its position in metres
    if (cursor && !drag && !panning) { c.strokeStyle = 'rgba(198,40,40,0.35)'; c.lineWidth = 1 / V.z; c.setLineDash([3 / V.z, 3 / V.z]); c.beginPath(); c.moveTo(cursor.x, y0); c.lineTo(cursor.x, h); c.moveTo(x0, cursor.y); c.lineTo(w, cursor.y); c.stroke(); c.setLineDash([]); }
    // what stays on the screen: the grid square, the scale bar, the zoom and the cursor position
    c.setTransform(k0, 0, 0, k0, 0, 0); const W2 = CW, H2 = CH;
    { const t = '1 square = ' + S.scale + ' m · zoom ' + Math.round(V.z * 100) + ' %' + (S.geo ? ' · ' + S.geo.lat.toFixed(5) + ', ' + S.geo.lon.toFixed(5) : ''); c.font = '11px Tahoma,Arial,sans-serif'; const tw = c.measureText(t).width + 10; c.fillStyle = 'rgba(251,251,248,0.92)'; c.fillRect(2, H2 - 20, tw, 17); c.fillStyle = '#505050'; c.fillText(t, 7, H2 - 8); }
    { const nice = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000], mpp = S.scale / GRID / V.z, bm = nice.reduce((b, v) => v / mpp <= 110 ? v : b, nice[0]), bl = bm / mpp; c.fillStyle = 'rgba(251,251,248,0.92)'; c.fillRect(W2 - bl - 24, H2 - 32, bl + 20, 28); c.strokeStyle = '#303030'; c.lineWidth = 2; c.beginPath(); c.moveTo(W2 - bl - 14, H2 - 12); c.lineTo(W2 - 14, H2 - 12); c.moveTo(W2 - bl - 14, H2 - 16); c.lineTo(W2 - bl - 14, H2 - 8); c.moveTo(W2 - 14, H2 - 16); c.lineTo(W2 - 14, H2 - 8); c.stroke(); c.fillStyle = '#303030'; c.font = '11px Tahoma,Arial,sans-serif'; c.textAlign = 'center'; c.fillText(bm + ' m', W2 - 14 - bl / 2, H2 - 18); c.textAlign = 'left'; }
    { c.fillStyle = 'rgba(255,255,255,0.9)'; c.fillRect(W2 - 34, 6, 28, 38); c.fillStyle = '#303030'; c.beginPath(); c.moveTo(W2 - 20, 10); c.lineTo(W2 - 27, 30); c.lineTo(W2 - 13, 30); c.closePath(); c.fill(); c.font = 'bold 10px Tahoma,Arial,sans-serif'; c.textAlign = 'center'; c.fillText('N', W2 - 20, 41); c.textAlign = 'left'; }
    if (cursor && !panning && !cadOn()) { const sp = toScr(cursor), t = 'x ' + fmt(m(cursor.x)) + ' m · y ' + fmt(m(cursor.y)) + ' m'; c.font = '10px Tahoma,Arial,sans-serif'; const tw = c.measureText(t).width + 10, bx = Math.min(W2 - tw - 4, sp.x + 12), by = Math.max(4, sp.y - 24); c.fillStyle = 'rgba(27,31,35,0.85)'; c.fillRect(bx, by, tw, 16); c.fillStyle = '#fff'; c.fillText(t, bx + 5, by + 12); }
    if (!P.length && !(S.cad && S.cad.length) && !cadOn()) { c.fillStyle = '#505050'; c.font = '13px Tahoma,Arial,sans-serif'; c.textAlign = 'center'; c.fillText('Click to place the corners of your field, or use "Make a rectangle" on the right.', W2 / 2, H2 / 2 - 18); c.fillText('Drag a corner to move it; click a side length to type it exactly.', W2 / 2, H2 / 2 + 2); c.fillText('Or find the farm on the satellite map: "Locate on the map".', W2 / 2, H2 / 2 + 22); c.textAlign = 'left'; }
    info();
  }
  // the layout inside the field: furrows, borders or basins; drip laterals; sprinklers; submain, mainline and valves
  function layout(c, g) {
    const sysS = S.sys === 'sid' ? S.sub : S.sys, Pp = S.pts;
    c.save(); c.beginPath(); Pp.forEach((p, i) => i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y)); c.closePath(); c.clip();
    const along = (t, s) => ({ x: s * g.ux - t * g.uy, y: s * g.uy + t * g.ux });
    let spM = sysS === 'drip' ? S.row : sysS === 'spr' ? S.sprSl : sysS === 'furrow' ? S.row : sysS === 'border' ? 10 : 20, sp = px(spM), k = Math.max(1, Math.ceil(5 / sp));
    if (sysS === 'basin') { const n = Math.max(1, Math.round(m(g.hi - g.lo) / 40)); c.strokeStyle = '#8A6A3A'; c.lineWidth = 2 / V.z; for (let i = 1; i < n; i++) { const s = g.lo + (g.hi - g.lo) * i / n, a = along(g.wlo - 5, s), b = along(g.whi + 5, s); c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke(); } }
    c.lineWidth = (sysS === 'drip' ? 1.2 : sysS === 'spr' ? 1.6 : 1.4) / V.z; c.strokeStyle = sysS === 'drip' ? '#1F5FA8' : sysS === 'spr' ? '#3A6EA5' : sysS === 'furrow' ? '#6B4F2A' : '#8A6A3A';
    let n = 0; for (let t = g.wlo + sp / 2; t < g.whi; t += sp * k) { const a = along(t, g.lo - 5), b = along(t, g.hi + 5); c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke(); n++; }
    if (sysS === 'spr') { const ss = px(S.sprSs), kk = Math.max(1, Math.ceil(6 / ss)); c.fillStyle = '#1F5FA8'; for (let t = g.wlo + sp / 2; t < g.whi; t += sp * k) for (let s = g.lo + ss / 2; s < g.hi; s += ss * kk) { const q = along(t, s); if (!inside(q.x, q.y)) continue; c.beginPath(); c.arc(q.x, q.y, 2.2 / V.z, 0, Math.PI * 2); c.fill(); c.strokeStyle = 'rgba(31,95,168,0.12)'; c.beginPath(); c.arc(q.x, q.y, ss * kk * 0.65, 0, Math.PI * 2); c.stroke(); } }
    c.restore();
    // submain (or head ditch) along the inlet end of the run, mainline from the source
    const SM = submainSeg(g), sEnd = SM.sEnd, a = SM.a, b = SM.b;
    c.strokeStyle = S.sys === 'sid' ? '#3A7BD5' : '#0A246A'; c.lineWidth = (S.sys === 'sid' ? 6 : 3.5) / V.z; c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke();
    if (S.src) { c.strokeStyle = '#0A246A'; c.lineWidth = 3 / V.z; c.setLineDash([8 / V.z, 4 / V.z]); c.beginPath(); c.moveTo(S.src.x, S.src.y); c.lineTo(g.inl.x, g.inl.y); c.stroke(); c.setLineDash([]); }
    const lab = (t, x, y, col) => { c.save(); c.translate(x, y); c.scale(1 / V.z, 1 / V.z); c.font = 'bold 10px Tahoma,Arial,sans-serif'; const tw = c.measureText(t).width + 8; c.fillStyle = 'rgba(255,255,255,0.92)'; c.fillRect(-tw / 2, -10, tw, 15); c.fillStyle = col || '#0A246A'; c.textAlign = 'center'; c.fillText(t, 0, 1); c.restore(); };
    if (S.src) { const dx = g.inl.x - S.src.x, dy = g.inl.y - S.src.y, dl = Math.hypot(dx, dy) || 1, nx = -dy / dl, ny = dx / dl, sg = ny > 0 ? -1 : 1; lab('mainline ' + fmt(g.main) + ' m', (S.src.x + g.inl.x) / 2 + nx * 16 * sg, (S.src.y + g.inl.y) / 2 + ny * 16 * sg + 4); }
    { const ln = m(len(a, b)), d0 = len(g.inl, a) > len(g.inl, b) ? 0.3 : 0.7, q = { x: a.x + (b.x - a.x) * d0, y: a.y + (b.y - a.y) * d0 }, dl = len(a, b) || 1; let nx = -(b.y - a.y) / dl, ny = (b.x - a.x) / dl; if (!inside(q.x + nx * 6, q.y + ny * 6)) { nx = -nx; ny = -ny; } lab((S.sys === 'sid' ? 'head ditch ' : 'submain ') + fmt(ln) + ' m', q.x + nx * 18, q.y + ny * 18 + 4); }
    const mid = along((g.wlo + g.whi) / 2, (g.lo + g.hi) / 2);
    lab((S.sys === 'sid' ? (S.sub === 'furrow' ? 'furrows ' : S.sub === 'basin' ? 'basins, run ' : 'borders ') : sysS === 'drip' ? 'laterals ' : 'sprinkler laterals ') + fmt(g.run) + ' m', mid.x, mid.y, '#12303A');
  }
  // where the length of a side is written: just outside the field, on the middle of the side
  function sideLab(i) {
    const P = S.pts, a = P[i], b = P[(i + 1) % P.length], d = len(a, b) || 1; let nx = (b.y - a.y) / d, ny = -(b.x - a.x) / d, f = 0.5;
    if (S.src && P.length > 2 && S.inlet !== undefined) { const inl = S.inlet || nearestOnEdge(S.src).p; if (len(inl, { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }) < 40) f = len(inl, a) > len(inl, b) ? 0.22 : 0.78; }
    const mx = a.x + (b.x - a.x) * f, my = a.y + (b.y - a.y) * f;
    if (P.length > 2 && inside(mx + nx * 4, my + ny * 4)) { nx = -nx; ny = -ny; } return P.length > 2 ? [mx + nx * 15, my + ny * 15] : [mx, my - 12];
  }
  function info() {
    const el = document.getElementById('skInfo'); if (!el) return; const g = geom();
    el.innerHTML = g ? '<b>' + fmt(g.area / 10000, 2) + ' ha</b> (' + Math.round(g.area).toLocaleString('en-US') + ' m²) · run ' + fmt(g.run) + ' m · width ' + fmt(g.wid) + ' m · perimeter ' + fmt(g.perim) + ' m' + (S.src ? ' · mainline ' + fmt(g.main) + ' m' : ' · place the water source') : 'Draw at least three corners.';
    if (el && S.objs.length) el.innerHTML += '<br>' + objSummary();
    const sm = document.getElementById('skSum'); if (sm) sm.innerHTML = summary();
  }


  // ------------------------------------------------------------------ greenhouses, beds, irrigated areas, plants and traps
  const polyA = P => { let A = 0; for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length]; A += a.x * b.y - b.x * a.y; } return m(m(Math.abs(A) / 2)); };
  const rectPts = (a, b) => [{ x: a.x, y: a.y }, { x: b.x, y: a.y }, { x: b.x, y: b.y }, { x: a.x, y: b.y }];
  const inPoly = (P, x, y) => { let c = false; for (let i = 0, j = P.length - 1; i < P.length; j = i++) { const a = P[i], b = P[j]; if ((a.y > y) !== (b.y > y) && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) c = !c; } return c; };
  function objStats() {
    const o = { gh: 0, bed: 0, irr: 0, noirr: 0, plant: 0, trap: 0, nGh: 0, nBed: 0, nIrr: 0, nNo: 0, valve: 0, pump: 0, filter: 0, tank: 0, pipes: { main: 0, sub: 0, lat: 0 }, nPipe: 0 };
    S.objs.forEach(q => { const k = OBJ[q.t][2]; if (k === 'pt') o[q.t]++; else if (k === 'line') { o.pipes[q.t] += lineLen(q.pts); o.nPipe++; } else { const a = polyA(q.pts); o[q.t] += a; o['n' + { gh: 'Gh', bed: 'Bed', irr: 'Irr', noirr: 'No' }[q.t]]++; } });
    return o;
  }
  // the area the design should irrigate: the drawn irrigation areas, else the field less the no-irrigation zones
  function irrArea() { const g = geom(), o = objStats(); if (o.irr > 0) return Math.max(1, o.irr - o.noirr * 0); if (g) return Math.max(1, g.area - o.noirr); return 0; }
  function drawObjs() {
    if (!cv) return; const c = cv.getContext('2d'), k0 = cv.width / CW; c.setTransform(k0 * V.z, 0, 0, k0 * V.z, -V.x * k0 * V.z, -V.y * k0 * V.z);
    const one = (q, cur) => {
      const d = OBJ[q.t]; c.strokeStyle = d[1]; c.lineWidth = 2 / V.z; c.fillStyle = d[1] + (q.t === 'noirr' ? '30' : q.t === 'gh' ? '33' : '26');
      if (OBJ[q.t][2] === 'line') {
        const P = q.pts, w = 1.6 + (q.dia || 16) / 22; c.strokeStyle = d[1]; c.lineWidth = w / V.z; c.lineJoin = 'round'; c.lineCap = 'round'; c.setLineDash(q.t === 'lat' ? [] : []); c.beginPath(); P.forEach((p, i) => i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y)); c.stroke();
        if (!cur && P.length > 1) { let tot = 0, seg = []; for (let i = 1; i < P.length; i++) { const l = len(P[i - 1], P[i]); seg.push(l); tot += l; } let h = tot / 2, i = 0; while (i < seg.length - 1 && h > seg[i]) { h -= seg[i]; i++; } const a = P[i], b = P[i + 1], f = seg[i] ? h / seg[i] : 0, mx = a.x + (b.x - a.x) * f, my = a.y + (b.y - a.y) * f, t = '\u00D8' + (q.dia || 16) + ' · ' + fmt(lineLen(P)) + ' m'; c.font = 'bold ' + (10 / V.z) + 'px Tahoma,Arial,sans-serif'; const tw = c.measureText(t).width + 6 / V.z; c.fillStyle = 'rgba(255,255,255,0.92)'; c.fillRect(mx - tw / 2, my - 15 / V.z, tw, 13 / V.z); c.fillStyle = d[1]; c.textAlign = 'center'; c.fillText(t, mx, my - 5 / V.z); c.textAlign = 'left'; }
        return;
      }
      if (OBJ[q.t][2] === 'pt' && q.t !== 'plant' && q.t !== 'trap') {
        const p0 = q.pts[0], r = 9 / V.z; c.fillStyle = '#FFFFFF'; c.strokeStyle = d[1]; c.lineWidth = 2 / V.z; c.beginPath();
        if (q.t === 'valve') { c.moveTo(p0.x - r, p0.y - r * 0.7); c.lineTo(p0.x + r, p0.y + r * 0.7); c.lineTo(p0.x + r, p0.y - r * 0.7); c.lineTo(p0.x - r, p0.y + r * 0.7); c.closePath(); }
        else if (q.t === 'pump') c.arc(p0.x, p0.y, r, 0, 7); else c.rect(p0.x - r, p0.y - r * 0.8, 2 * r, 1.6 * r);
        c.fill(); c.stroke(); c.fillStyle = d[1]; c.font = 'bold ' + (10 / V.z) + 'px Tahoma,Arial,sans-serif'; c.textAlign = 'center'; if (q.t !== 'valve') c.fillText({ pump: 'P', filter: 'F', tank: 'T' }[q.t], p0.x, p0.y + 3.5 / V.z); c.fillText(d[0].split(' /')[0], p0.x, p0.y + 21 / V.z); c.textAlign = 'left'; return;
      }
      if (q.t === 'plant' || q.t === 'trap') { const r = (q.t === 'plant' ? 5 : 6) / V.z; c.beginPath(); if (q.t === 'plant') c.arc(q.pts[0].x, q.pts[0].y, r, 0, 7); else { c.moveTo(q.pts[0].x, q.pts[0].y - r); c.lineTo(q.pts[0].x + r, q.pts[0].y + r); c.lineTo(q.pts[0].x - r, q.pts[0].y + r); c.closePath(); } c.fillStyle = d[1]; c.fill(); return; }
      const P = q.pts; if (!P.length) return; c.beginPath(); P.forEach((p, i) => i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y)); if (!cur && P.length > 2) { c.closePath(); c.fill(); } if (q.t === 'noirr' || cur) c.setLineDash([6 / V.z, 4 / V.z]); c.stroke(); c.setLineDash([]);
      if (q.t === 'gh' && !cur && P.length > 2) { c.lineWidth = 1 / V.z; for (let i = 1; i < 6; i++) { const f = i / 6; c.beginPath(); c.moveTo(P[0].x + (P[1].x - P[0].x) * f, P[0].y + (P[1].y - P[0].y) * f); c.lineTo(P[3].x + (P[2].x - P[3].x) * f, P[3].y + (P[2].y - P[3].y) * f); c.stroke(); } }
      if (q.t === 'bed' && !cur && P.length > 2) { c.lineWidth = 1 / V.z; const w = Math.abs(P[1].x - P[0].x), h = Math.abs(P[2].y - P[0].y); for (let i = 1; i < 5; i++) { const f = i / 5; c.beginPath(); if (w >= h) { c.moveTo(P[0].x, P[0].y + (P[3].y - P[0].y) * f); c.lineTo(P[1].x, P[0].y + (P[3].y - P[0].y) * f); } else { c.moveTo(P[0].x + (P[1].x - P[0].x) * f, P[0].y); c.lineTo(P[0].x + (P[1].x - P[0].x) * f, P[3].y); } c.stroke(); } }
      if (!cur && P.length > 2) { const cx = P.reduce((a, p) => a + p.x, 0) / P.length, cy = P.reduce((a, p) => a + p.y, 0) / P.length; c.fillStyle = d[1]; c.font = 'bold ' + (11 / V.z) + 'px sans-serif'; c.textAlign = 'center'; c.fillText(d[0].split(' /')[0] + ' ' + fmt(polyA(P)) + ' m²', cx, cy); }
    };
    S.objs.forEach(q => one(q, false)); if (S.cur) one(S.cur, true);
    if (S.cur && cursor && S.cur.pts.length) { const l = S.cur.pts[S.cur.pts.length - 1]; c.strokeStyle = OBJ[S.cur.t][1]; c.lineWidth = 1 / V.z; c.setLineDash([3 / V.z, 3 / V.z]); c.beginPath(); c.moveTo(l.x, l.y); c.lineTo(cursor.x, cursor.y); c.stroke(); c.setLineDash([]); }
    if (S.rect && cursor) { const P = rectPts(S.rect.a, { x: snap(cursor.x), y: snap(cursor.y) }), d = OBJ[S.rect.t]; c.strokeStyle = d[1]; c.lineWidth = 1.5 / V.z; c.setLineDash([5 / V.z, 3 / V.z]); c.beginPath(); P.forEach((p, i) => i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y)); c.closePath(); c.stroke(); c.setLineDash([]); c.fillStyle = d[1]; c.font = (11 / V.z) + 'px sans-serif'; c.textAlign = 'left'; c.fillText(fmt(m(Math.abs(P[1].x - P[0].x)), 1) + ' × ' + fmt(m(Math.abs(P[2].y - P[0].y)), 1) + ' m', P[2].x + 6 / V.z, P[2].y); }
  }
  // a click while one of the object tools is chosen; true when the click was used
  function objClick(q) {
    const d = OBJ[S.mode]; if (!d) return false; pushH();
    if (d[2] === 'pt') S.objs.push({ t: S.mode, pts: [q] });
    else if (d[2] === 'rect') { if (!S.rect) S.rect = { t: S.mode, a: q }; else { if (Math.abs(q.x - S.rect.a.x) > 2 && Math.abs(q.y - S.rect.a.y) > 2) S.objs.push({ t: S.mode, pts: rectPts(S.rect.a, q) }); else HIST.u.pop(); S.rect = null; } }
    else if (d[2] === 'line') {
      const onPipe = pipeSnap(q);                                  // a click on a pipe already drawn joins it (a junction)
      if (!S.cur) { S.cur = { t: S.mode, pts: [], dia: S.pd[S.mode] || PIPE_D[S.mode] }; S.cur.pts.push(onPipe || q); }
      else {
        const last = S.cur.pts[S.cur.pts.length - 1];
        if (len(last, q) < 9 / V.z) { if (S.cur.pts.length > 1) { finishCur(); return true; } HIST.u.pop(); return true; }   // a click on the dead end finishes the pipe
        S.cur.pts.push(onPipe || q); if (onPipe) { finishCur(); return true; }                                          // a click on another pipe ends this one there
      }
    }
    else { if (!S.cur) S.cur = { t: S.mode, pts: [] }; if (S.cur.pts.length > 2 && len(S.cur.pts[0], q) < 9 / V.z) { finishCur(); return true; } S.cur.pts.push(q); }
    info(); return true;
  }
  let lastFin = 0;
  function pipeSnap(q) { let best = null, bd = 9 / V.z; S.objs.forEach(o => { if (OBJ[o.t][2] !== 'line') return; for (let j = 1; j < o.pts.length; j++) { const a = o.pts[j - 1], b = o.pts[j], dx = b.x - a.x, dy = b.y - a.y, L2 = dx * dx + dy * dy || 1, t = Math.max(0, Math.min(1, ((q.x - a.x) * dx + (q.y - a.y) * dy) / L2)), p = { x: a.x + t * dx, y: a.y + t * dy }, d = len(p, q); if (d < bd) { bd = d; best = p; } } }); return best; }
  function finishCur() { lastFin = Date.now(); if (S.cur && OBJ[S.cur.t][2] === 'line') S.cur.pts = S.cur.pts.filter((p, i, a) => !i || len(p, a[i - 1]) > 2); if (S.cur && S.cur.pts.length >= (OBJ[S.cur.t][2] === 'line' ? 2 : 3)) S.objs.push(S.cur); else if (S.cur) HIST.u.pop(); S.cur = null; draw(); info(); }
  function segD(p, a, b) { const dx = b.x - a.x, dy = b.y - a.y, L2 = dx * dx + dy * dy || 1, t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / L2)); return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy); }
  function objAt(p) { for (let i = S.objs.length - 1; i >= 0; i--) { const q = S.objs[i]; if (OBJ[q.t][2] === 'line') { for (let j = 1; j < q.pts.length; j++) if (segD(p, q.pts[j - 1], q.pts[j]) < 8 / V.z) return i; } else if (q.pts.length === 1) { if (len(q.pts[0], p) < 9 / V.z) return i; } else if (inPoly(q.pts, p.x, p.y)) return i; } return -1; }
  function objSummary() {
    const o = objStats(), a = [];
    if (o.nIrr) a.push('irrigate ' + fmt(o.irr / 10000, 3) + ' ha in ' + o.nIrr + ' area' + (o.nIrr > 1 ? 's' : '')); if (o.nNo) a.push('excluded ' + fmt(o.noirr) + ' m²');
    if (o.nGh) a.push(o.nGh + ' greenhouse' + (o.nGh > 1 ? 's' : '') + ' ' + fmt(o.gh) + ' m²'); if (o.nBed) a.push(o.nBed + ' bed' + (o.nBed > 1 ? 's' : '') + ' ' + fmt(o.bed) + ' m²');
    if (o.plant) a.push(o.plant + ' plants'); if (o.trap) a.push(o.trap + ' traps');
    if (o.nPipe) a.push('pipes: ' + ['main', 'sub', 'lat'].filter(k => o.pipes[k] > 0).map(k => ({ main: 'mainline', sub: 'submain', lat: 'laterals' }[k]) + ' ' + fmt(o.pipes[k]) + ' m').join(', '));
    const fit = ['valve', 'pump', 'filter', 'tank'].filter(k => o[k]).map(k => o[k] + ' ' + k + (o[k] > 1 ? 's' : '')); if (fit.length) a.push(fit.join(', '));
    return a.join(' · ');
  }
  // ------------------------------------------------------------------ the mouse: add, drag and type
  function scr(e) { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * CW / r.width, y: (e.clientY - r.top) * CH / r.height }; }
  function at(e) { const q = scr(e); return { x: V.x + q.x / V.z, y: V.y + q.y / V.z }; }
  function zoomAt(f, sx, sy) { const nz = Math.max(0.1, Math.min(12, V.z * f)); if (sx == null) { sx = CW / 2; sy = CH / 2; } const wx = V.x + sx / V.z, wy = V.y + sy / V.z; V.z = nz; V.x = wx - sx / nz; V.y = wy - sy / nz; closeEdit(); draw(); }
  function fitView() { const P = S.pts.concat(S.src ? [S.src] : []); if (P.length < 2) { V.z = 1; V.x = 0; V.y = 0; draw(); return; } const xs = P.map(p => p.x), ys = P.map(p => p.y), a = Math.min(...xs), b = Math.max(...xs), c2 = Math.min(...ys), d = Math.max(...ys); V.z = Math.max(0.1, Math.min(12, Math.min((CW - 80) / Math.max(1, b - a), (CH - 80) / Math.max(1, d - c2)))); V.x = (a + b) / 2 - CW / 2 / V.z; V.y = (c2 + d) / 2 - CH / 2 / V.z; closeEdit(); draw(); }
  function hit(p) {
    const z = V.z; for (let i = 0; i < S.pts.length; i++) if (len(S.pts[i], p) < 9 / z) return { t: 'pt', i };
    if (S.src && len(S.src, p) < 12 / z) return { t: 'src' };
    const g = geom(); if (g && S.src && len(g.inl, p) < 9 / z) return { t: 'inlet' };
    if (S.pts.length > 1) for (let i = 0; i < S.pts.length; i++) { if (S.pts.length < 3 && i === S.pts.length - 1) continue; const [lx, ly] = sideLab(i); if (Math.abs(lx - p.x) < 26 / z && Math.abs(ly - p.y) < 11 / z) return { t: 'side', i }; }
    return null;
  }
  function wire() {
    cv.addEventListener('pointermove', e => {
      if (panning) { const q = scr(e); V.x = panning.vx - (q.x - panning.x) / V.z; V.y = panning.vy - (q.y - panning.y) / V.z; draw(); return; }
      const p = at(e); cursor = cadOn() ? SketchCAD.track(p, e) : p;
      if (drag) { const q = { x: snap(p.x), y: snap(p.y) }; if (drag.t === 'pt') S.pts[drag.i] = q; else if (drag.t === 'src') S.src = q; else if (drag.t === 'inlet') S.inlet = nearestOnEdge(p).p; }
      else { hover = (S.mode === 'pan' || cadOn()) ? null : hit(p); cv.style.cursor = S.mode === 'pan' ? 'grab' : hover ? (hover.t === 'side' ? 'text' : 'move') : 'crosshair'; }
      draw();
    });
    cv.addEventListener('pointerleave', () => { cursor = null; hover = null; draw(); });
    cv.addEventListener('pointerdown', e => {
      if (S.mode === 'pan' || e.button === 1 || e.button === 2 || e.shiftKey) { const q = scr(e); panning = { x: q.x, y: q.y, vx: V.x, vy: V.y }; cv.setPointerCapture(e.pointerId); cv.style.cursor = 'grabbing'; e.preventDefault(); return; }
      if (cadOn()) { if (e.button === 0) { SketchCAD.down(at(e), e); try { cv.setPointerCapture(e.pointerId); } catch (x) { } } return; }
      const p = at(e), h = hit(p); closeEdit();
      if (h && h.t === 'side') { openEdit(h.i); return; }
      if (h && h.t !== 'side') { pushH(); drag = h; cv.setPointerCapture(e.pointerId); return; }
      const q = { x: snap(p.x), y: snap(p.y) };
      if (OBJ[S.mode]) { objClick(q); draw(); return; }
      pushH();
      if (S.mode === 'src') { S.src = q; S.inlet = null; }
      else if (S.mode === 'inlet') { if (S.pts.length > 2) S.inlet = nearestOnEdge(p).p; }
      else { if (S.pts.length > 2) { const ne = nearestOnEdge(p); if (ne.d < 10) { S.pts.splice(ne.i + 1, 0, q); draw(); return; } } S.pts.push(q); S.inlet = null; }
      draw();
    });
    cv.addEventListener('pointerup', () => { if (cadOn()) SketchCAD.up(); drag = null; if (panning) { panning = null; cv.style.cursor = S.mode === 'pan' ? 'grab' : 'crosshair'; } draw(); });
    cv.addEventListener('wheel', e => { e.preventDefault(); const q = scr(e); zoomAt(e.deltaY < 0 ? 1.2 : 1 / 1.2, q.x, q.y); }, { passive: false });
    cv.addEventListener('contextmenu', e => e.preventDefault());
    cv.addEventListener('dblclick', e => { if (cadOn()) { SketchCAD.dbl(); return; } if (Date.now() - lastFin < 600) return; if (S.cur) { S.cur.pts.pop(); finishCur(); return; } if (OBJ[S.mode] == null) { /* corner removal below */ } else { const k = objAt(at(e)); if (k >= 0) { pushH(); S.objs.splice(k, 1); draw(); info(); } return; } const h = hit(at(e)); if (h && h.t === 'pt' && S.pts.length > 3) { S.pts.splice(h.i, 1); S.inlet = null; draw(); } });
  }
  // type the exact length of a side: the second corner moves along the side
  function openEdit(i) {
    const a = S.pts[i], b = S.pts[(i + 1) % S.pts.length], r = cv.getBoundingClientRect(), host = cv.parentNode;
    edit = document.createElement('div'); edit.className = 'skEdit';
    edit.innerHTML = '<input type="number" step="any" min="0.1" value="' + fmt(m(len(a, b)), 1) + '"> m <button class="btn">Set</button>';
    host.style.position = 'relative'; host.appendChild(edit);
    const sx = r.width / CW, mid = toScr({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }); edit.style.left = Math.max(0, mid.x * sx - 70) + 'px'; edit.style.top = (mid.y * sx + 12) + 'px';
    const inp = edit.querySelector('input'), go = () => { const v = parseFloat(inp.value); if (isFinite(v) && v > 0) { const d = len(a, b) || 1, k = px(v) / d, nb = { x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k }; if (false) { const ns = SC.find(s => s >= S.scale * Math.max(nb.x / CW, nb.y / CH, 1) * 1.1) || 100; const f = S.scale / ns; S.scale = ns; S.pts = S.pts.map(p => ({ x: p.x * f, y: p.y * f })); if (S.src) S.src = { x: S.src.x * f, y: S.src.y * f }; const sel = document.getElementById('skScale'); if (sel) sel.value = ns; return openAfter(i, v); } S.pts[(i + 1) % S.pts.length] = nb; S.inlet = null; } closeEdit(); draw(); };
    edit.querySelector('button').onclick = go; inp.addEventListener('keydown', e => { if (e.key === 'Enter') go(); if (e.key === 'Escape') closeEdit(); }); setTimeout(() => { inp.focus(); inp.select(); }, 10);
  }
  function openAfter(i, v) { closeEdit(); openEdit(i); const inp = edit && edit.querySelector('input'); if (inp) { inp.value = v; edit.querySelector('button').click(); } }
  function closeEdit() { if (edit) { edit.remove(); edit = null; } }

  // ------------------------------------------------------------------ the questions, step by step
  const STEPS = ['Field', 'Water', 'Crop', 'Soil', 'System', 'Running', 'Summary'];
  const opt = (v, l, cur) => '<option value="' + esc(v) + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + esc(l) + '</option>';
  const num = (id, label, v, unit, st, note) => '<div class="pr"><label for="' + id + '">' + label + '</label><div class="skin"><input type="number" id="' + id + '" value="' + v + '" step="' + (st || 'any') + '"> <span>' + unit + '</span></div>' + (note ? '<div class="pnote">' + note + '</div>' : '') + '</div>';
  const sel = (id, label, opts, note) => '<div class="pr"><label for="' + id + '">' + label + '</label><select id="' + id + '">' + opts + '</select>' + (note ? '<div class="pnote">' + note + '</div>' : '') + '</div>';
  function stepHtml() {
    const s = S.step, L = LIST || { crops: [], soils: [] };
    if (s === 0) return '<h4>1. Your field</h4><p class="pnote">Draw the corners on the grid, or give the size and make a rectangle. Drag any corner to move it; click a side length to type it exactly; double-click a corner to remove it.</p>' +
      num('qL', 'Field length', S.L, 'm') + num('qW', 'Field width', S.Wd, 'm') + '<button class="btn" id="qRect">Make a rectangle of this size</button>' +
      num('qSlope', 'Ground slope', S.slope, '%', 0.05, 'Fall of the ground per 100 m.') + sel('qSlopeDir', 'The ground falls', opt('run', 'along the run (the length of the laterals or furrows)', S.slopeDir) + opt('across', 'across the run', S.slopeDir) + opt('level', 'nowhere: it is level', S.slopeDir));
    if (s === 1) return '<h4>2. The water</h4><p class="pnote">Choose "Water source" above the grid and click where the water is; drag the yellow inlet along the edge of the field to where the pipe or the canal enters.</p>' +
      sel('qSrc', 'Where does the water come from?', opt('well', 'a well', S.srcType) + opt('borehole', 'a borehole', S.srcType) + opt('canal', 'a canal', S.srcType) + opt('river', 'a river or stream', S.srcType) + opt('tank', 'a pond or a tank', S.srcType)) +
      num('qLift', 'How high must the water be lifted to the field?', S.lift, 'm', 0.5, 'From the water level to the field surface.') + num('qSup', 'How much water can the source give?', S.supply, 'L/s', 0.5, 'The pump or the canal share; 1 L/s = 3.6 m³/h.') + num('qHrs', 'How many hours a day can you irrigate?', S.hours, 'h', 0.5);
    if (s === 2) return '<h4>3. The crop</h4>' + sel('qCrop', 'Which crop will you grow?', L.crops.map(q => opt(q[0], q[1], S.crop)).join('')) +
      num('qRow', 'Distance between the rows', S.row, 'm', 0.05, 'Drip laterals follow the rows; furrows are spaced at the rows.') + num('qPlant', 'Distance between plants in a row', S.plant, 'm', 0.05, 'Drip emitters are spaced at the plants (or closer for a continuous wet strip).');
    if (s === 3) return '<h4>4. The soil</h4>' + sel('qSoil', 'What is the soil of the field?', L.soils.map(q => opt(q[0], q[1], S.soil)).join(''), 'The soil decides the intake, the water it holds and the wetted bulb.') +
      sel('qPan', 'Is there a hard or compact layer below the topsoil?', opt('no', 'no', S.pan ? 'yes' : 'no') + opt('yes', 'yes', S.pan ? 'yes' : 'no'), 'A compact layer lowers the rate the soil accepts (sprinklers).');
    if (s === 4) return '<h4>5. The irrigation system and the pipes</h4>' +
      sel('qSys', 'Which system?', opt('sid:border', 'Surface: border strips', S.sys + ':' + S.sub) + opt('sid:furrow', 'Surface: furrows', S.sys + ':' + S.sub) + opt('sid:basin', 'Surface: basins', S.sys + ':' + S.sub) + opt('drip:', 'Drip', S.sys === 'drip' ? 'drip:' : '') + opt('spr:', 'Sprinklers', S.sys === 'spr' ? 'spr:' : '')) +
      sel('qDir', 'Run the laterals (or furrows)', opt('length', 'along the length of the field', S.dir) + opt('across', 'across the field', S.dir), 'Longer laterals need fewer pipes but lose more pressure.') +
      (S.sys === 'drip' ? sel('qDep', 'Where do the laterals lie?', [[0, 'on the surface'], [15, 'buried 15 cm'], [25, 'buried 25 cm'], [45, 'buried 45 cm'], [55, 'buried 55 cm']].map(q => opt(q[0], q[1], S.dep)).join('')) + sel('qKind', 'Emitter', [['inline', 'inline emitters'], ['online', 'online emitters'], ['tape', 'drip tape'], ['pc', 'pressure-compensating']].map(q => opt(q[0], q[1], S.kind)).join('')) : '') +
      (S.sys === 'spr' ? sel('qSprSys', 'Sprinkler system', [['solid', 'solid-set'], ['hand', 'hand-move'], ['pivot', 'center pivot'], ['linear', 'linear-move'], ['gun', 'traveling gun']].map(q => opt(q[0], q[1], S.sprSys)).join('')) + sel('qSprType', 'Sprinkler', [['impact', 'impact sprinkler'], ['spray', 'rotating spray'], ['micro', 'micro-sprinkler'], ['gun', 'big gun']].map(q => opt(q[0], q[1], S.sprType)).join('')) + num('qSs', 'Spacing along the lateral', S.sprSs, 'm', 0.5) + num('qSl', 'Spacing between laterals', S.sprSl, 'm', 0.5) : '');
    if (s === 5) return '<h4>6. How you will run it</h4>' + (S.sys === 'drip' ? num('qIntv', 'Irrigate every', S.intv, 'days', 1) : '') +
      sel('qAuto', 'Who opens the valves?', opt('no', 'the farmer, on the predicted dates', S.auto ? 'yes' : 'no') + opt('yes', 'an automatic controller with the soil sensor', S.auto ? 'yes' : 'no')) + '<p class="pnote">The dates come from the soil sensor and the trigger in Properties; the design decides the depth and the time of each irrigation.</p>';
    return '<h4>7. Summary</h4><div id="skSum">' + summary() + '</div>';
  }
  function summary() {
    const g = geom(); if (!g) return pipeHtml() + '<p class="pnote">Draw the field first.</p>';
    const L = LIST || { crops: [], soils: [] }, cn = (L.crops.find(q => q[0] === S.crop) || [0, S.crop])[1], sn = (L.soils.find(q => q[0] === S.soil) || [0, S.soil])[1];
    const sysN = S.sys === 'sid' ? 'Surface irrigation: ' + ({ border: 'border strips', furrow: 'furrows', basin: 'basins' }[S.sub]) : S.sys === 'drip' ? 'Drip, laterals ' + (S.dep ? 'buried ' + S.dep + ' cm' : 'on the surface') : 'Sprinklers (' + S.sprSys + ', ' + S.sprType + ')';
    const nLat = S.sys === 'drip' ? Math.max(1, Math.floor(g.wid / S.row)) : S.sys === 'spr' ? Math.max(1, Math.floor(g.wid / S.sprSl)) : 0;
    const rows = [['Field', fmt(g.area / 10000, 2) + ' ha, run ' + fmt(g.run) + ' m × width ' + fmt(g.wid) + ' m, slope ' + fmt(S.slopeDir === 'level' ? 0 : S.slope, 2) + ' %'], ['Water', S.srcType + ', lift ' + fmt(S.lift, 1) + ' m, ' + fmt(S.supply, 1) + ' L/s, ' + fmt(S.hours, 1) + ' h a day'], ['Mainline', S.objs.some(q => q.t === 'main') ? fmt(pipeHandOff().Lm) + ' m drawn, \u00D8 ' + pipeHandOff().Dm + ' mm' : S.src ? fmt(g.main) + ' m from the source to the inlet' : 'place the water source'], ['Crop', cn + ', rows ' + fmt(S.row, 2) + ' m, plants ' + fmt(S.plant, 2) + ' m'], ['Soil', sn + (S.pan ? ', compact layer below' : '')], ['System', sysN], ['Layout', (S.sys === 'sid' ? 'run' : 'laterals') + ' ' + fmt(g.run) + ' m ' + (S.dir === 'length' ? 'along the length' : 'across the field') + (nLat ? ', about ' + nLat + ' laterals' : '')]];
    if (S.objs.length) rows.push(['Drawn on the field', objSummary()]);
    return '<table class="tbl" style="width:100%">' + rows.map(r => '<tr><td>' + r[0] + '</td><td><b>' + esc(r[1]) + '</b></td></tr>').join('') + '</table>' + pipeHtml() + '<p class="pnote">Press <b>Turn the sketch into the design</b>: the design layer opens with these inputs; check them and press Run simulation.</p>';
  }
  function readStep() {
    const v = id => { const e = document.getElementById(id); return e ? e.value : null; }, n = (id, d) => { const x = parseFloat(v(id)); return isFinite(x) ? x : d; };
    if (v('qL') != null) { S.L = Math.max(1, n('qL', S.L)); S.Wd = Math.max(1, n('qW', S.Wd)); S.slope = Math.max(0, n('qSlope', S.slope)); S.slopeDir = v('qSlopeDir'); }
    if (v('qSrc') != null) { S.srcType = v('qSrc'); S.lift = Math.max(0, n('qLift', S.lift)); S.supply = Math.max(0.1, n('qSup', S.supply)); S.hours = Math.max(1, Math.min(24, n('qHrs', S.hours))); }
    if (v('qCrop') != null) { S.crop = v('qCrop'); S.row = Math.max(0.05, n('qRow', S.row)); S.plant = Math.max(0.03, n('qPlant', S.plant)); }
    if (v('qSoil') != null) { S.soil = v('qSoil'); S.pan = v('qPan') === 'yes'; }
    if (v('qSys') != null) { const [a, b] = v('qSys').split(':'); S.sys = a; if (b) S.sub = b; S.dir = v('qDir') || S.dir; if (v('qDep') != null) { S.dep = +v('qDep'); S.kind = v('qKind'); } if (v('qSprSys') != null) { S.sprSys = v('qSprSys'); S.sprType = v('qSprType'); S.sprSs = Math.max(1, n('qSs', S.sprSs)); S.sprSl = Math.max(1, n('qSl', S.sprSl)); } }
    if (v('qAuto') != null) { S.auto = v('qAuto') === 'yes'; if (v('qIntv') != null) S.intv = Math.max(1, Math.round(n('qIntv', S.intv))); }
  }
  function showStep() {
    const host = document.getElementById('skQ'); if (!host) return; host.innerHTML = stepHtml();
    document.querySelectorAll('#skSteps button').forEach((b, i) => b.classList.toggle('on', i === S.step));
    host.querySelectorAll('input,select').forEach(el => el.addEventListener('change', () => { readStep(); if (el.id === 'qSys') showStep(); if (el.id === 'qCrop') { const r = (LIST.rows || {})[S.crop]; if (r) { S.row = r; const q = document.getElementById('qRow'); if (q) q.value = r; } } draw(); }));
    const rb = document.getElementById('qRect'); if (rb) rb.onclick = () => { readStep(); rectangle(); const s2 = document.getElementById('skScale'); if (s2) s2.value = S.scale; draw(); };
    document.getElementById('skBack').disabled = S.step === 0; document.getElementById('skNext').textContent = S.step === STEPS.length - 1 ? 'Back to the start' : 'Next question';
    draw();
  }

  // what the CAD tools may use of the sketch
  const CADAPI = { get S() { return S; }, V, get CW() { return CW; }, get CH() { return CH; }, GRID, m, px, get cv() { return cv; }, draw: () => draw(), pushH: () => pushH(), undo: () => undo(), info: () => info(), finishCur: () => { if (S.cur) finishCur(); } };
  // the drawing area takes all the room the window offers (width of its column, height of the window)
  function fitCanvas(keep) {
    if (!cv) return; const box = cv.parentNode, w = Math.floor(box.clientWidth); if (w < 200) return;
    const top = box.getBoundingClientRect().top, h = Math.max(340, Math.min(Math.round(w * 0.9), Math.floor(window.innerHeight - top - 150)));
    if (w === CW && h === CH) return; const ow = CW, oh = CH; CW = w; CH = h; cv.width = CW * 2; cv.height = CH * 2;
    if (keep) { V.x -= (CW - ow) / 2 / V.z; V.y -= (CH - oh) / 2 / V.z; } draw();
  }
  // ------------------------------------------------------------------ the window
  function open() {
    LIST = E.json("({crops:Object.keys(CROPS).map(function(k){return [k,CROPS[k].label]}),soils:DATA.soils.map(function(k){return [k,DATA.soil_labels[k]]}),crop:state.crop,soil:state.soil,rows:Object.fromEntries(Object.keys(CROPS).map(function(k){var r=(typeof IRCROP!=='undefined'&&IRCROP[k])||{};return [k,Math.max(0.2,r.row||0.75)]})),sys:SID.sys,lift:IRX.lift,Qs:DRP.Qs})") || { crops: [], soils: [], rows: {} };
    if (!S.crop) { S.crop = LIST.crop; S.row = (LIST.rows || {})[S.crop] || S.row; } if (!S.soil) S.soil = LIST.soil;
    UI.modal({ title: 'Field sketch to design', icon: 'pipe', width: 'min(1120px,97vw)', html:
      '<div class="skwrap"><div class="skleft"><div class="skbar"><div class="seg" id="skMode"><button data-m="field"' + (S.mode === 'field' ? ' class="on"' : '') + '>Field corners</button><button data-m="src"' + (S.mode === 'src' ? ' class="on"' : '') + '>Water source</button><button data-m="inlet"' + (S.mode === 'inlet' ? ' class="on"' : '') + '>Inlet</button><button data-m="pan"' + (S.mode === 'pan' ? ' class="on"' : '') + ' title="Move the drawing (also: right button, middle button or Shift and drag)">&#9995; Hand</button></div>' +
      '<button class="btn" id="skZin" title="Zoom in (mouse wheel up)">&#43;</button><button class="btn" id="skZout" title="Zoom out (mouse wheel down)">&minus;</button><button class="btn" id="skFit" title="Show the whole field">Fit</button><button class="btn pri" id="skMap" title="Find the farm on the satellite map, demarcate it and compute the vegetation and water indices">&#127757; Locate on the map</button>' +
      '<button class="btn" id="skUndo">Undo corner</button><button class="btn" id="skClear">Clear</button><label id="skPdL" style="display:none">Pipe diameter <select id="skPd"></select> mm</label><label>Grid square <select id="skScale">' + SC.map(v => '<option value="' + v + '"' + (v === S.scale ? ' selected' : '') + '>' + v + ' m</option>').join('') + '</select></label></div>' +
      '<div class="skcv"><canvas id="skCv" width="' + CW * 2 + '" height="' + CH * 2 + '"></canvas></div><div id="skCadHost"></div><div id="skInfo" class="skinfo"></div></div>' +
      '<div class="skright"><div class="seg skst" id="skSteps">' + STEPS.map((s, i) => '<button data-s="' + i + '">' + (i + 1) + '. ' + s + '</button>').join('') + '</div><div id="skQ" class="skq"></div>' +
      '<div class="skbtns"><button class="btn" id="skBack">Back</button><button class="btn" id="skNext">Next question</button></div></div></div>',
      full: true, buttons: [{ label: 'Turn the sketch into the design', pri: true, act: () => apply() }, { label: 'Close' }] });
    cv = document.getElementById('skCv'); fitCanvas(false); { let t = 0; const rs = () => { clearTimeout(t); t = setTimeout(() => { if (!document.body.contains(cv)) { window.removeEventListener('resize', rs); return; } fitCanvas(true); }, 60); }; window.addEventListener('resize', rs); if (window.ResizeObserver) new ResizeObserver(rs).observe(cv.parentNode); } wire(); if (window.SketchCAD) { SketchCAD.init(CADAPI); SketchCAD.mount(document.getElementById('skCadHost')); } setTimeout(() => { const P2 = S.pts.concat(S.src ? [S.src] : []); if (P2.some(p => p.x < 0 || p.y < 0 || p.x > CW || p.y > CH)) fitView(); }, 0);
    document.getElementById('skZin').onclick = () => zoomAt(1.25); document.getElementById('skZout').onclick = () => zoomAt(1 / 1.25); document.getElementById('skFit').onclick = fitView;
    document.getElementById('skMap').onclick = () => { if (typeof FieldMap !== 'undefined') FieldMap.open(); };
    { const bar = document.getElementById('skMode'); Object.keys(OBJ).forEach(k => { const b = document.createElement('button'); b.dataset.m = k; b.textContent = OBJ[k][0].split(' /')[0]; b.title = OBJ[k][0] + (OBJ[k][2] === 'rect' ? ': click two opposite corners' : OBJ[k][2] === 'poly' ? ': click the corners, double-click or click the first corner to finish' : OBJ[k][2] === 'line' ? ': click the points of the pipe along its route; click its last point again (the dead end), click any other pipe, double-click or press Enter to finish; the diameter is chosen in the list that appears' : ': click to place'); b.style.borderBottom = '3px solid ' + OBJ[k][1]; if (S.mode === k) b.className = 'on'; bar.appendChild(b); }); bar.style.flexWrap = 'wrap'; }
    pdUpdate();
    if (!window.__skKeys) { window.__skKeys = true; document.addEventListener('keydown', e => { if (!document.getElementById('skCv')) return; if (/INPUT|SELECT|TEXTAREA/.test((e.target || {}).tagName || '')) return; if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 'z') { e.preventDefault(); Sketch.undo(); } else if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) { e.preventDefault(); Sketch.redo(); } else if (e.key === 'Enter') Sketch.finish(); else if (e.key === 'Escape') Sketch.cancel(); }); }
    document.getElementById('skMode').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; S.mode = b.dataset.m; S.rect = null; if (S.cur) finishCur(); document.querySelectorAll('#skMode button').forEach(x => x.classList.toggle('on', x === b)); pdUpdate(); if (window.SketchCAD) SketchCAD.sync(); draw(); });
    document.getElementById('skUndo').onclick = undo; { const b = document.createElement('button'); b.className = 'btn'; b.id = 'skRedo'; b.textContent = 'Redo'; b.title = 'Ctrl+Y'; document.getElementById('skUndo').after(b); b.onclick = redo; document.getElementById('skUndo').textContent = 'Undo'; document.getElementById('skUndo').title = 'Ctrl+Z'; }
    document.getElementById('skClear').onclick = () => { pushH(); S.cad = []; if (window.SketchCAD) SketchCAD.reset(); S.objs = []; S.cur = null; S.rect = null; S.pts = []; S.src = null; S.inlet = null; S.geo = null; V.z = 1; V.x = V.y = 0; draw(); };
    document.getElementById('skScale').onchange = e => { const ns = +e.target.value, f = S.scale / ns; S.scale = ns; S.pts = S.pts.map(p => ({ x: p.x * f, y: p.y * f })); if (S.src) S.src = { x: S.src.x * f, y: S.src.y * f }; S.inlet = null; draw(); };
    document.getElementById('skSteps').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; readStep(); S.step = +b.dataset.s; showStep(); });
    document.getElementById('skBack').onclick = () => { readStep(); S.step = Math.max(0, S.step - 1); showStep(); };
    document.getElementById('skNext').onclick = () => { readStep(); S.step = S.step === STEPS.length - 1 ? 0 : S.step + 1; showStep(); };
    showStep();
  }
  // the diameter list appears while a pipe tool is chosen; a new diameter is applied to the pipes of that kind already drawn
  function pdUpdate() {
    const L = document.getElementById('skPdL'), sel = document.getElementById('skPd'); if (!L || !sel) return; const k = S.mode, on = OBJ[k] && OBJ[k][2] === 'line'; L.style.display = on ? '' : 'none'; if (!on) return;
    sel.innerHTML = PIPE_OPTS[k].map(v => '<option value="' + v + '"' + (v === (S.pd[k] || PIPE_D[k]) ? ' selected' : '') + '>' + v + '</option>').join('');
    sel.onchange = () => { S.pd[k] = +sel.value; S.objs.forEach(q => { if (q.t === k) q.dia = +sel.value; }); draw(); info(); };
  }
  // the pipe network as drawn: length, diameter, flow, speed and friction loss of every pipe (Hazen-Williams), and the pump head it asks for
  function pipeReport() {
    const g = geom(), pipes = S.objs.filter(q => OBJ[q.t][2] === 'line'); if (!pipes.length) return null;
    const Q = Math.max(0.1, S.supply), nl = g ? Math.max(1, Math.floor(g.wid / (S.sys === 'spr' ? S.sprSl : S.row))) : (pipes.filter(q => q.t === 'lat').length || 1), rows = []; let hfMain = 0, hfSub = 0, hfLat = 0;
    const NAME = { main: 'Mainline', sub: 'Submain', lat: 'Lateral' }, ord = { main: 0, sub: 1, lat: 2 };
    pipes.slice().sort((a, b) => ord[a.t] - ord[b.t]).forEach(q => {
      const D = q.dia || PIPE_D[q.t], L = lineLen(q.pts), Qp = q.t === 'lat' ? Q / nl : Q, v = Qp / 1000 / (Math.PI * D * D / 4e6), hf0 = 10.67 * L * Math.pow(Qp / 1000, 1.852) / (Math.pow(PIPE_C[q.t], 1.852) * Math.pow(D / 1000, 4.871)), hf = q.t === 'main' ? hf0 : hf0 * 0.4;
      if (q.t === 'main') hfMain += hf; else if (q.t === 'sub') hfSub += hf; else hfLat = Math.max(hfLat, hf);
      const vmax = q.t === 'lat' ? 2 : 1.5, st = v > vmax ? 'too fast' : v < 0.3 ? 'very slow' : 'good';
      rows.push([NAME[q.t], D, L, Qp, v, hf, st, v > vmax]);
    });
    const head = (S.sys === 'spr' ? 30 : 10) + 9, TDH = S.lift + hfMain + hfSub + hfLat + head, kW = 9.81 * Q / 1000 * TDH / 0.65;
    return { rows, hfMain, hfSub, hfLat, TDH, kW, head, bad: rows.some(r => r[7]), Q };
  }
  function pipeHtml() {
    const R = pipeReport(); if (!R) return '';
    return '<p class="pnote"><b>Pipe network</b> (flow ' + fmt(R.Q, 1) + ' L/s; Hazen-Williams, C = 140 for the main and submain, 150 for the laterals; every lateral of the layout takes an equal share of the flow; a pipe marked too fast needs a wider diameter)</p><table class="tbl" style="width:100%"><tr><th>Pipe</th><th>&Oslash; mm</th><th>Length m</th><th>Flow L/s</th><th>Speed m/s</th><th>Loss m</th><th>Check</th></tr>' +
      R.rows.map(r => '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td><td>' + fmt(r[2]) + '</td><td>' + fmt(r[3], 2) + '</td><td' + (r[7] ? ' style="color:#B3261E"' : '') + '>' + fmt(r[4], 2) + '</td><td>' + fmt(r[5], 2) + '</td><td>' + esc(r[6]) + '</td></tr>').join('') + '</table>' +
      '<p class="pnote">Pump head asked by this network: lift ' + fmt(S.lift, 1) + ' m + friction ' + fmt(R.hfMain + R.hfSub + R.hfLat, 1) + ' m + working head and fittings ' + fmt(R.head) + ' m = <b>' + fmt(R.TDH, 1) + ' m</b>, about <b>' + fmt(R.kW, 1) + ' kW</b> at 65 % efficiency.' + (R.bad ? ' <span style="color:#B3261E">A pipe is too narrow for the flow: choose a wider diameter.</span>' : '') + '</p>';
  }
  // what the drawn pipes hand to the design: mainline length, mainline and submain diameter, lateral diameter
  function pipeHandOff() {
    const o = { Lm: 0, Dm: 0, Dsm: 0, Dl: 0, js: '' }, P = S.objs.filter(q => OBJ[q.t][2] === 'line'), big = k => { const a = P.filter(q => q.t === k).sort((x, y) => lineLen(y.pts) - lineLen(x.pts))[0]; return a ? a.dia || PIPE_D[k] : 0; };
    o.Lm = Math.round(P.filter(q => q.t === 'main').reduce((a, q) => a + lineLen(q.pts), 0)); o.Dm = big('main'); o.Dsm = big('sub'); o.Dl = big('lat');
    o.js = 'IRX.Dm0=' + o.Dm + ';IRX.Dsm0=' + o.Dsm + ';' + (o.Dl && S.sys === 'drip' ? 'DRP.D=' + Math.max(8, Math.min(40, o.Dl)) + ';' : '');
    return o;
  }
  function apply() {
    readStep(); const g = geom(); if (!g) { UI.toast('Draw the field first (at least three corners)'); return false; }
    const cl = (v, a, b) => Math.max(a, Math.min(b, v)), ha = Math.max(0.0001, (S.objs.length ? irrArea() : g.area) / 10000), slope = S.slopeDir === 'level' ? 0 : S.slope, run = Math.round(g.run), wid = Math.round(g.wid), PH = pipeHandOff(), main = PH.Lm || Math.round(S.src ? g.main : 120);
    const st = {}; if (S.crop && S.crop !== LIST.crop) st.crop = S.crop; if (S.soil && S.soil !== LIST.soil) st.soil = S.soil;
    const id = S.sys, common = PH.js + 'IRX.lift=' + cl(S.lift, 0, 500) + ';IRX.Lm=' + cl(main, 0, 10000) + ';IRX.src=' + JSON.stringify(S.srcType === 'canal' || S.srcType === 'river' ? 'canal' : S.srcType === 'tank' ? 'tank' : 'well') + ';SPD.top=' + cl(S.hours, 1, 24) + ';SPD.pan=' + (S.pan ? 'true' : 'false') + ';if(window.__FARM)__FARM.auto=' + (S.auto ? 'true' : 'false') + ';';
    let js;
    if (id === 'sid') { st.method = 'M02_Surface'; js = "(function(){sidSys('" + S.sub + "');SID.L=" + cl(run, 5, 3000) + ";SID.Wf=" + cl(wid, 1, 5000) + ";SID.S=" + cl(slope, 0.001, 10) + ";SID.Qs=" + cl(S.supply, 0.5, 2000) + (S.sub === 'furrow' ? ";SID.w=" + cl(S.row < 0.5 ? 0.75 : S.row, 0.3, 2.5) : '') + ";SID.preset=null;SID.autoQ=true;" + common + "})()"; }
    else if (id === 'drip') { const mm = { 15: 'M04_Drip10-20cm', 25: 'M06_Drip20-30cm', 45: 'M09_Drip40-50cm', 55: 'M10_Drip50-60cm' }[S.dep]; if (mm) st.method = mm;
      js = "(function(){DRP.LL=" + cl(run, 1, 1000) + ";DRP.Sl=" + cl(S.row, 0.1, 10) + ";DRP.Se=" + cl(S.plant, 0.05, 5) + ";DRP.Af=" + cl(+ha.toFixed(4), 0.0001, 10000) + ";DRP.Qs=" + cl(S.supply, 0.1, 2000) + ";DRP.intv=" + cl(S.intv, 1, 60) + ";DRP.kind=" + JSON.stringify(S.kind) + ";" + (S.dep ? "DRP.surf=false;DRP.dep=" + S.dep : "DRP.surf=true") + ";IRX.fd.drip={on:true,L:" + run + ",W:" + wid + "};" + common + "})()"; }
    else { st.method = 'M01_Overhead'; js = "(function(){SPR.Af=" + cl(+ha.toFixed(4), 0.001, 10000) + ";SPR.S=" + cl(slope, 0, 60) + ";SPR.Qs=" + cl(S.supply, 0.1, 5000) + ";SPR.Ss=" + cl(S.sprSs, 1, 120) + ";SPR.Sl=" + cl(S.sprSl, 1, 120) + ";SPR.type=" + JSON.stringify(S.sprType) + ";SPD.sys=" + JSON.stringify(S.sprSys) + ";IRX.LLs=" + cl(run, 5, 2000) + ";IRX.fd.spr={on:true,L:" + run + ",W:" + wid + "};" + common + "})()"; }
    st.areaHa = +ha.toFixed(4);
    if (Object.keys(st).length) E.set(st);
    // the crop and soil settle first (they set their own defaults), then the answers of the sketch are written over them
    const put = () => { E.ev(js); E.ev("window.DESIGN_RUN&&(DESIGN_RUN['" + id + "'].on=false,DESIGN_RUN['" + id + "'].why='field sketch applied')"); };
    put(); setTimeout(put, 400); setTimeout(put, 1200);
    UI.log('Field sketch applied to ' + Layers.nameOf(id) + ': ' + ha.toFixed(2) + ' ha, run ' + run + ' m, width ' + wid + ' m, mainline ' + main + ' m');
    Layers.open(id); UI.toast('Sketch applied: check the inputs and press Run simulation'); return true;
  }
  // the three systems side by side on the present field and soil
  function compare() {
    const R = E.json("(function(){var a=sidRun(),b=drRun(),c=spRun();return [['Surface (' + SID.sys + ')',a.Ea,a.Es,a.dp,a.ro,a.tco/60],['Drip',b.Ea,b.Es,b.dp,b.ev||0,b.t],['Sprinkler',c.Ea,c.Es,c.dp,c.ro,c.T/60]]})()");
    if (!R) { UI.toast('The designs are not ready yet'); return; }
    const p = v => (v * 100).toFixed(1) + ' %';
    UI.modal({ title: 'Irrigation systems compared on this field', icon: 'chart', width: 'min(640px,94vw)', html: '<table class="tbl" style="width:100%"><tr><th>System</th><th>Application efficiency</th><th>Root zone filled</th><th>Deep percolation</th><th>Runoff / evaporation</th><th>Time per irrigation</th></tr>' +
      R.map(r => '<tr><td>' + UI.esc(r[0]) + '</td><td><b>' + p(r[1]) + '</b></td><td>' + p(r[2]) + '</td><td>' + p(r[3]) + '</td><td>' + p(r[4]) + '</td><td>' + r[5].toFixed(1) + ' h</td></tr>').join('') + '</table><p class="pnote">Each system with the inputs it has now in its design layer, on the same soil, crop and trigger. Open a design layer to change them and run it.</p>' });
  }
  // the field in metres (x east, y down) for the map, and a field from the map
  function getMetres() { return S.pts.map(p => [m(p.x), m(p.y)]); }
  function setMetres(xy, geo, stay) {
    const xs = xy.map(p => p[0]), ys = xy.map(p => p[1]), wM = Math.max(...xs) - Math.min(...xs), hM = Math.max(...ys) - Math.min(...ys);
    S.scale = SC.find(v => wM * GRID / v <= CW - 140 && hM * GRID / v <= CH - 120) || 100;
    const cx = (Math.max(...xs) + Math.min(...xs)) / 2, cy = (Math.max(...ys) + Math.min(...ys)) / 2;
    S.pts = xy.map(p => ({ x: CW / 2 + 20 + px(p[0] - cx), y: CH / 2 + px(p[1] - cy) })); S.inlet = null; S.geo = geo ? Object.assign({}, geo, { offx: m(CW / 2 + 20) - cx, offy: m(CH / 2) - cy }) : null;
    const l = Math.min(...S.pts.map(p => p.x)); S.src = { x: Math.max(16, l - 60), y: CH / 2 }; V.z = 1; V.x = V.y = 0;
    const sel = document.getElementById('skScale'); if (sel) sel.value = S.scale; if (cv && document.body.contains(cv)) draw(); else if (!stay) open();
  }
  // where the drawing sits on the earth: east = m(x) - offx, north = -(m(y) - offy), in metres from (lat, lon)
  // the submain or head ditch: across the run at the inlet end, inside the field; on a field without a straight end, the edge that holds the inlet
  function submainSeg(g) {
    const along = (t, s2) => ({ x: s2 * g.ux - t * g.uy, y: s2 * g.uy + t * g.ux }), mid = (g.inl.x * g.ux + g.inl.y * g.uy), sEnd = mid - g.lo < g.hi - mid ? g.lo : g.hi, inw = sEnd === g.lo ? 1 : -1;
    const P = S.pts, e = nearestOnEdge(g.inl).i, a = P[e], b = P[(e + 1) % P.length], el = len(a, b) || 1, cosr = Math.abs(((b.x - a.x) * g.ux + (b.y - a.y) * g.uy) / el);
    if (cosr < 0.5) return { a, b, sEnd, inw, edge: true };   // the edge with the inlet runs across the laterals: the submain follows it
    const segs = clipSeg(along(g.wlo - 5, sEnd + inw * 2), along(g.whi + 5, sEnd + inw * 2)); if (segs.length) { const best = segs.sort((p, q) => len(q[0], q[1]) - len(p[0], p[1]))[0]; return { a: best[0], b: best[1], sEnd, inw }; }
    return { a, b, sEnd, inw, edge: true };
  }
  function setGeo(g) { S.geo = g; if (cv && document.body.contains(cv)) draw(); }
  function setAnswers(o) { Object.keys(o).forEach(k => { if (o[k] !== undefined) S[k] = o[k]; }); S.inlet = null; if (cv && document.body.contains(cv)) { draw(); try { showStep(); } catch (e) {} } }
  function setSrcMetres(e, n) { if (!S.geo) return; S.src = { x: px(e + S.geo.offx), y: px(-n + S.geo.offy) }; S.inlet = null; if (cv && document.body.contains(cv)) draw(); }
  // the irrigation layout of the sketch in metres east and north of the geographic origin, for the map
  function clipSeg(a, b) {
    const P = S.pts, ts = [0, 1], dx = b.x - a.x, dy = b.y - a.y;
    for (let i = 0; i < P.length; i++) { const p = P[i], q = P[(i + 1) % P.length], ex = q.x - p.x, ey = q.y - p.y, den = dx * ey - dy * ex; if (Math.abs(den) < 1e-9) continue;
      const t = ((p.x - a.x) * ey - (p.y - a.y) * ex) / den, u = ((p.x - a.x) * dy - (p.y - a.y) * dx) / den; if (t > 0 && t < 1 && u >= 0 && u <= 1) ts.push(t); }
    ts.sort((x, y) => x - y); const out = [];
    for (let i = 0; i + 1 < ts.length; i++) { const tm = (ts[i] + ts[i + 1]) / 2; if (ts[i + 1] - ts[i] > 1e-6 && inside(a.x + dx * tm, a.y + dy * tm)) out.push([{ x: a.x + dx * ts[i], y: a.y + dy * ts[i] }, { x: a.x + dx * ts[i + 1], y: a.y + dy * ts[i + 1] }]); }
    return out;
  }
  function layoutM() {
    const g = geom(); if (!g || !S.geo) return null; const G2 = S.geo, E2 = p => [m(p.x) - G2.offx, -(m(p.y) - G2.offy)];
    const sysS = S.sys === 'sid' ? S.sub : S.sys, along = (t, s2) => ({ x: s2 * g.ux - t * g.uy, y: s2 * g.uy + t * g.ux }), out = { lat: G2.lat, lon: G2.lon, sys: sysS, lines: [], pts: [] };
    const spM = sysS === 'drip' ? S.row : sysS === 'spr' ? S.sprSl : sysS === 'furrow' ? S.row : sysS === 'border' ? 10 : 20, sp = px(spM), n0 = Math.max(1, Math.ceil((g.whi - g.wlo) / sp)), k = Math.max(1, Math.ceil(n0 / 160));
    const kind = sysS === 'drip' ? 'lateral' : sysS === 'spr' ? 'sprinkler lateral' : sysS === 'furrow' ? 'furrow' : sysS === 'basin' ? 'basin' : 'border';
    for (let t = g.wlo + sp / 2; t < g.whi; t += sp * k) clipSeg(along(t, g.lo - 5), along(t, g.hi + 5)).forEach(sg => out.lines.push({ kind, pts: sg.map(E2) }));
    if (sysS === 'basin') { const nb = Math.max(1, Math.round(m(g.hi - g.lo) / 40)); for (let i = 1; i < nb; i++) { const s2 = g.lo + (g.hi - g.lo) * i / nb; clipSeg(along(g.wlo - 5, s2), along(g.whi + 5, s2)).forEach(sg => out.lines.push({ kind: 'basin', pts: sg.map(E2) })); } }
    if (sysS === 'spr') { const ss = px(S.sprSs), kk = Math.max(1, Math.ceil(n0 * (g.hi - g.lo) / ss / 1500)); for (let t = g.wlo + sp / 2; t < g.whi; t += sp * k) for (let s2 = g.lo + ss / 2; s2 < g.hi; s2 += ss * kk) { const q = along(t, s2); if (inside(q.x, q.y)) out.pts.push({ kind: 'sprinkler', p: E2(q), r: S.sprSs * 0.65 }); } }
    const sEnd = (g.inl.x * g.ux + g.inl.y * g.uy) - g.lo < g.hi - (g.inl.x * g.ux + g.inl.y * g.uy) ? g.lo : g.hi;
    { const SM = submainSeg(g); out.lines.push({ kind: S.sys === 'sid' ? 'head ditch' : 'submain', pts: [E2(SM.a), E2(SM.b)] }); }
    if (S.src) { out.lines.push({ kind: 'mainline', pts: [E2(S.src), E2(g.inl)] }); out.pts.push({ kind: 'source', p: E2(S.src), name: { well: 'well', borehole: 'borehole', canal: 'canal', river: 'river', tank: 'pond or tank' }[S.srcType] || 'source' }); }
    out.pts.push({ kind: 'inlet', p: E2(g.inl) }); out.spacing = spM * k; out.thinned = k > 1;
    out.label = (S.sys === 'sid' ? (S.sub === 'furrow' ? 'Furrows' : S.sub === 'basin' ? 'Basins' : 'Border strips') : sysS === 'drip' ? 'Drip laterals' : 'Sprinklers') + ' every ' + (spM * k).toFixed(spM * k < 10 ? 2 : 0) + ' m' + (k > 1 ? ' (one line of every ' + k + ' drawn)' : '');
    return out;
  }
  return { open, compare, undo, redo, finish: () => { if (S.cur) finishCur(); }, cancel: () => { S.cur = null; S.rect = null; draw(); }, objStats, irrArea, getMetres, setMetres, setGeo, setSrcMetres, setAnswers, layoutM, _S: S, _V: V };
})();
