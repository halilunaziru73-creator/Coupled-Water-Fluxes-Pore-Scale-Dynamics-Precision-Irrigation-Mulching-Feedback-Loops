/* SWAFL UI toolkit: icons, menus, modals, toast, message log, splitters. */
'use strict';
const UI = (() => {
  const P = {   // 24x24 stroke icons
    new: 'M6 3h8l4 4v14H6z M14 3v4h4', open: 'M3 7h6l2 2h10v10H3z', save: 'M5 3h12l3 3v15H5z M8 3v6h8V3 M8 21v-7h8v7',
    img: 'M3 5h18v14H3z M3 16l5-5 4 4 3-3 6 6 M15 9h.01', csv: 'M5 3h10l4 4v14H5z M8 12h8 M8 16h8 M12 10v8', print: 'M7 8V3h10v5 M5 8h14v9h-3v4H8v-4H5z',
    undo: 'M9 7L4 12l5 5 M4 12h10a6 6 0 010 8', redo: 'M15 7l5 5-5 5 M20 12H10a6 6 0 000 8', reset: 'M4 12a8 8 0 1114 5 M4 5v7h7',
    play: 'M7 4l13 8-13 8z', pause: 'M7 4h4v16H7z M14 4h4v16h-4z', restart: 'M5 5v14 M9 12l10-7v14z', pin: 'M12 3l4 5-2 4v3l-2 6-2-6v-3l-2-4z',
    refresh: 'M20 12a8 8 0 11-3-6 M20 4v6h-6', help: 'M12 3a9 9 0 100 18 9 9 0 000-18z M9.5 9.5a2.5 2.5 0 115 0c0 2-2.5 2-2.5 4 M12 17h.01',
    github: 'M9 19c-4 1-4-2-6-2 M15 22v-3.5c0-1 .1-1.4-.5-2 3-.3 6-1.5 6-6.5a5 5 0 00-1.4-3.5 4.6 4.6 0 00-.1-3.5s-1.2-.3-3.6 1.4a12 12 0 00-6.8 0C6.200 3.700 5 4 5 4a4.600 4.600 0 00-.1 3.500A5 5 0 003.500 11c0 5 3 6.200 6 6.500-.6.600-.6 1.200-.5 2V22',
    layers: 'M12 3l9 5-9 5-9-5z M3 13l9 5 9-5', tool: 'M14 6a4 4 0 005 5l-9 9a2 2 0 01-3-3l9-9a4 4 0 01-2-2z', chart: 'M4 20V4 M4 20h16 M8 16v-5 M12 16V8 M16 16v-8',
    drop: 'M12 3s6 6.500 6 11a6 6 0 01-12 0c0-4.500 6-11 6-11z', soil: 'M3 8h18 M3 13h18 M3 18h18 M7 5v3 M15 5v3', sun: 'M12 8a4 4 0 100 8 4 4 0 000-8z M12 2v3 M12 19v3 M2 12h3 M19 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2',
    pipe: 'M3 9h12a3 3 0 013 3v9 M3 9v6 M18 21h-3', sprinkler: 'M12 20v-8 M12 12l-5-5 M12 12l5-5 M12 12V4 M8 20h8', folder: 'M3 6h7l2 2h9v11H3z', info: 'M12 3a9 9 0 100 18 9 9 0 000-18z M12 11v6 M12 7.500h.01',
    gear: 'M12 9a3 3 0 100 6 3 3 0 000-6z M12 2v3 M12 19v3 M2 12h3 M19 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2', search: 'M11 4a7 7 0 100 14 7 7 0 000-14z M16 16l5 5',
    exit: 'M9 4H4v16h5 M16 8l4 4-4 4 M20 12H9', copy: 'M8 8h12v12H8z M4 4h12v3 M4 4v12h3', fit: 'M4 9V4h5 M20 9V4h-5 M4 15v5h5 M20 15v5h-5', doc: 'M6 3h9l4 4v14H6z M9 12h7 M9 16h7',
    run: 'M5 4l14 8-14 8z', field: 'M3 18l5-9 5 6 3-4 5 7z', book: 'M5 4h13v16H7a2 2 0 01-2-2z M5 18a2 2 0 012-2h11', key: 'M3 7h18v10H3z M7 11h.01 M11 11h.01 M15 11h.01 M8 14h8',
    bug: 'M9 7a3 3 0 016 0 M7 9h10v6a5 5 0 01-10 0z M3 11h4 M17 11h4 M3 17h4 M17 17h4', zoom: 'M11 4a7 7 0 100 14 7 7 0 000-14z M8 11h6 M11 8v6 M16 16l5 5', cloud: 'M7 18a4 4 0 010-8 5 5 0 019.500-1A4 4 0 0117 18z'
  };
  const icon = (n, cls) => '<svg class="' + (cls || 'ico') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="' + (P[n] || P.info) + '"/></svg>';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* ---- message log ---- */
  const logs = [];
  function log(msg, level) {
    const d = new Date(), t = [d.getHours(), d.getMinutes(), d.getSeconds()].map(x => String(x).padStart(2, '0')).join(':');
    logs.push({ t, msg, level: level || 'info' }); if (logs.length > 400) logs.shift();
    document.dispatchEvent(new CustomEvent('swafl-log'));
  }

  /* ---- toast ---- */
  function toast(msg) {
    let el = document.getElementById('toast'); if (el) el.remove();
    el = document.createElement('div'); el.id = 'toast'; el.textContent = msg; document.body.appendChild(el);
    setTimeout(() => el.remove(), 2600);
  }

  /* ---- menus: they stay on the screen, scroll when the window is small, open by hover, click or tap, work from the keyboard, and the bar folds into one Menu button on a narrow window ---- */
  const root = document.getElementById('ctxMenu');
  let openBar = null, allMenus = [];
  const narrow = () => innerWidth < 880;
  function closeMenus() { root.hidden = true; root.innerHTML = ''; document.querySelectorAll('.menu.subm').forEach(m => m.remove()); document.querySelectorAll('.mbtn.open').forEach(b => b.classList.remove('open')); openBar = null; }
  function fit(el, x, y, rightEdge) {   // put a menu where it is fully visible; if it is taller than the window it scrolls
    const pad = 6, H = innerHeight - 2 * pad; el.style.maxHeight = H + 'px'; el.style.overflowY = 'auto';
    const w = el.offsetWidth, h = el.offsetHeight; let L = x, T = y;
    if (L + w > innerWidth - pad) L = rightEdge != null ? rightEdge - w : innerWidth - w - pad;   // a submenu that does not fit on the right opens on the left of its parent
    L = Math.max(pad, Math.min(L, innerWidth - w - pad)); T = Math.max(pad, Math.min(T, innerHeight - h - pad));
    el.style.left = L + 'px'; el.style.top = T + 'px';
  }
  const dropSubs = lvl => document.querySelectorAll('.menu.subm').forEach(m => { if (m.__level >= lvl) m.remove(); });
  function fill(el, defs) {
    el.innerHTML = ''; el.setAttribute('role', 'menu');
    defs.forEach(d => {
      if (d.sep) { const s = document.createElement('div'); s.className = 'msep'; el.appendChild(s); return; }
      const dis = d.dis && d.dis();
      const it = document.createElement('div'); it.className = 'mi' + (d.sub ? ' sub' : '') + (dis ? ' dis' : ''); it.setAttribute('role', 'menuitem'); if (d.tip) it.title = d.tip;
      const chk = d.check ? '<span class="mcheck">' + (d.check() ? '&#10003;' : '') + '</span>' : '';
      it.innerHTML = chk + (d.icon ? icon(d.icon) : (d.check ? '' : '<span class="ico"></span>')) + '<span class="ml">' + esc(d.label) + '</span>' + (d.key ? '<span class="key">' + esc(d.key) + '</span>' : '');
      if (d.sub) {
        const openSub = () => {
          dropSubs((el.__level || 0) + 1);
          const sm = document.createElement('div'); sm.className = 'menu subm'; sm.__level = (el.__level || 0) + 1;
          fill(sm, typeof d.sub === 'function' ? d.sub() : d.sub); document.body.appendChild(sm);
          const r = it.getBoundingClientRect(); fit(sm, r.right - 2, r.top - 3, r.left + 2);
          it.classList.add('act');
        };
        it.addEventListener('mouseenter', () => { if (!narrow()) openSub(); });
        it.addEventListener('click', ev => { ev.stopPropagation(); openSub(); });
        it.__open = openSub;
      } else if (!dis) {
        it.addEventListener('mouseenter', () => dropSubs((el.__level || 0) + 1));
        it.addEventListener('click', ev => { ev.stopPropagation(); closeMenus(); if (d.act) d.act(); });
      }
      el.appendChild(it);
    });
  }
  function showMenu(defs, x, y) {
    closeMenus(); root.hidden = false; root.__level = 0; fill(root, defs); fit(root, x, y);
  }
  /* the menu bar: every menu is a button; on a narrow window one Menu button holds them all as submenus */
  function layoutBar() {
    const bar = document.getElementById('menus'); if (!bar) return; bar.innerHTML = '';
    if (narrow()) {
      const b = document.createElement('div'); b.className = 'mbtn mburger'; b.innerHTML = '<span aria-hidden="true">&#9776;</span>&nbsp;Menu';
      b.addEventListener('click', ev => { ev.stopPropagation(); if (openBar === b) { closeMenus(); return; } const r = b.getBoundingClientRect(); showMenu(allMenus.map(m => ({ label: m.label, sub: () => (typeof m.items === 'function' ? m.items() : m.items) })), r.left, r.bottom); b.classList.add('open'); openBar = b; });
      bar.appendChild(b); return;
    }
    allMenus.forEach(m => {
      const b = document.createElement('div'); b.className = 'mbtn'; b.textContent = m.label; b.setAttribute('role', 'button'); b.tabIndex = 0;
      const open = () => { const r = b.getBoundingClientRect(); showMenu(typeof m.items === 'function' ? m.items() : m.items, r.left, r.bottom); b.classList.add('open'); openBar = b; };
      b.__open = open;
      b.addEventListener('click', ev => { ev.stopPropagation(); if (openBar === b) closeMenus(); else open(); });
      b.addEventListener('mouseenter', () => { if (openBar && openBar !== b) { closeMenus(); open(); } });
      bar.appendChild(b);
    });
  }
  function buildMenubar(menus) { allMenus = menus; layoutBar(); let was = narrow(); window.addEventListener('resize', () => { closeMenus(); if (narrow() !== was) { was = narrow(); layoutBar(); } }); }
  /* keyboard: arrows move, Enter opens or runs, Escape closes, left and right change menu */
  function menuKeys(e) {
    if (root.hidden) { const ACC = { f: 'File', e: 'Edit', v: 'View', t: 'Tools', s: 'Refresh', r: 'Review', u: 'Run', d: 'Daisy', h: 'Help' }; if (e.altKey && !e.ctrlKey && ACC[e.key.toLowerCase()]) { const m = allMenus.findIndex(x => x.label === ACC[e.key.toLowerCase()]), bt = document.querySelectorAll('#menus .mbtn')[m]; if (bt && bt.__open) { e.preventDefault(); bt.__open(); const f = root.querySelector('.mi:not(.dis)'); if (f) f.classList.add('kf'); } } return; }
    const subs = Array.from(document.querySelectorAll('.menu.subm')), cur = subs.length ? subs[subs.length - 1] : root, items = Array.from(cur.querySelectorAll('.mi:not(.dis)')); let i = items.findIndex(x => x.classList.contains('kf'));
    const mark = k => { items.forEach(x => x.classList.remove('kf')); if (items[k]) { items[k].classList.add('kf'); items[k].scrollIntoView({ block: 'nearest' }); } };
    if (e.key === 'ArrowDown') { e.preventDefault(); mark((i + 1) % items.length); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); mark(i <= 0 ? items.length - 1 : i - 1); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); if (i >= 0 && items[i].__open) { items[i].__open(); const s2 = document.querySelectorAll('.menu.subm'), l2 = s2[s2.length - 1], f = l2 && l2.querySelector('.mi:not(.dis)'); if (f) f.classList.add('kf'); } else if (!narrow() && openBar) { const bs = Array.from(document.querySelectorAll('#menus .mbtn')), k = bs.indexOf(openBar); closeMenus(); const nb = bs[(k + 1) % bs.length]; nb.__open(); const f = root.querySelector('.mi:not(.dis)'); if (f) f.classList.add('kf'); } }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); if (subs.length) { subs[subs.length - 1].remove(); } else if (!narrow() && openBar) { const bs = Array.from(document.querySelectorAll('#menus .mbtn')), k = bs.indexOf(openBar); closeMenus(); const nb = bs[(k - 1 + bs.length) % bs.length]; nb.__open(); const f = root.querySelector('.mi:not(.dis)'); if (f) f.classList.add('kf'); } }
    else if (e.key === 'Enter' || e.key === ' ') { if (i >= 0) { e.preventDefault(); items[i].click(); } }
  }
  document.addEventListener('keydown', menuKeys, true);
  document.addEventListener('click', closeMenus);
  window.addEventListener('blur', closeMenus);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMenus(); closeModal(); } });

  /* ---- modal ---- */
  function closeModal() { document.getElementById('modalRoot').innerHTML = ''; }
  function modal(o) {
    const r = document.getElementById('modalRoot');
    r.innerHTML = '<div class="ov"><div class="modal" style="' + (o.width ? 'width:' + o.width : '') + '"><div class="mh">' + icon(o.icon || 'info') + '<span>' + esc(o.title) + '</span><span style="margin-left:auto;display:flex;gap:4px;align-items:center"><span class="x" data-manual title="Open the manual at the page for this window" style="margin-right:8px;cursor:pointer;width:auto;padding:0 7px;font-size:11px;display:none"></span><span class="x" data-zm="-1" title="Smaller text" style="margin-right:2px;cursor:pointer;width:auto;padding:0 5px;font-size:10px">A&minus;</span><span class="x" data-zm="1" title="Larger text" style="margin-right:6px;cursor:pointer;width:auto;padding:0 5px;font-size:13px">A+</span><span class="x" data-fsm title="Full screen (Esc or double click on the title bar to go back)" style="margin-right:4px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center"><svg viewBox="0 0 16 16" width="14" height="14" style="vertical-align:-2px"><path d="M1.5 5.5v-4h4M10.5 1.5h4v4M14.5 10.5v4h-4M5.5 14.5h-4v-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square"/></svg></span></span><span class="x" data-x>&#10005;</span></div><div class="mb">' + o.html + '</div><div class="mf"></div></div></div>';
    const mf = r.querySelector('.mf');
    (o.buttons || [{ label: 'Close', pri: true }]).forEach(b => {
      const el = document.createElement('button'); el.className = 'btn' + (b.pri ? ' pri' : ''); el.textContent = b.label;
      el.addEventListener('click', () => { if (!b.act || b.act() !== false) closeModal(); }); mf.appendChild(el);
    });
    r.querySelector('[data-x]').addEventListener('click', closeModal);
    const mdl = r.querySelector('.modal'), ov = r.querySelector('.ov'), fsm = r.querySelector('[data-fsm]'); let sv = mdl.style.cssText;
    let zz = 0; const zoom = () => { const mb = mdl.querySelector('.mb'); const z = mdl.classList.contains('mfull') ? (zz || Math.max(1, Math.min(1.3, window.innerWidth / (window.UIScale ? UIScale.cur() : 1) / 1700))) : 1; mb.style.zoom = z; mdl.style.setProperty('--mz', z); };
    r.querySelectorAll('[data-zm]').forEach(b => b.addEventListener('click', () => { const cur = zz || Math.max(1, Math.min(1.3, window.innerWidth / (window.UIScale ? UIScale.cur() : 1) / 1700)); zz = Math.max(0.8, Math.min(2.4, cur + (+b.dataset.zm) * 0.15)); zoom(); window.dispatchEvent(new Event('resize')); }));
    const setM = on => { const mb = mdl.querySelector('.mb'); mdl.classList.toggle('mfull', on); if (on) { mdl.style.cssText = 'width:' + (innerWidth / (window.UIScale ? UIScale.cur() : 1)) + 'px;max-width:100%;height:' + (innerHeight / (window.UIScale ? UIScale.cur() : 1)) + 'px;max-height:100%;margin:0;display:flex;flex-direction:column'; mb.style.cssText += ';flex:1;max-height:none;overflow:auto'; } else { mdl.style.cssText = sv; mb.style.flex = ''; mb.style.maxHeight = ''; } zoom(); window.dispatchEvent(new Event('resize')); };
    const onFs = () => { if (!document.fullscreenElement && mdl.classList.contains('mfull') && mdl._real) { mdl._real = false; setM(false); document.removeEventListener('fullscreenchange', onFs); } };
    const toggle = () => { const on = !mdl.classList.contains('mfull'); setM(on); if (on) { mdl._real = true; document.addEventListener('fullscreenchange', onFs); try { if (ov.requestFullscreen) ov.requestFullscreen().catch(() => { mdl._real = false; }); } catch (e) { mdl._real = false; } } else { mdl._real = false; document.removeEventListener('fullscreenchange', onFs); if (document.fullscreenElement) document.exitFullscreen().catch(() => { }); } };
    fsm.addEventListener('click', toggle); mdl.querySelector('.mh').addEventListener('dblclick', e => { if (!e.target.closest('.x')) toggle(); });
    mdl.querySelector('[data-x]').addEventListener('click', () => { if (document.fullscreenElement) document.exitFullscreen().catch(() => { }); });
    // the page of the manual that explains this window, one click away
    { const mb = r.querySelector('[data-manual]'), M = window.SWAFLManual, map = [[/field sketch/i, 'The field sketch'], [/field on the map/i, 'The field on the map'], [/online weather/i, 'The weather of a place'], [/weather|climate/i, 'Weather data: your own file, or the weather of a place'], [/irrigation systems compared/i, 'Surface irrigation design'], [/shortcut|settings|open project|paste settings/i, 'Menu bar reference'], [/full report|save report/i, 'Reports'], [/daisy/i, 'From Daisy to the SWAFL project'], [/how to use|welcome|about swafl/i, 'The window: a guided tour']], hit = o.manual || (map.find(q => q[0].test(String(o.title))) || [])[1];
      if (mb && M && hit) M.load().then(() => { const sx = M.find(hit); if (!sx || !mdl.isConnected) return; mb.textContent = 'Manual, page ' + sx.page; mb.title = 'Open the manual at page ' + sx.page + ': ' + sx.title; mb.style.display = ''; mb.addEventListener('click', e => { e.stopPropagation(); M.open(sx.page); }); }).catch(() => { }); }
    if (o.full) setM(true);
    r.querySelectorAll('a[data-url]').forEach(a => a.addEventListener('click', () => openExternal(a.dataset.url)));
    return r;
  }

  /* ---- external links ---- */
  function openExternal(url) {
    // the manual is part of SWAFL: its links open the PDF that comes with the program (at the right page), not the GitHub page
    if (/\/Manual\/SWAFL_Manual_v1\.1\.0\.pdf/.test(String(url)) && window.SWAFLManual) { const m = /#page=(\d+)/.exec(url); window.SWAFLManual.open(m ? +m[1] : 0); return; }
    if (window.swafl) window.swafl.openExternal(url); else window.open(url, '_blank', 'noopener');
  }

  /* ---- file output (desktop dialog or browser download) ---- */
  async function saveFile(name, data, isBase64, mime) {
    name = window.SWAFLDate ? window.SWAFLDate.name(name) : name; // every saved file carries today's date and time
    if (window.swafl) { const r = await window.swafl.saveFile(name, data, !!isBase64); if (r.ok) { toast('Saved ' + r.path); log('Saved file: ' + r.path); } return r.ok; }
    const blob = isBase64 ? new Blob([Uint8Array.from(atob(data), c => c.charCodeAt(0))], { type: mime || 'application/octet-stream' }) : new Blob([data], { type: mime || 'text/plain' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 3000);
    toast('Saved ' + name); log('Saved file: ' + name); return true;
  }
  function pickFileText() {
    if (window.swafl) return window.swafl.openFile().then(r => r.ok ? { name: r.path.split(/[\\/]/).pop(), data: r.data } : null);
    return new Promise(res => { const i = document.createElement('input'); i.type = 'file'; i.accept = '.swafl,.json'; i.onchange = () => { const f = i.files[0]; if (!f) return res(null); const rd = new FileReader(); rd.onload = () => res({ name: f.name, data: rd.result }); rd.readAsText(f); }; i.click(); });
  }

  /* ---- splitters ---- */
  function hsplit(el, target, side, min, max) {
    el.addEventListener('mousedown', e => {
      e.preventDefault(); el.classList.add('drag'); const x0 = e.clientX, w0 = target.getBoundingClientRect().width;
      const fr = document.getElementById('engine'); fr.style.pointerEvents = 'none';
      const mv = ev => { const d = (ev.clientX - x0) * (side === 'left' ? 1 : -1); target.style.width = Math.max(min, Math.min(max, w0 + d)) + 'px'; };
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); el.classList.remove('drag'); fr.style.pointerEvents = ''; };
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
  }
  function vsplit(el, getTarget, dir, min, max) {   // dir 'down': dragging down grows target; 'up': dragging up grows target
    el.addEventListener('mousedown', e => {
      e.preventDefault(); el.classList.add('drag'); const t = getTarget(), y0 = e.clientY, h0 = t.getBoundingClientRect().height;
      const fr = document.getElementById('engine'); fr.style.pointerEvents = 'none';
      const mv = ev => { const d = (ev.clientY - y0) * (dir === 'up' ? -1 : 1); const h = Math.max(min, Math.min(max, h0 + d)); t.style.height = h + 'px'; t.style.flex = 'none'; };
      const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); el.classList.remove('drag'); fr.style.pointerEvents = ''; };
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up);
    });
  }
  return { icon, esc, log, logs, toast, showMenu, closeMenus, buildMenubar, modal, closeModal, openExternal, saveFile, pickFileText, hsplit, vsplit };
})();
