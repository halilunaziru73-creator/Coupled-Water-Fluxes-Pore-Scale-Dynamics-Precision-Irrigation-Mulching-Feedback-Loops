/* Daisy workbench, decision base from the Daisy reference manual (version 7.1.14, reference.pdf): what Daisy can vary in an irrigation, nitrogen, weather
   or soil experiment, with the section of the manual each choice comes from, and the combinations worth running first for the weather and soil of the user.
   No experiment of an earlier study is used here: the combinations are derived from the manual and from the data given. */
'use strict';
(() => {
  const R = {};
  // what the manual says, by section: names, parameters, units, defaults
  R.SOURCE = 'Daisy reference manual 7.1.14 (reference.pdf)';
  R.BASE = {
    irrigation: {
      methods: [{ id: 'overhead', sec: '15.19', text: 'irrigate overhead: irrigate the field from above, over the canopy' }, { id: 'surface', sec: '15.21', text: 'irrigate surface: irrigate directly on the soil surface, bypassing the canopy' }, { id: 'drip', sec: '15.20', text: 'irrigate subsoil: irrigate directly into a soil volume (from and to heights in cm)' }],
      params: { flux: { sec: '15.5, 15.18', unit: 'mm/h', def: 2, text: 'water application speed, default 2 mm/h' }, hours: { sec: '15.18', unit: 'h', text: 'irrigate this number of hours' }, days: { sec: '15.18', unit: 'd' }, temperature: { sec: '15.18', unit: 'dg C', text: 'temperature of the water, default air temperature' } },
      season: { sec: '15.5', text: 'the irrigation of a crop is tested between a from date and a to date, at a soil potential, with an amount in mm' }
    },
    triggers: [
      { id: 'pressure', sec: '28.39', cond: 'soil water pressure above', params: 'potential [cm], height [cm]', text: 'true when the soil at the height is wetter than the potential; used with not to irrigate when it is drier' },
      { id: 'content', sec: '28.38', cond: 'soil water content above', params: 'water [mm], from [cm], to [cm]', text: 'true when the layer holds more water than the amount' },
      { id: 'nitrogen', sec: '28.36', cond: 'soil inorganic N above', params: 'amount [kg N/ha], from, to' },
      { id: 'temperature', sec: '28.37', cond: 'soil temperature above', params: 'height [cm], temperature [dg C]' },
      { id: 'rain', sec: '28.12', cond: 'daily precipitation above', params: 'precipitation [mm]' },
      { id: 'crop', sec: '28.6, 28.8', cond: 'crop dm over, crop ds after', params: 'crop, weight [kg DM/ha] or development stage' }
    ],
    scheduling: { id: 'markvand', sec: '15.22', text: 'MARKVAND scheduling: a water budget of the root zone, with flux 2 mm/h by default' },
    fertiliser: { sec: '15.12', text: 'fertilize: the amount in kg N/ha, at a date or a condition' },
    soil: { sec: '47, 48.16', text: 'horizons with a hydraulic model, by default hypres from texture, humus and bulk density' },
    chemical: { sec: '23', text: 'sorption (K_OC) and decomposition (half-life) of a chemical' },
    weather: { sec: '25.7, 107.26', text: 'weather data: precipitation, air temperature, global radiation, reference evapotranspiration, optional wind and vapour pressure' }
  };
  // texture of the soil of the user, or of the course soils
  const sandy = ctx => ctx.sand != null ? ctx.sand >= 60 : ctx.soil === 'sand' || /sand/.test(String(ctx.soil || '')) && !/loam/.test(String(ctx.soil || ''));
  const clayey = ctx => ctx.clay != null ? ctx.clay >= 30 : /clay|silt/.test(String(ctx.soil || ''));
  const rootDepth = ctx => ctx.root || 100;

  // the combinations to run first; each is {id, title, why, ref, plan:{design, factors:[{id, levels}], base}, score}
  /* which chapters of the reference have something that can be varied and run in this app */
  R.CHAPTER_MAP = { 15: ['method', 'trigger', 'dose', 'window', 'flux', 'tillage', 'nitrogen', 'straw', 'wtemp', 'fdepth', 'nprec', 'detain', 'tilltypes', 'irrfull', 'fluxmethod', 'windowtrig', 'ntypeirr', 'ntimerain', 'residtill', 'dripdepth2'], 16: ['chemical'], 19: ['etmodel', 'climate'], 23: ['chemical'], 28: ['trigger'], 29: ['rooting', 'rootclimate'], 47: ['soils', 'soilmethod'], 48: ['soils', 'detain', 'soilmethod'], 62: ['etmodel'], 103: ['climate', 'season', 'stations'] };

  /* chapters whose models cannot be changed directly yet lead to the process they belong to: the experiments of that process are offered, marked as related */
  const GROUPS = [
    { topic: 'water and heat movement in the soil', ids: ['soils', 'climate'], ch: [20, 27, 37, 38, 45, 46, 47, 48, 53, 54, 55, 56, 65, 71, 82, 87, 89, 90, 92, 97, 98, 99, 31, 9, 12] },
    { topic: 'the crop: growth, roots and water use', ids: ['rooting', 'climate', 'nitrogen'], ch: [11, 29, 30, 63, 64, 72, 73, 74, 75, 79, 81, 84, 88, 100, 101, 104] },
    { topic: 'nitrogen, carbon and organic matter', ids: ['nitrogen', 'tillage'], ch: [7, 8, 10, 13, 14, 17, 32, 33, 36, 58, 60, 70, 91, 69, 39, 51, 78] },
    { topic: 'chemicals and their sorption', ids: ['chemical'], ch: [16, 23, 24] },
    { topic: 'weather, radiation and evapotranspiration', ids: ['etmodel', 'climate', 'season', 'stations'], ch: [19, 25, 35, 43, 57, 62, 67, 68, 103] },
    { topic: 'management', ids: ['method', 'trigger', 'dose', 'window', 'flux', 'tillage', 'nitrogen', 'straw', 'wtemp', 'fdepth', 'nprec', 'detain', 'tilltypes', 'irrfull', 'fluxmethod', 'windowtrig', 'ntypeirr', 'ntimerain', 'residtill', 'dripdepth2'], ch: [15, 28] }
  ];
  R.CHAPTER_RELATED = {}; GROUPS.forEach(g => g.ch.forEach(n => { R.CHAPTER_RELATED[n] = { topic: g.topic, ids: g.ids }; }));
  R.GENERAL = ['method', 'trigger', 'nitrogen', 'climate', 'soils'];
  R.suggest = function (ctx) {
    ctx = ctx || {}; const P = ctx.Pmean, dry = P != null && P < 600, wet = P != null && P > 800, out = [];
    const soils = ctx.userSoil ? [] : [{ id: 'soil', levels: ['usda:sand', 'loam'] }];
    const trigs = sandy(ctx) ? [-100, -200, -400] : clayey(ctx) ? [-300, -600, -1200] : [-150, -300, -600];
    const zs = [10, 30, 60].filter(z => z <= rootDepth(ctx)).concat(rootDepth(ctx) < 60 ? [] : []);
    const wxNote = P != null ? ' The weather given has ' + Math.round(P) + ' mm of rain a year' + (ctx.Tmean != null ? ' and ' + ctx.Tmean.toFixed(1) + ' degC' : '') + '.' : '';
    out.push({ id: 'method', title: 'Overhead, surface or drip irrigation', ref: '15.19, 15.20, 15.21', score: dry ? 9 : 7,
      why: 'The manual has three ways to apply water: over the canopy, on the soil surface, and into a soil volume. Run the three with the same trigger and dose, so only the way of applying water differs.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'method', levels: ['overhead', 'surface', 'drip'] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'trigger', title: 'When to irrigate: the trigger and the depth of the sensor', ref: '28.39, 15.5', score: dry ? 10 : 6,
      why: 'Irrigation starts when "soil water pressure above" is not true: the potential (cm) and the height (cm) are its two parameters. The potentials run from near field capacity to well before wilting for this soil texture; the depths stay inside the rooting depth of ' + rootDepth(ctx) + ' cm.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'trig', levels: trigs }, { id: 'z', levels: zs.length ? zs : [10, 30] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'dose', title: 'How much and how fast: dose and duration', ref: '15.5, 15.18', score: 6,
      why: 'The water application speed is a parameter in mm/h (default 2 mm/h) and the irrigation lasts a number of hours. The pairs below keep the speed of the manual (2 mm/h) while the dose grows, so the answer is the effect of the dose and not of the speed.',
      plan: { design: 'paired', factors: [{ id: 'mm', levels: [10, 20, 30, 40] }, { id: 'hours', levels: [5, 10, 15, 20] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'window', title: 'The irrigation season and a limit on water', ref: '15.5', score: dry ? 8 : 5,
      why: 'The irrigation of a crop is tested between a from date and a to date and can be given an amount. Start dates and a seasonal limit show how much of the yield is bought by the first and the last irrigations.',
      plan: { design: 'factorial', factors: [{ id: 'window', levels: [{ label: 'Apr 1 - Oct 1', set: { w1: '04-01', w2: '10-01' } }, { label: 'May 1 - Oct 1', set: { w1: '05-01', w2: '10-01' } }, { label: 'Jun 1 - Sep 1', set: { w1: '06-01', w2: '09-01' } }] }, { id: 'limit', levels: [60, 120, 240] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'nitrogen', title: 'Nitrogen fertiliser, irrigated and rainfed', ref: '15.12', score: wet ? 10 : 6,
      why: 'Fertiliser is applied as an amount in kg N/ha. Scaling the rotation between half and one and a quarter of its dose, with and without irrigation, shows the dose where yield stops rising and the nitrate leached below the roots starts to climb.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'nfac', levels: [0.5, 0.75, 1, 1.25] }, { id: 'irrig', levels: ['0', '1'] }].concat(soils), base: {} } });
    out.push({ id: 'climate', title: 'A drier, wetter or warmer year', ref: '25.7, 107.26', score: dry ? 7 : 6,
      why: 'The weather file gives precipitation and air temperature to every model of the column. Scaling the rain and adding a warming to the same record shows how much the yield and the water use move with the weather, with the soil and the management unchanged.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'precip', levels: [0.8, 1, 1.2] }, { id: 'temp', levels: [0, 2] }].concat(soils), base: { irrig: '1' } } });
    if (!ctx.userSoil) out.push({ id: 'soils', title: 'Which soil needs the most water', ref: '47, 48.16', score: 5,
      why: 'A horizon gets its hydraulic properties from the hypres model by default, from the sand, silt, clay, humus and bulk density. Rainfed and irrigated runs on several textures show where irrigation pays.',
      plan: { design: 'factorial', factors: [{ id: 'soil', levels: ['usda:sand', 'usda:sandyloam', 'loam', 'usda:siltloam', 'usda:clayloam'] }, { id: 'irrig', levels: ['0', '1'] }], base: {} } });
    out.push({ id: 'flux', title: 'Slow or fast irrigation: a constant water flux', ref: '15.5, 15.18', score: dry ? 6 : 5,
      why: 'Daisy applies irrigation at a rate in mm/h, so a slow rate keeps the water in the topsoil and a fast one can run off or percolate. The rates below keep the same dose per irrigation, so only the speed of application differs.',
      plan: { design: 'factorial', factors: [{ id: 'flux', levels: [0.1, 0.5, 2] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'tillage', title: 'Tillage and the time and form of the fertiliser', ref: '15.3, 15.12', score: wet ? 7 : 4,
      why: 'The tillage action (plowing, rotavation, or none) mixes the residues and the topsoil; the fertiliser is taken from the fertilizer library by name, and the date can be moved. These three decide how much nitrate is exposed to leaching.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'till', levels: ['plowing', 'rotavation', 'none'] }, { id: 'ntime', levels: [-14, 0, 14] }, { id: 'ntype', levels: ['N25S', 'AmmoniumNitrate', 'Ammonia'] }].concat(soils), base: {} } });
    out.push({ id: 'etmodel', title: 'Evapotranspiration model and radiation', ref: '25.7, 107.26', score: 4,
      why: 'Daisy can take the reference evapotranspiration from the weather file (FAO56) or compute it from the energy balance, and the radiation can be scaled. The runs show how much of the answer depends on that choice.',
      plan: { design: 'factorial', factors: [{ id: 'bio', levels: ['auto', 'default'] }, { id: 'radscale', levels: [0.9, 1, 1.1] }].concat(soils), base: {} } });
    out.push({ id: 'rooting', title: 'Rooting depth of the crop', ref: '29.1, 72', score: 3,
      why: 'The crop model has a maximum rooting depth, which decides how much of the soil water and nitrate the roots can reach. Shallow to deep roots, rainfed and irrigated, show how much of a water shortage a deeper root zone absorbs.',
      plan: { design: 'factorial', factors: [{ id: 'root', levels: [30, 60, 90, 120] }, { id: 'irrig', levels: ['0', '1'] }].concat(soils), base: {} } });
    out.push({ id: 'season', title: 'A dry summer, a dry spring or a wet winter', ref: '103, 25.7', score: dry ? 6 : 4,
      why: 'The weather component can scale the precipitation month by month (twelve factors). Taking 30 percent of the rain from the summer or the spring, or adding 30 percent in the winter, shows which part of the year matters for yield and for leaching.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'season', levels: [{ label: 'dry summer (rain x0.7 Jun-Aug)', set: { pmonths: '1 1 1 1 1 0.7 0.7 0.7 1 1 1 1' } }, { label: 'dry spring (rain x0.7 Mar-May)', set: { pmonths: '1 1 0.7 0.7 0.7 1 1 1 1 1 1 1' } }, { label: 'wet winter (rain x1.3 Dec-Feb)', set: { pmonths: '1.3 1.3 1 1 1 1 1 1 1 1 1 1.3' } }] }, { id: 'irrig', levels: ['0', '1'] }].concat(soils), base: {} } });
    out.push({ id: 'stations', title: 'The same farm under other climates', ref: '103', score: 3,
      why: 'The weather component reads a file for one place. Running the same soil, crops and management with the weather of several places shows how much of the result belongs to the climate.',
      plan: { design: 'factorial', factors: [{ id: 'station', levels: ['course', 'it-bologna', 'dk-foulum'] }, { id: 'irrig', levels: ['0', '1'] }].concat(soils), base: {} } });
    out.push({ id: 'chemical', title: 'Sorption and half-life of a chemical', ref: '23', score: 4,
      why: 'A chemical has a sorption coefficient (K_OC, L/kg) and a decomposition rate; the two decide whether it stays in the topsoil or reaches the depth where it is counted as leached.',
      plan: { design: 'factorial', factors: [{ id: 'koc', levels: [0, 50, 500] }, { id: 'half', levels: [15, 90] }].concat(soils), base: {} } });
    // interactions between the management choices of topic 15 and the weather and soil
    out.push({ id: 'deficit', title: 'Deficit irrigation: a water limit against the trigger', ref: '15.5, 28.39', score: dry ? 8 : 4, group: 'Irrigation',
      why: 'A crop can be given a limited amount of water in the season, and irrigation starts only when the soil water pressure is below the trigger. A strict trigger with a small limit, against a lax trigger with a large limit, shows whether the same water gives more yield when it is saved for the dry spell.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'trig', levels: trigs.slice(0, 3) }, { id: 'limit', levels: [60, 120, 240] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'sensorbal', title: 'Sensor depth against rooting depth', ref: '28.39, 29.1, 72', score: 5, group: 'Irrigation',
      why: 'The tensiometer that triggers irrigation sits at one depth, while the roots take water from the whole root zone. A sensor above or below most of the roots triggers too early or too late; crossing the sensor depth with the rooting depth shows where it matters.',
      plan: { design: 'factorial', factors: [{ id: 'z', levels: [10, 30, 50] }, { id: 'root', levels: [40, 80, 120] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'irrnitrogen', title: 'Irrigation and nitrogen together', ref: '15.5, 15.12', score: wet ? 6 : 7, group: 'Nitrogen',
      why: 'Water moves nitrate and decides how much of the fertiliser the crop can use. Irrigation against rainfed, at three fertiliser doses, shows whether more water raises the yield only when the nitrogen is there, and what it costs in nitrate below the roots.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'irrig', levels: ['0', '1'] }, { id: 'nfac', levels: [0.5, 1, 1.25] }].concat(soils), base: {} } });
    out.push({ id: 'ntiming', title: 'When the fertiliser is applied and how much', ref: '15.12, 15.3', score: wet ? 7 : 5, group: 'Nitrogen',
      why: 'The fertilize action is placed on a date. Moving it two weeks earlier or later, at three doses, shows how much nitrate is exposed to the rain before the crop takes it up.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'ntime', levels: [-14, 0, 14] }, { id: 'nfac', levels: [0.7, 1, 1.3] }].concat(soils), base: {} } });
    out.push({ id: 'warming', title: 'Warming with and without irrigation', ref: '25.7, 15.5', score: 5, group: 'Climate',
      why: 'A warmer year raises the evapotranspiration and shortens the crop cycle. Warming of 0 to 3 degrees, rainfed and irrigated, shows how much of the loss irrigation can give back.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'temp', levels: [0, 1.5, 3] }, { id: 'irrig', levels: ['0', '1'] }].concat(soils), base: {} } });
    out.push({ id: 'tillnit', title: 'Tillage against fertiliser form', ref: '15.3, 15.12, 17', score: 3, group: 'Nitrogen',
      why: 'The tillage action mixes residues and topsoil; the fertilizer library holds several forms of mineral nitrogen. Crossing the two shows whether the form of the nitrogen matters more under one tillage than another.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'till', levels: ['plowing', 'rotavation', 'none'] }, { id: 'ntype', levels: ['N25S', 'AmmoniumNitrate', 'Ammonia'] }].concat(soils), base: {} } });
    // the other actions of chapter 15 and their combinations
    out.push({ id: 'straw', title: 'Stubble and straw at harvest', ref: '15.14', score: 4, group: 'Nitrogen',
      why: 'The harvest action leaves stem and leaf below a stubble height on the field and takes a fraction of the stem, the leaf and the storage organ. Leaving or removing the straw, at four stubble heights, changes the organic matter and the nitrogen that go back to the soil.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'stub', levels: [0, 8, 15, 30] },{ id: 'straw', levels: ['left', 'removed'] }].concat(soils), base: {} } });
    out.push({ id: 'wtemp', title: 'Temperature of the irrigation water', ref: '15.18, 15.19, 15.21', score: 3, group: 'Irrigation',
      why: 'Every irrigate action has a temperature, by default that of the air. Cold and warm water, applied over the canopy and on the soil surface, differ in evaporation and in the heat that enters the soil (the temperature is not used by the subsoil action).' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'wtemp', levels: [5, 12, 20, 30] },{ id: 'method', levels: ['overhead', 'surface'] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'fdepth', title: 'How deep the fertiliser goes, and which fertiliser', ref: '15.12, 15.13, 17', score: 4, group: 'Nitrogen',
      why: 'The fertilize action can spread the nitrogen on the surface or work it into the soil between two heights. Surface, 5, 10 and 20 cm, with three mineral forms, show how much nitrogen is lost to the air from the surface and how much is exposed to leaching.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'fdepth', levels: [0, 5, 10, 20] },{ id: 'ntype', levels: ['N25S', 'AmmoniumNitrate', 'Ammonia'] }].concat(soils), base: {} } });
    out.push({ id: 'nprec', title: 'Fertiliser by the nitrogen already in the soil', ref: '15.11, 15.12', score: 5, group: 'Nitrogen',
      why: 'With the precision option the amount applied is the target minus the mineral nitrogen already in the soil between two depths. Fixed rates against the same targets applied by this rule, at three doses, show how much nitrogen is saved and what happens to the yield.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'nprec', levels: ['off', 'on'] },{ id: 'nfac', levels: [0.7, 1, 1.3] }].concat(soils), base: {} } });
    out.push({ id: 'detain', title: 'Ponding on the soil surface before runoff', ref: '15.40, 48', score: 3, group: 'Soil and water',
      why: 'The surface can hold a depth of ponding before water runs off. From none to 30 mm, with the rain scaled, shows how much water the soil gets in dry and wet years and how much is lost.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'detain', levels: [0, 5, 15, 30] },{ id: 'precip', levels: [0.8, 1, 1.2] }].concat(soils), base: {} } });
    out.push({ id: 'tilltypes', title: 'Plowing, rotavation, disk harrowing, stubble cultivation or none', ref: '15.24, 15.25, 15.26, 15.28, 15.52', score: 5, group: 'Nitrogen',
      why: 'Each tillage action mixes the soil down to a depth (plowing deepest, then rotavation, disk harrowing and stubble cultivation). The five systems, with the consolidation of the loosened soil, show how the mixing depth changes the water, the nitrogen and the yield.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'till', levels: ['plowing', 'rotavation', 'disk_harrowing', 'stubble_cultivation', 'none'] },{ id: 'tc', levels: [0.001, 0.01] }].concat(soils), base: {} } });
    out.push({ id: 'irrfull', title: 'Method, trigger and dose of irrigation together', ref: '15.5, 15.18, 15.19, 15.20, 15.21, 28.39', score: 6, group: 'Irrigation',
      why: 'The three ways of applying water, three triggers and three doses, all crossed. The best combination is the one that gives the yield for the least water.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'method', levels: ['overhead', 'surface', 'drip'] },{ id: 'trig', levels: trigs.slice(0, 3) },{ id: 'mm', levels: [15, 30, 45] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'fluxmethod', title: 'Speed of application for each method', ref: '15.18 to 15.21', score: 4, group: 'Irrigation',
      why: 'The same dose applied slowly or fast by the three actions: slow drip keeps the water in the root zone, a fast surface flow can run off or drain below the roots.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'flux', levels: [0.1, 0.5, 2] },{ id: 'method', levels: ['overhead', 'surface', 'drip'] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'windowtrig', title: 'The season of irrigation against the trigger', ref: '15.5, 28.39', score: 4, group: 'Irrigation',
      why: 'The irrigation window and the trigger work together: a late start with a strict trigger can miss the dry spell, an early start with a lax trigger wastes water.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'window', levels: [{ label: 'Apr 1 - Oct 1', set: { w1: '04-01', w2: '10-01' } }, { label: 'May 1 - Sep 1', set: { w1: '05-01', w2: '09-01' } }, { label: 'Jun 1 - Aug 15', set: { w1: '06-01', w2: '08-15' } }] },{ id: 'trig', levels: trigs.slice(0, 3) }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'ntypeirr', title: 'Fertiliser form, irrigated and rainfed', ref: '15.12, 15.5, 17', score: 4, group: 'Nitrogen',
      why: 'Ammonium and nitrate behave differently in wet soil: nitrate leaches and denitrifies, ammonium is held and can be lost to the air. Irrigation changes the water they meet.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'ntype', levels: ['N25S', 'AmmoniumNitrate', 'Nitrate', 'Ammonia'] },{ id: 'irrig', levels: ['0', '1'] }].concat(soils), base: {} } });
    out.push({ id: 'ntimerain', title: 'Fertiliser date and the rain of the year', ref: '15.12, 25.7', score: 4, group: 'Nitrogen',
      why: 'Moving the fertiliser by weeks is a different decision in a wet year than in a dry one: the rain after the date decides how much nitrate leaves the root zone.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'ntime', levels: [-14, 0, 14, 28] },{ id: 'precip', levels: [0.8, 1, 1.2] }].concat(soils), base: {} } });
    out.push({ id: 'rootclimate', title: 'Rooting depth in a drier or wetter year', ref: '29.1, 72, 25.7', score: 4, group: 'Climate',
      why: 'Deep roots buffer a dry year and let the crop use nitrate that has moved down. Four rooting depths against the rain scaled by the weather show where depth matters.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'root', levels: [30, 60, 90, 120] },{ id: 'precip', levels: [0.7, 1, 1.3] }].concat(soils), base: {} } });
    out.push({ id: 'warmn', title: 'Warming and nitrogen', ref: '25.7, 15.12', score: 3, group: 'Climate',
      why: 'A warmer year speeds up mineralisation and the crop cycle. Warming of 0 to 3 degrees at three nitrogen doses shows the yield and the leaching.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'temp', levels: [0, 1.5, 3] },{ id: 'nfac', levels: [0.7, 1, 1.3] }].concat(soils), base: {} } });
    out.push({ id: 'residtill', title: 'Straw and tillage together', ref: '15.14, 15.24 to 15.28', score: 3, group: 'Nitrogen',
      why: 'Straw left on the field is mixed into the soil by the tillage action: the depth of the mixing decides where the residue carbon and nitrogen end up.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'straw', levels: ['left', 'removed'] },{ id: 'till', levels: ['plowing', 'rotavation', 'none'] }].concat(soils), base: {} } });
    out.push({ id: 'soilmethod', title: 'Which soil needs which irrigation method', ref: '47, 48, 15.19, 15.20, 15.21', score: 4, group: 'Soil and water',
      why: 'A sand drains the water of a fast surface application, a clay holds it. The three methods on four textures show which method suits which soil.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'soil', levels: ['usda:sand', 'usda:sandyloam', 'loam', 'usda:clayloam'] },{ id: 'method', levels: ['overhead', 'surface', 'drip'] }].concat(soils), base: { irrig: '1' } } });
    out.push({ id: 'dripdepth2', title: 'Depth of the drip line', ref: '15.20', score: 4, group: 'Irrigation',
      why: 'The subsoil action puts the water between two heights. A shallow line wets the roots and the surface, a deep one keeps the surface dry but can pass below the roots.' + wxNote,
      plan: { design: 'factorial', factors: [{ id: 'dripdepth', levels: [{ label: 'drip 5-10 cm', set: { method: 'drip', dfrom: 5, dto: 10 } }, { label: 'drip 10-20 cm', set: { method: 'drip', dfrom: 10, dto: 20 } }, { label: 'drip 20-40 cm', set: { method: 'drip', dfrom: 20, dto: 40 } }] },{ id: 'trig', levels: trigs.slice(0, 3) }].concat(soils), base: { irrig: '1' } } });
    // one experiment for each group of parameters that was tested in Daisy: the two or three that moved the results most, around the value the farm uses
    const PR = (typeof window !== 'undefined' ? window.DaisyParams : (typeof globalThis !== 'undefined' ? globalThis.DaisyParams : null)) || [];
    const byAttr = {}; PR.forEach(q => { (byAttr[q.attr + '|' + q.use] = byAttr[q.attr + '|' + q.use] || []).push(q); });
    const TOP = { Surface: 'Water at the soil surface: runoff and evaporation', Groundwater: 'The groundwater and the aquitard below the profile', OrganicMatter: 'Turnover of organic matter and the mineral nitrogen it releases', Bioclimate: 'The numerical settings of the bioclimate model', Chemistry: 'The limits on the chemistry sink terms', Drain: 'Pipe drainage' };
    Object.keys(byAttr).forEach(k => { const L = byAttr[k].filter(q => q.sens).concat(byAttr[k].filter(q => !q.sens)).filter(q => (q.farm != null ? q.farm : q.def) > 0).slice(0, 3); if (!L.length) return; const q0 = L[0], base = q => q.farm != null ? q.farm : q.def, rd = (q, v) => q.type === 'integer' ? Math.max(1, Math.round(v)) : +(+v).toPrecision(4);
      out.push({ id: 'p_' + q0.attr + '_' + (q0.use || 'std'), group: 'Parameters', title: (TOP[q0.attr] || q0.attr) + (Object.keys(byAttr).filter(x => x.split('|')[0] === q0.attr).length > 1 ? ': ' + (q0.use && q0.use !== 'std' ? q0.use : 'standard model') : '') + ' (topic ' + q0.ch + ')', ref: String(q0.ch), score: 2 + (L.some(q => q.sens) ? 1 : 0),
        why: L.map(q => q.name + (q.unit ? ' [' + q.unit + ']' : '') + ': ' + (q.desc || '').replace(/\.$/, '')).join('; ') + '. Each is varied from half to double the value the farm uses' + (L.some(q => q.sens) ? '; ' + L.filter(q => q.sens).map(q => q.name).join(', ') + ' moved the yield, water or nitrogen in the test.' : '; none of them moved yield, water or nitrogen in the test, so the effect shows in the process itself.'),
        plan: { design: L.length > 2 ? 'oat' : 'factorial', factors: L.map(q => ({ id: q.opt, levels: [0.5, 1, 2].map(f => rd(q, base(q) * f)).filter((v, i, a) => a.indexOf(v) === i) })), base: {} } }); });
    const GR = { method: 'Irrigation', trigger: 'Irrigation', dose: 'Irrigation', window: 'Irrigation', flux: 'Irrigation', straw: 'Nitrogen', nitrogen: 'Nitrogen', tillage: 'Nitrogen', climate: 'Climate', season: 'Climate', stations: 'Climate', etmodel: 'Climate', soils: 'Soil and crop', rooting: 'Soil and crop', chemical: 'Chemicals' };
    out.forEach(g => { if (!g.group) g.group = GR[g.id] || 'Other combinations'; });
    return out.sort((a, b) => b.score - a.score);
  };

  // learn from the runs and propose the next ones: a ridge regression with squares and products of the numeric factors, fitted on the runs finished so far;
  // the next points are chosen on a grid between the tested levels where the fitted response is best and that are far from the points already run
  R.learn = function (rows, numFactors, resp, opt) {
    opt = opt || {}; const good = opt.good == null ? 1 : opt.good, nf = numFactors.length, n = rows.length;
    if (nf < 1 || n < nf + 2) return { ok: false, why: 'at least ' + (nf + 2) + ' finished runs are needed to learn from them' };
    const lo = numFactors.map(f => Math.min.apply(null, rows.map(r => r.val[f]))), hi = numFactors.map(f => Math.max.apply(null, rows.map(r => r.val[f])));
    const u = (r, k) => hi[k] === lo[k] ? 0 : 2 * (r.val[numFactors[k]] - lo[k]) / (hi[k] - lo[k]) - 1;
    const feat = x => { const f = [1]; x.forEach(v => f.push(v)); if (n >= 2 * nf + 3) x.forEach(v => f.push(v * v)); if (n >= 3 * nf + 4) for (let i = 0; i < nf; i++) for (let j = i + 1; j < nf; j++) f.push(x[i] * x[j]); return f; };
    const X = rows.map(r => feat(numFactors.map((_, k) => u(r, k)))), y = rows.map(r => r.r[resp]), m = X[0].length;
    const lam = 0.05, A = Array.from({ length: m }, (_, i) => Array.from({ length: m }, (_, j) => (i === j && i > 0 ? lam : 0))), b = Array(m).fill(0);
    X.forEach((x, k) => { for (let i = 0; i < m; i++) { b[i] += x[i] * y[k]; for (let j = 0; j < m; j++) A[i][j] += x[i] * x[j]; } });
    const w = solve(A, b); if (!w) return { ok: false, why: 'the runs do not separate the factors yet' };
    const pred = x => feat(x).reduce((s, v, i) => s + v * w[i], 0), ybar = y.reduce((a, c) => a + c, 0) / n, sst = y.reduce((s, v) => s + (v - ybar) * (v - ybar), 0) || 1, sse = X.reduce((s, x, k) => s + Math.pow(y[k] - pred(x.slice(1, 1 + nf)), 2), 0);
    const r2 = Math.max(0, 1 - sse / sst), pts = X.map((_, k) => numFactors.map((_, i) => u(rows[k], i)));
    const steps = nf === 1 ? 21 : nf === 2 ? 13 : 7, cand = []; const walk = (k, cur) => { if (k === nf) { cand.push(cur.slice()); return; } for (let s = 0; s < steps; s++) { cur[k] = -1 + 2 * s / (steps - 1); walk(k + 1, cur); } cur.pop && 0; }; walk(0, []);
    const dist = (a, c) => Math.sqrt(a.reduce((s, v, i) => s + (v - c[i]) * (v - c[i]), 0)), picked = [], k = opt.count || 4, ys = cand.map(c => good * pred(c)), ymin = Math.min.apply(null, ys), ymax = Math.max.apply(null, ys);
    const near = pts.slice(); for (let t = 0; t < k; t++) { let best = -1, bs = -Infinity; cand.forEach((c, i) => { const d = near.length ? Math.min.apply(null, near.map(p => dist(p, c))) : 1; if (d < 0.12) return; const sc = (ys[i] - ymin) / ((ymax - ymin) || 1) + 0.6 * Math.min(1, d); if (sc > bs) { bs = sc; best = i; } }); if (best < 0) break; picked.push(cand[best]); near.push(cand[best]); }
    const val = c => { const o = {}; numFactors.forEach((f, i) => { o[f] = lo[i] + (c[i] + 1) / 2 * (hi[i] - lo[i]); }); return o; };
    return { ok: true, r2, n, terms: m, next: picked.map(c => ({ val: val(c), predicted: pred(c) })), best: (() => { let bi = 0; ys.forEach((v, i) => { if (v > ys[bi]) bi = i; }); return { val: val(cand[bi]), predicted: pred(cand[bi]) }; })() };
  };
  function solve(A, b) { const n = b.length, M = A.map((r, i) => r.concat([b[i]])); for (let i = 0; i < n; i++) { let p = i; for (let r = i + 1; r < n; r++) if (Math.abs(M[r][i]) > Math.abs(M[p][i])) p = r; if (Math.abs(M[p][i]) < 1e-12) return null; [M[i], M[p]] = [M[p], M[i]]; for (let r = 0; r < n; r++) if (r !== i) { const f = M[r][i] / M[i][i]; for (let c = i; c <= n; c++) M[r][c] -= f * M[i][c]; } } return M.map((r, i) => r[n] / r[i]); }
  if (typeof module !== 'undefined' && module.exports) module.exports = R; if (typeof window !== 'undefined') window.DaisyRef = R;   // also in a window that has a module object
})();
