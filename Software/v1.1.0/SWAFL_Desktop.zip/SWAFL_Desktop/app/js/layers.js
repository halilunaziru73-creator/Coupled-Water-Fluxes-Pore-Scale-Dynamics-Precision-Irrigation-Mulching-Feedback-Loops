/* Layers panel (project tree), document tabs and the view bar. Click a layer to open it, click a sub-layer to jump to that section. */
'use strict';
const Layers = (() => {
  const GROUPS = [
    { id: 'g-design', name: 'Irrigation design', icon: 'pipe', items: [['sid', 'Surface irrigation design', 'S2'], ['drip', 'Drip irrigation design', 'S3'], ['spr', 'Sprinkler design and pipes', 'S4'], ['drn', 'Drainage design', 'S5']] },
    { id: 'g-ctrl', name: 'Irrigation control', icon: 'drop', items: [['v1', 'Sensor and trigger', 'V1'], ['n1', 'Trigger law', 'N1']] },
    { id: 'g-mulch', name: 'Mulch and evaporation', icon: 'layers', items: [['v4', 'Mulch against bare soil', 'V4'], ['v6', 'Mulch control', 'V6'], ['e1', 'Evaporation', 'E1'], ['n2', 'Fate of saved water', 'N2'], ['n3', 'Regime map', 'N3']] },
    { id: 'g-soil', name: 'Soil structure and tillage', icon: 'soil', items: [['v3', 'Tillage and structure', 'V3'], ['v7', 'Soil hydraulic drivers', 'V7'], ['r1', 'Root structure', 'R1']] },
    { id: 'g-pheno', name: 'Phenotyping', icon: 'soil', items: [['dph', 'Deterministic phenotyping', 'P1'], ['vph', 'Volumetric phenotyping', 'P2']] },
    { id: 'g-water', name: 'Field water balance', icon: 'field', items: [['field', 'Field balance', ''], ['spac', 'Soil, plant and air', 'S1'], ['v2', 'Profile evolution', 'V2']] },
    { id: 'g-year', name: 'Seasonal data', icon: 'refresh', items: [['yby', 'Reliability over 20 seasons', 'Y1'], ['wb2', 'Full water balance', 'W1'], ['nb', 'Nitrogen budget', 'N4']] },
    { id: 'g-crop', name: 'Crops', icon: 'drop', items: [['crop', 'Crop water requirement', 'C1']] },
    { id: 'g-loop', name: 'Feedback loops', icon: 'refresh', items: [['v5', 'Feedback loops', 'V5']] }
  ];
  // the Daisy model is a project of its own, beside the SWAFL project
  const DAISY = [
    { id: 'g-ddata', name: 'Input data', icon: 'field', items: [['dz-data', 'Weather, soil and site data', ''], ['dz-library', 'Parameter library (soils, crops, fertilisers)', '']] },
    { id: 'g-dscen', name: 'Experiments and scenarios', icon: 'drop', items: [['dz-exp', 'Experiments', ''], ['dz-scen', 'Scenarios', ''], ['dz-scen:irrigation', 'Scenario: irrigation strategy', ''], ['dz-scen:nitrogen', 'Scenario: nitrogen fertilisation and leaching', ''], ['dz-scen:climate', 'Scenario: climate change (warmer, drier, wetter)', ''], ['dz-scen:chemical', 'Scenario: pesticide and tracer fate', ''], ['dz-scen:soil', 'Scenario: soil texture (sand against loam)', ''], ['dz-scen:own', 'Scenario: own Daisy set-up', ''], ['dz-scen:irrmethod', 'Scenario: irrigation method (overhead, surface, drip)', ''], ['dz-scen:trigger', 'Scenario: when to irrigate (trigger suction)', ''], ['dz-scen:dose', 'Scenario: water per irrigation', ''], ['dz-scen:deficit', 'Scenario: deficit irrigation', ''], ['dz-scen:sensor', 'Scenario: sensor depth', ''], ['dz-scen:fertype', 'Scenario: mineral fertiliser type', ''], ['dz-scen:manure', 'Scenario: slurry and manure', ''], ['dz-scen:ntiming', 'Scenario: when to fertilise', ''], ['dz-scen:textures', 'Scenario: eight soil textures', ''], ['dz-scen:jbsoils', 'Scenario: Danish soils JB1 to JB7', ''], ['dz-scen:tillage', 'Scenario: tillage', ''], ['dz-scen:roots', 'Scenario: rooting depth', ''], ['dz-scen:aquitard', 'Scenario: the aquitard', ''], ['dz-scen:crops', 'Scenario: which crop', ''], ['dz-scen:stations', 'Scenario: six climates of Europe', ''], ['dz-scen:radiation', 'Scenario: sunnier or cloudier', ''], ['dz-scen:pesticides', 'Scenario: pesticides of the library', ''], ['dz-scen:pfas', 'Scenario: PFAS', ''], ['dz-scen:sorption', 'Scenario: sorption (K_OC)', '']] },
    { id: 'g-dproc', name: 'Process structure', icon: 'layers', items: [['dz-proc', 'Process map', ''], ['dz-proc:snow', 'Snowpack', ''], ['dz-proc:surf', 'Canopy, litter and surface pond', ''], ['dz-proc:water', 'Soil water', ''], ['dz-proc:pore', 'Biopores', ''], ['dz-proc:drain', 'Subsurface drainage', ''], ['dz-proc:temp', 'Soil heat and freezing', ''], ['dz-proc:no3', 'Nitrate', ''], ['dz-proc:nh4', 'Ammonium', ''], ['dz-proc:om', 'Soil organic matter pools', ''], ['dz-proc:carbon', 'Carbon balance', ''], ['dz-proc:deni', 'Denitrification and N2O', ''], ['dz-proc:photo', 'Photosynthesis', ''], ['dz-proc:crop', 'Crop growth', '']] },
    { id: 'g-dana', name: 'Results and analysis', icon: 'chart', items: [['dz-plot', 'Log plots and run data', ''], ['dz-balance', 'Mass balance', ''], ['dz-compare', 'Run comparison and tests (run library, two logs, two runs, many runs, double-blind)', '']] },
    { id: 'g-ddss', name: 'Decision support (SWAFL layers)', icon: 'chart', items: [['chem', 'Chemical fate (from my runs)', ''], ['dsum', 'Decision table (from my runs)', ''], ['dwb', 'Water balance (from my runs)', ''], ['dnb', 'Nitrogen balance (from my runs)', ''], ['dyr', 'Yield risk and limiting factor (from my runs)', ''], ['dchx', 'Chemicals and drinking water (from my runs)', ''], ['dtrd', 'Trade-offs and the best edge (from my runs)', ''], ['dirr', 'The return of irrigation (from my runs)', ''], ['dghg', 'Nitrous oxide and gaseous nitrogen (from my runs)', '']] },
    { id: 'g-dbuilt', name: 'Model development', icon: 'soil', items: [['dz-editor', 'Set-up editor (.dai)', ''], ['dz-build', 'Model builder (any Daisy model as a form)', ''], ['dz-richards', 'Soil column (Richards equation)', ''], ['dz-deni', 'Denitrification and N2O response curves', ''], ['dz-calib', 'Calibration', '']] },
    { id: 'g-ddoc', name: 'Documentation', icon: 'book', items: [['dz-learn', 'Learn the Daisy files (.dai, Common, a sample experiment)', ''], ['dz-docs', 'Model description and installation', ''], ['dz-refman', 'Daisy reference manual (every component and parameter)', ''], ['dz-manual', 'The SWAFL manual inside the program (every section, at its page)', '']] }
  ];
  // short names in the tree (the full name stays as the tooltip); the scenarios are listed under "Scenarios"
  const SHORT = { 'dz-library': 'Parameter library', 'dz-compare': 'Run comparison and tests', 'dz-build': 'Model builder',
    'dz-learn': 'Learn the Daisy files', 'dz-refman': 'Daisy reference manual', 'dz-manual': 'SWAFL manual',
    'dz-deni': 'Denitrification response curves',
    'dz-scen:irrigation': 'Irrigation strategy', 'dz-scen:nitrogen': 'Nitrogen and leaching', 'dz-scen:climate': 'Climate change',
    'dz-scen:chemical': 'Pesticide and tracer fate', 'dz-scen:soil': 'Sand against loam', 'dz-scen:own': 'Own Daisy set-up',
    'dz-scen:irrmethod': 'Irrigation method', 'dz-scen:trigger': 'When to irrigate', 'dz-scen:dose': 'Water per irrigation',
    'dz-scen:deficit': 'Deficit irrigation', 'dz-scen:sensor': 'Sensor depth', 'dz-scen:fertype': 'Fertiliser type',
    'dz-scen:manure': 'Slurry and manure', 'dz-scen:ntiming': 'When to fertilise', 'dz-scen:textures': 'Eight soil textures',
    'dz-scen:jbsoils': 'Danish soils JB1 to JB7', 'dz-scen:roots': 'Rooting depth', 'dz-scen:aquitard': 'Aquitard',
    'dz-scen:stations': 'Six European climates', 'dz-scen:radiation': 'Sunnier or cloudier', 'dz-scen:pesticides': 'Library pesticides',
    'dz-scen:sorption': 'Sorption (K_OC)' };
  const shortOf = it => SHORT[it[0]] || it[1].replace(/ \(from my runs\)$/, '').replace(/^Scenario: /, '');
  const DESIGN = ['sid', 'drip', 'spr', 'drn'];
  // the manual at the section of the layer in use (the manual is built into the program: js/daisymanual.js)
  const manBtn = id => { const M = window.SWAFLManual, sx = M && M.idx ? M.forLayer(id) : null; return '<button class="vb" data-man="' + (sx ? sx.page : 0) + '" title="' + UI.esc(sx ? 'The manual: ' + sx.title + ', page ' + sx.page : 'The manual') + '" style="margin-left:auto">&#128214; Manual' + (sx ? ' p. ' + sx.page : '') + '</button>'; };
  let dzCur = null, tabs = [], cur = null, started = false, collapsed = { 'g-water': true, 'g-ctrl': true, 'g-soil': true, 'g-pheno': true, 'g-mulch': true, 'g-loop': true, 'g-design': true, 'g-crop': true, 'g-year': true, 'g-chem': true, 'g-dss': true, 'g-dscen': true, 'g-ddss': true, 'droot': true, 'g-ddata': true, 'g-dproc': true, 'g-dana': true, 'g-dbuilt': true, 'g-ddoc': true, 'g-daisy': true, 's-sid': true, 's-drip': true, 's-spr': true }, sectionPick = {};
  const groupOf = id => { const g = GROUPS.find(x => x.items.some(i => i[0] === id)); return g && g.id; };
  const reveal = (id, sec) => { collapsed['root'] = false; const g = groupOf(id); if (g) collapsed[g] = false; if (sec) collapsed['s-' + id] = false; };
  const tree = document.getElementById('layerTree');

  const nameOf = id => { for (const g of GROUPS.concat(typeof DAISY !== 'undefined' ? DAISY : [])) for (const it of g.items) if (it[0] === id) return it[1]; return id; };
  const sections = id => { const s = (E.snap && E.snap.sec && E.snap.sec[id]) || {}; return Object.entries(s).sort((a, b) => a[1][0] - b[1][0]).map(e => e[0]); };

  function render() {
    const open = id => !collapsed[id];
    let h = '<div class="tn grp" data-id="root"><span class="tw">' + (open('root') ? '&#9660;' : '&#9654;') + '</span>' + UI.icon('folder') + '<span class="lbl">SWAFL project</span></div><div class="tkids" ' + (open('root') ? '' : 'hidden') + '>';
    GROUPS.forEach(g => {
      h += '<div class="tn grp" style="padding-left:14px" data-id="' + g.id + '"><span class="tw">' + (open(g.id) ? '&#9660;' : '&#9654;') + '</span>' + UI.icon(g.icon) + '<span class="lbl">' + g.name + '</span></div><div class="tkids" ' + (open(g.id) ? '' : 'hidden') + '>';
      g.items.forEach(it => {
        const subs = DESIGN.includes(it[0]) ? sections(it[0]) : [], hasKids = DESIGN.includes(it[0]), op = open('s-' + it[0]);
        h += '<div class="tn' + (cur === it[0] && !sectionPick[it[0]] ? ' sel' : '') + '" style="padding-left:30px" data-scene="' + it[0] + '"><span class="tw" data-twist="' + it[0] + '">' + (hasKids ? (op ? '&#9660;' : '&#9654;') : '') + '</span>' + UI.icon('doc') + '<span class="lbl">' + UI.esc(it[1]) + '</span>' + '</div>';
        if (hasKids) {
          h += '<div class="tkids" ' + (op ? '' : 'hidden') + '>';
          subs.forEach(t => { h += '<div class="tn' + (cur === it[0] && sectionPick[it[0]] === t ? ' sel' : '') + '" style="padding-left:58px" data-scene="' + it[0] + '" data-sec="' + UI.esc(t) + '" title="' + UI.esc(t) + '"><span class="lbl">' + UI.esc(short(t)) + '</span></div>'; });
          h += '</div>';
        }
      });
      h += '</div>';
    });
    h += '</div>';
    h += '<div class="tn grp" data-id="droot"><span class="tw">' + (open('droot') ? '&#9660;' : '&#9654;') + '</span>' + UI.icon('soil') + '<span class="lbl">Daisy model</span></div><div class="tkids" ' + (open('droot') ? '' : 'hidden') + '>';
    DAISY.forEach(g => {
      h += '<div class="tn grp" style="padding-left:14px" data-id="' + g.id + '"><span class="tw">' + (open(g.id) ? '&#9660;' : '&#9654;') + '</span>' + UI.icon(g.icon) + '<span class="lbl">' + g.name + '</span></div><div class="tkids" ' + (open(g.id) ? '' : 'hidden') + '>';
      const row = (it, sub) => '<div class="tn' + (dzCur === it[0] ? ' sel' : '') + (sub ? ' dzsub' : '') + '" style="padding-left:' + (sub ? 16 : 30) + 'px" data-scene="' + it[0] + '" title="' + UI.esc(it[1]) + '"><span class="tw"></span>' + (sub ? '' : UI.icon('doc')) + '<span class="lbl">' + UI.esc(shortOf(it)) + '</span></div>';
      const subs = g.items.filter(it => /^dz-scen:/.test(it[0]));
      g.items.forEach(it => {
        if (/^dz-scen:/.test(it[0])) return;
        h += row(it, false);
        if (it[0] === 'dz-scen' && subs.length) h += '<div class="tkids">' + subs.map(x => row(x, true)).join('') + '</div>';
      });
      h += '</div>';
    });
    h += '</div>';
    tree.innerHTML = h;
  }

  tree.addEventListener('click', e => {
    const tw = e.target.closest('[data-twist]');
    if (tw) { const k = 's-' + tw.dataset.twist; collapsed[k] = !collapsed[k]; render(); e.stopPropagation(); return; }
    const n = e.target.closest('.tn'); if (!n) return;
    if (n.dataset.id) { collapsed[n.dataset.id] = !collapsed[n.dataset.id]; render(); return; }
    open(n.dataset.scene, n.dataset.sec);
  });
  tree.addEventListener('contextmenu', e => {
    const n = e.target.closest('[data-scene]'); if (!n) return; e.preventDefault();
    UI.showMenu([{ label: 'Open layer', icon: 'open', act: () => open(n.dataset.scene, n.dataset.sec) }, { label: 'Go to top', act: () => { open(n.dataset.scene); E.scrollTop(); } }, { label: 'Close tab', act: () => closeTab(n.dataset.scene) }], e.clientX, e.clientY);
  });

  function open(id, sec) {
    try { if (window.SWBusy) { const hb = SWBusy.begin('Loading', { delay: 0 }); setTimeout(hb.end, 700); } } catch (e) {}
    if (String(id).indexOf('dz-') === 0) { dzCur = id; try { DaisyUI.open(id.slice(3)); } catch (e) { UI.log('Daisy workbench: ' + e.message); } render(); return; }
    if (!started) { started = true; document.body.classList.remove('nolayer'); }
    if (!tabs.includes(id)) tabs.push(id);
    sectionPick = {}; if (sec) sectionPick[id] = sec;
    const need = !E.snap || E.snap.scene !== id; if (need) E.scene(id);
    /* no waiting: the scene is drawn at once, so the scroll is instant; one short retry only if the sections are not yet known */
    if (sec) { if (!E.scrollTo(id, sec)) setTimeout(() => E.scrollTo(id, sec), 90); } else if (need) E.scrollTop();
    cur = id; reveal(id, sec); renderTabs(); render(); renderViewBar(); try { Dash.render(); } catch (e) {}
  }
  function closeTab(id) {
    if (tabs.length <= 1) return; const i = tabs.indexOf(id); tabs = tabs.filter(t => t !== id);
    if (cur === id) open(tabs[Math.max(0, i - 1)]); else renderTabs();
  }
  function renderTabs() {
    const el = document.getElementById('docTabs');
    el.innerHTML = tabs.map(t => '<div class="dt' + (t === cur ? ' on' : '') + '" data-t="' + t + '">' + UI.icon('doc') + '<span>' + UI.esc(nameOf(t)) + '</span>' + (tabs.length > 1 ? '<span class="x" data-x="' + t + '">&#10005;</span>' : '') + '</div>').join('');
  }
  document.getElementById('docTabs').addEventListener('click', e => {
    const x = e.target.closest('[data-x]'); if (x) { closeTab(x.dataset.x); return; }
    const t = e.target.closest('[data-t]'); if (t) open(t.dataset.t);
  });

  /* View bar: the working views of each design window, mapped to the drawing sections by heading. */
  const VIEWS = {
    sid: [['Layout design', /^Layout in plan/], ['Simulation', /^Longitudinal section/], ['Hydrograph', /^Hydrograph/], ['Advance and opportunity', /^Advance and opportunity/], ['Results', /^Performance indices/], ['Design table', /^Design table/]],
    drip: [['Simulation', /^Soil moisture around/], ['Lateral hydraulics', /^Uniformity along/], ['Layout and pipes', /^Layout and infrastructure/], ['Results', /^Result for this design/], ['Design table', /^Design table/]],
    spr: [['Layout design', /^Layout in plan/], ['Simulation', /^Along the lateral/], ['Pipes and pump', /^Pipes, pump/], ['Infrastructure layout', /^Layout and infrastructure/], ['Results', /^Result for this design/], ['Design checks', /^Does your design pass/], ['Design table', /^Design table/]]
  };
  const short = t => { const p = t.split(':')[0].replace(/^\s*\d+\s*[.)]\s*/, ''); return p.length > 64 ? p.slice(0, 61) + '...' : p; };
  function renderViewBar() {
    const el = document.getElementById('viewBar');
    if (!started) { el.innerHTML = ''; return; }
    if (DESIGN.includes(cur)) {
      const secs = sections(cur);
      let h = '<span class="vtitle">' + UI.esc(nameOf(cur)) + '</span>';
      h += '<button class="vb' + (!sectionPick[cur] ? ' on' : '') + '" data-top>Whole design</button>';
      (VIEWS[cur] || []).forEach(v => { const t = secs.find(x => v[1].test(x)); if (t) h += '<button class="vb' + (sectionPick[cur] === t ? ' on' : '') + '" data-sec="' + UI.esc(t) + '" title="' + UI.esc(t) + '">' + v[0] + '</button>'; });
      h += '<button class="vb run" data-vrun title="Run the design simulation, or run it again, without scrolling">&#9654; Run / re-run simulation</button>';
      h += manBtn(cur);
      el.innerHTML = h;
  } else {
      const sc = E.meta && E.metaData ? E.metaData.scenes.find(s => s[0] === cur) : null;
      el.innerHTML = '<span class="vtitle">' + UI.esc(nameOf(cur)) + '</span><span class="pnote">' + UI.esc(sc && sc[2] ? sc[2] : 'Use the Properties panel on the right to change the scenario. The picture updates live.') + '</span>' + manBtn(cur);
    }
  }
  document.getElementById('viewBar').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.hasAttribute('data-top')) { sectionPick = {}; E.scrollTop(); renderViewBar(); render(); return; }
    if (b.hasAttribute('data-vrun')) { E.ev("runDesign('" + cur + "')"); E.poll(true); const t = document.querySelector('#dashTabs [data-tab=design]'); if (t) t.click(); try { Dash.render(); } catch (e) {} return; }
    if (b.dataset.man != null) { const M = window.SWAFLManual; if (M) M.open(+b.dataset.man || 0); return; }
    if (b.dataset.sec) open(cur, b.dataset.sec);
  });

  function expandAll() { collapsed = {}; render(); }
  function collapseAll() { GROUPS.forEach(g => { collapsed[g.id] = true; }); DAISY.forEach(g => { collapsed[g.id] = true; }); collapsed['droot'] = true; collapsed['root'] = false; DESIGN.forEach(d => { collapsed['s-' + d] = true; }); render(); }
  /* "+" and "-" act on one group at a time: the group of the layer in use first, then the next closed one (Shift+click: all) */
  const ALLG = () => GROUPS.map(g => g.id).concat(DAISY.map(g => g.id));
  const curGroup = () => { const id = dzCur && String(cur || '').length === 0 ? dzCur : (cur || dzCur); const d = DAISY.find(g => g.items.some(i => i[0] === dzCur)); return (cur && groupOf(cur)) || (d && d.id) || null; };
  function expandOne() {
    const root = !collapsed['root'], g = curGroup(); if (collapsed['root']) { collapsed['root'] = false; render(); return; }
    if (g && collapsed[g]) { collapsed[g] = false; if (DAISY.some(x => x.id === g)) collapsed['droot'] = false; render(); return; }
    const nx = ALLG().find(id => collapsed[id]); if (nx) { collapsed[nx] = false; if (DAISY.some(x => x.id === nx)) collapsed['droot'] = false; render(); const el = tree.querySelector('[data-id="' + nx + '"]'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' }); }
  }
  function collapseOne() {
    const g = curGroup(); if (g && !collapsed[g]) { collapsed[g] = true; render(); return; }
    const open = ALLG().filter(id => !collapsed[id]); if (open.length) { collapsed[open[open.length - 1]] = true; render(); }
  }
  document.querySelector('#layersDock [data-act=expandAll]').onclick = e => e.shiftKey ? expandAll() : expandOne();
  document.querySelector('#layersDock [data-act=collapseAll]').onclick = e => e.shiftKey ? collapseAll() : collapseOne();

  E.on('scene', s => { if (!started) return; cur = s.scene; if (!tabs.includes(cur)) tabs.push(cur); renderTabs(); render(); renderViewBar(); });
  let lastSec = '';
  E.on('snap', ({ s }) => { const k = JSON.stringify(s.sec); if (k !== lastSec) { lastSec = k; render(); renderViewBar(); } });

  return { GROUPS, DAISY, render, open, renderTabs, renderViewBar, expandAll, collapseAll, nameOf, current: () => cur, started: () => started, DESIGN };
})();
