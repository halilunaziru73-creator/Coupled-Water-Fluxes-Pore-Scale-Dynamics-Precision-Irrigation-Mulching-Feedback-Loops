/* SWAFL bridge: the workbench talks to the simulation engine (iframe, same origin) through this object only. */
'use strict';
const E = (() => {
  const frame = document.getElementById('engine');
  const subs = {};
  const api = {
    frame, win: null, ready: false, snap: null, _last: '',
    on(ev, fn) { (subs[ev] = subs[ev] || []).push(fn); },
    emit(ev, a) { (subs[ev] || []).forEach(fn => { try { fn(a); } catch (e) { console.error(e); } }); },

    /* run code inside the engine (global scope, so let/const of the engine are visible) */
    ev(code) { try { return api.win.eval(code); } catch (e) { UI && UI.log('Engine: ' + e.message, 'err'); return undefined; } },
    json(expr) { const s = api.ev('JSON.stringify(' + expr + ')'); return s === undefined ? undefined : JSON.parse(s); },

    /* ---- navigation ---- */
    scene(id) { api.ev("window.__idleStart=false;switchScene(SCENES.find(function(s){return s.id==='" + id + "'})); window.__wake && window.__wake()"); api.poll(true); },
    scrollTo(sceneId, title) {
      const sec = api.json('window.__SEC||{}') || {}, m = (sec[sceneId] || {})[title]; if (!m) return false;
      const cv = api.win.document.getElementById('profileCanvas'), wrap = api.win.document.querySelector('.canvaswrap');
      if (cv && wrap) { wrap.scrollTo({ top: Math.max(0, m[0] * cv.clientWidth / m[1] - 34), behavior: 'instant' }); return true; }
      return false;
    },
    scrollTop() { const w = api.win && api.win.document.querySelector('.canvaswrap'); if (w) w.scrollTo({ top: 0, behavior: 'instant' }); },

    /* ---- state ---- */
    set(o) { api.ev('applyState(' + JSON.stringify(o) + ')'); api.poll(true); },
    setMulch(k) { api.ev("setMulch('" + k + "')"); api.poll(true); },
    setYear(v) { const s = api.win.document.getElementById('dssYear'); if (s) { s.value = v; s.dispatchEvent(new Event('change', { bubbles: true })); } api.poll(true); },
    setDate(v) { const s = api.win.document.getElementById('dssDate'); if (s) { s.value = v; s.dispatchEvent(new Event('change', { bubbles: true })); } api.poll(true); },
    preset(v) { const s = api.win.document.getElementById('guiPreset'); if (s) { s.value = v; s.dispatchEvent(new Event('change', { bubbles: true })); } api.poll(true); },
    click(id) { const b = api.win.document.getElementById(id); if (b) b.click(); api.poll(true); },
    togglePlay() { api.click('playBtn'); },
    restart() { api.ev('play.t=0;play.on=true;play.hold=0;'); const b = api.win.document.getElementById('playBtn'); if (b) b.textContent = 'Pause'; api.poll(true); },
    reset() { api.ev('applyState(' + JSON.stringify(api.defaults) + ')'); api.poll(true); },
    setFit(m) { try { api.win.__setFit(m); } catch (e) {} },
    redraw() { api.ev('refresh()'); },
    canvasPNG() { const c = api.win.document.getElementById('profileCanvas'); return c ? c.toDataURL('image/png') : null; },
    print() { try { api.win.focus(); api.win.print(); } catch (e) { window.print(); } },

    /* ---- snapshot of everything the panels need ---- */
    take() {
      return api.json(`(function(){
        var g=function(i){var e=document.getElementById(i);return e?e.textContent:''};
        var o={state:state,scene:currentScene.id,sceneLabel:currentScene.label,playOn:play.on,playT:play.t,
          vals:{tc:g('tcVal'),vff:g('vffVal'),cap:g('capVal'),rain:g('rainVal'),temp:g('tempVal'),trig:g('trigVal'),z:g('zVal'),n:g('nVal')},
          ro:{evap:g('roEvap'),drain:g('roDrain'),irr:g('roIrr'),yield:g('roYield'),transp:g('roTransp'),et:g('roET'),nl:g('roNL'),ie:g('roIE'),rain:g('roRain'),baseIrr:g('roBaseIrr')},
          year:(document.getElementById('dssYear')||{}).value,date:isoDate(dateOfK(fclock.kd())),dateLbl:fmtDate(dateOfK(fclock.kd())),
          sec:window.__SEC||{},wx:(typeof wxStatus==='function'?wxStatus():{src:'record'})};
        return o;})()`);
    },
    poll(force) {
      if (!api.ready) return;
      let s; try { s = api.take(); } catch (e) { return; } if (!s) return;
      const str = JSON.stringify(s);
      if (!force && str === api._last) return;
      // while a layer plays its own season or sweep, the rest of the window keeps your settings and date: it follows again on pause
      let busy = false; try { busy = !!api.ev("(function(){var id=currentScene&&currentScene.id;return ((id==='n1'||id==='r1')&&n1ui.play)||(typeof SWEEPS!=='undefined'&&SWEEPS[id]&&SWEEPS[id].keys.length&&AUTO.on)})()"); } catch (e) {}
      if (busy && api.snap && !force) return;
      const prev = api.snap; api._last = str; api.snap = s;
      api.emit('snap', { s, prev });
      if (!prev || prev.scene !== s.scene) api.emit('scene', s);
      if (!prev || JSON.stringify(prev.state) !== JSON.stringify(s.state) || prev.year !== s.year || prev.date !== s.date || (prev.wx && prev.wx.key) !== (s.wx && s.wx.key)) api.emit('state', s);
    },

    /* ---- data from the engine ---- */
    meta() {
      return api.json(`({soils:DATA.soils,soilLabels:DATA.soil_labels,texture:DATA.texture,tills:TILL_LABELS,crops:Object.keys(CROPS).map(function(k){return[k,CROPS[k].label]}),
        cropGroups:window.CROP_GROUPS?CROP_GROUPS.map(function(g){return[g[0],g[1].filter(function(k){return CROPS[k]}).map(function(k){return[k,CROPS[k].label]})]}):null,
        methods:METHODS.map(function(m){return[m.k,m.label]}),mulches:MULCHES.map(function(m){return[m.k,m.label]}),
        scenes:SCENES.map(function(s){return[s.id,s.label,s.title||'']}),
        presets:[].map.call(document.querySelectorAll('#guiPreset option'),function(o){return[o.value,o.textContent]}),
        years:[].map.call(document.querySelectorAll('#dssYear option'),function(o){return[o.value,o.textContent]}),
        defaults:state,NYR:NYR,DPY:DPY})`);
    },
    day() {
      return api.json(`(function(){var sim=seasonSim(true),rows=dssRows(sim),adv=dssAdvice(sim,rows),k=fclock.kd(),r0=rows[0],nx=rows.slice(1),yt=yearTable(sim)[yearOf(k)]||{},dp=window.dayPlan?window.dayPlan(Math.floor(k)):null;
        if(dp){r0=Object.assign({},r0,{rain:dp.rain,evap:dp.evap,irr:dp.irr,tr:dp.tr,dr:dp.dr});}
        return{date:fmtDate(dateOfK(k)),like:1980+yearOf(k),mode:dss.mode,N:dss.ahead,head:adv.head,text:adv.text,tone:adv.tone,crop:dp?dp.crop:cropShown(sim,k),rd:dp?dp.rd:sim.rd[k],f:dp?dp.f:r0.f,fT:sim.fTrigRaw,
        rain:r0.rain,evap:r0.evap,irr:r0.irr,tr:r0.tr,dr:r0.dr,fc:(window.WXD&&WXD.on&&WXD.src==='online'&&WXD.fcStart!=null&&Math.abs(Date.UTC(dateOfK(k).getUTCFullYear(),dateOfK(k).getUTCMonth(),dateOfK(k).getUTCDate())-WXD.fcStart)<17*864e5)?1:0,next:dp?dp.next:{rain:sumKey(nx,'rain'),irr:sumKey(nx,'irr'),evap:sumKey(nx,'evap'),tr:sumKey(nx,'tr'),dr:sumKey(nx,'dr')},year:yt}})()`);
    },
    season() {
      return api.json(`(function(){var r=seasonSim(true);var f=function(a){return a?Array.prototype.slice.call(a):[]};
        return{yI:f(r.yI),yD:f(r.yD),yRain:f(r.yRain),yE:f(r.yE),yT:f(r.yT),yR:f(r.yR),meanIrr:r.meanIrr,meanDrain:r.meanDrain,cal0:CAL0}})()`);
    },
    // the day by day water of the twenty seasons, for the scientific figure of the Charts tab
    seasonDaily() {
      return api.json(`(function(){var r=seasonSim(true),n=NYR*DPY,a=AWC[state.soil]*DZ,k=24,o={rain:[],irr:[],drain:[],E:[],T:[],cover:[],wf:[]};var q=function(v){return Math.round(v*100)/100};
        for(var d=0;d<n;d++){o.rain.push(q(r.rain[d]));o.irr.push(q(r.irr[d]));o.drain.push(q(r.drain[d]));o.E.push(q(r.dE[d]));o.T.push(q(r.dT[d]));o.cover.push(q(r.cover[d]));var s=r.s[d],t=0;for(var i=0;i<k;i++)t+=s[i];o.wf.push(Math.round(1000*t/(k*a))/1000)}
        var y=(typeof dss!=='undefined'&&dss.ay0!=null)?dss.ay0:NYR-1;o.sel=Math.max(0,Math.min(NYR-1,y));o.cal0=CAL0;o.nyr=NYR;o.dpy=DPY;o.trig=r.fTrig;o.proj=(window.projPlan&&window.projN&&window.projN())?{n:window.projN(),F:window.projPlan(window.projN()),note:window.projNote()}:null;return o})()`);
    },
    design(scene) {
      const fn = { sid: 'sidRun', drip: 'drRun', spr: 'spRun' }[scene]; if (!fn) return null;
      return api.json(`(function(){var R=${fn}();var o={};for(var k in R){if(typeof R[k]==='number'&&isFinite(R[k]))o[k]=R[k];else if(typeof R[k]==='string')o[k]=R[k]}return o})()`);
    },
    optimiseSurface() { return api.ev('(function(){try{sidApply(SIDOPT.best.d);return true}catch(e){return false}})()'); },

    /* ---- start-up ---- */
    start() {
      return new Promise(res => {
        const t0 = Date.now(), iv = setInterval(() => {
          try {
            const w = frame.contentWindow;
            if (w && w.document.getElementById('profileCanvas') && w.eval("typeof SCENES!=='undefined'&&typeof state!=='undefined'&&typeof switchScene==='function'&&typeof DATA!=='undefined'")) {
              clearInterval(iv); api.win = w; api.ready = true;
              api.defaults = JSON.parse(w.eval('JSON.stringify(state)')); api.setFit('window');
              // visit the three design scenes once so their section headings become layer sub-nodes
              const keep = w.eval('currentScene.id'), sw = id => { try { w.eval("switchScene(SCENES.find(function(s){return s.id==='" + id + "'})); try{currentScene.draw&&currentScene.draw();if(currentScene.id==='sid')currentScene.draw()}catch(e){}"); } catch (e) {} };
              /* The headings of the three design layers do not change between starts, so after the first start they are kept and the three drawings (about a second and a half of work at every start) are not repeated. */
              const verK = 'swafl.secs.' + ((new URL(frame.src, location.href)).searchParams.get('v') || '0'); let cached = null; try { cached = JSON.parse(localStorage.getItem(verK) || 'null'); } catch (e) {}
              const fin = () => setTimeout(() => { const t = new Date(), p = n => String(n).padStart(2, '0'); api.setDate(t.getFullYear() + '-' + p(t.getMonth() + 1) + '-' + p(t.getDate())); api.ev('dssHold()'); api.poll(true); res(true); }, cached ? 0 : 300);
              if (cached && cached.sid && cached.drip && cached.spr) { try { w.eval('window.__SEC=Object.assign(window.__SEC||{},' + JSON.stringify(cached) + ')'); fin(); return; } catch (e) { cached = null; } }
              const seq = ['sid', 'drip', 'spr', keep]; let i = 0;
              (function step() { sw(seq[i]); i++; if (i < seq.length) setTimeout(step, 20); else { try { const sc = JSON.parse(w.eval('JSON.stringify(window.__SEC||{})')); if (sc.sid && sc.drip && sc.spr) { for (const k in localStorage) if (k.indexOf('swafl.secs.') === 0 && k !== verK) localStorage.removeItem(k); localStorage.setItem(verK, JSON.stringify({ sid: sc.sid, drip: sc.drip, spr: sc.spr })); } } catch (e) {} fin(); } })();
            } else if (Date.now() - t0 > 40000) { clearInterval(iv); res(false); }
          } catch (e) { /* not loaded yet */ }
        }, 150);
      });
    }
  };
  Guard.every(() => { if (!document.hidden) api.poll(false); }, 900, "bridge116");
  return api;
})();

/* a click anywhere in the program wakes the picture: it was drawn only every 0.3 to 0.6 s while the window around it had the focus, which made a layer appear late */
document.addEventListener('pointerdown', () => { try { const w = document.getElementById('engine').contentWindow; w.__wake && w.__wake(); } catch (e) {} }, true);
document.addEventListener('keydown', () => { try { const w = document.getElementById('engine').contentWindow; w.__wake && w.__wake(); } catch (e) {} }, true);
