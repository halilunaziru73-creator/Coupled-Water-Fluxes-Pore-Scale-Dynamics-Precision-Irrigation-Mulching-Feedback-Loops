/* A small code editor for the files of Daisy: the colours of VS Code (Dark+ and Light+ themes), line numbers, find, the
   cursor position and a check of the brackets of .dai files. Used where files are shown: the experiment folder before it is
   saved, the parameter library and the tutorial. The text is edited in place and given back with onChange. */
(function (root) {
  'use strict';
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const C = {};
  C.LANGS = { dai: 'Daisy set-up (.dai)', dwf: 'Daisy weather (.dwf)', dlf: 'Daisy log (.dlf)', json: 'JSON', csv: 'CSV table', sh: 'Shell script', bat: 'Windows batch', txt: 'Text', md: 'Markdown' };
  C.lang = function (name) { const n = String(name || '').toLowerCase(), e = (n.match(/\.([a-z0-9]+)$/) || [])[1] || 'txt'; if (e === 'dai' || e === 'daisy') return 'dai'; if (e === 'dwf') return 'dwf'; if (e === 'dlf') return 'dlf'; if (e === 'json') return 'json'; if (e === 'csv' || e === 'tsv') return 'csv'; if (e === 'sh') return 'sh'; if (e === 'bat' || e === 'cmd') return 'bat'; if (e === 'md') return 'md'; return 'txt'; };
  const sp = (c, t) => '<span class="' + c + '">' + esc(t) + '</span>';
  // the colouring of each kind of file, line by line where the file has lines
  const HL = {
    dai: t => root.DaisyIO && root.DaisyIO.highlightDai ? root.DaisyIO.highlightDai(t) : esc(t),
    json: t => esc(t).replace(/(&quot;|")((?:\\.|[^"\\])*)"(\s*:)?|\b(true|false|null)\b|(-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b)/g, (m, q, s, colon, kw, num) => colon ? '<span class="dfn">"' + s + '"</span>' + colon : q ? '<span class="dst">"' + s + '"</span>' : kw ? '<span class="dkw">' + kw + '</span>' : '<span class="dnu">' + num + '</span>'),
    csv: t => { const cls = ['dfn', 'dst', 'dnu', 'ddf', 'dun', 'dkw', 'dph']; return t.split('\n').map(l => { let k = 0, o = '', cur = '', inq = false; for (let i = 0; i < l.length; i++) { const ch = l[i]; if (ch === '"') inq = !inq; if ((ch === ',' || ch === ';' || ch === '\t') && !inq) { o += sp(cls[k % cls.length], cur) + esc(ch); cur = ''; k++; } else cur += ch; } return o + (cur ? sp(cls[k % cls.length], cur) : ''); }).join('\n'); },
    sh: t => t.split('\n').map(l => /^\s*#/.test(l) ? sp('dcm', l) : esc(l).replace(/\b(for|do|done|in|if|then|fi|cd|echo|exit)\b/g, '<span class="dkw">$1</span>').replace(/(&quot;|")([^"]*)"/g, '<span class="dst">"$2"</span>').replace(/\b(daisy)\b/g, '<span class="dfn">$1</span>')).join('\n'),
    bat: t => t.split('\n').map(l => /^\s*(rem\b|::)/i.test(l) ? sp('dcm', l) : esc(l).replace(/\b(for|do|in|if|echo|off|pushd|popd|set|call)\b/gi, '<span class="dkw">$1</span>').replace(/(%%?\w)/g, '<span class="dun">$1</span>').replace(/\b(daisy)\b/g, '<span class="dfn">$1</span>')).join('\n'),
    dwf: t => { let body = false, cols = 0; return t.split('\n').map(l => { if (body) { cols++; return cols <= 2 ? sp(cols === 1 ? 'dfn' : 'dun', l) : esc(l).replace(/(-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b)/g, '<span class="dnu">$1</span>'); } if (/^-{5,}/.test(l)) { body = true; return sp('dcm', l); } if (/^\s*#/.test(l)) return sp('dcm', l); const k = l.indexOf(':'); if (/^dwf-|^dlf-/i.test(l)) return sp('ddf', l); return k > 0 ? sp('dkw', l.slice(0, k)) + esc(':') + sp('dst', l.slice(k + 1)) : esc(l); }).join('\n'); },
    // text: one pass over each line, so a colour never lands inside the mark-up of another one
    txt: t => t.split('\n').map((l, i, a) => { if (/^\s*[=\-]{5,}\s*$/.test(l)) return sp('dcm', l); if (/^[A-Z0-9][A-Z0-9 ,.()'&\/-]{3,}$/.test(l.trim()) || (a[i + 1] && /^\s*={5,}/.test(a[i + 1]))) return sp('ddf', l);
      const re = /(\([a-z_]+(?=[\s)]))|("[^"]*")|(\[[^\]\s]{1,24}\])|((?:\.\.\/)?(?:[A-Za-z0-9_\-]+\/)+[A-Za-z0-9_\-.*<>]+|\*?[A-Za-z0-9_\-]+\.(?:dai|dwf|dlf|csv|json|sh|bat|txt))|((?:^|(?<=[\s=(,:]))-?\d+(?:\.\d+)?(?=[\s,).;:x%]|$))/g; let o = '', k = 0, m;
      while ((m = re.exec(l))) { if (!m[0]) { re.lastIndex++; continue; } o += esc(l.slice(k, m.index)) + sp(m[1] ? 'dfn' : m[2] ? 'dst' : m[3] ? 'dun' : m[4] ? 'dph' : 'dnu', m[0]); k = m.index + m[0].length; } return o + esc(l.slice(k)); }).join('\n'),
  };
  HL.dlf = HL.dwf; HL.md = t => t.split('\n').map(l => /^#{1,6} /.test(l) ? sp('ddf', l) : /^\s*[-*] /.test(l) ? sp('dkw', l.match(/^\s*[-*] /)[0]) + esc(l.replace(/^\s*[-*] /, '')) : /^```/.test(l) ? sp('dcm', l) : esc(l).replace(/(`[^`]+`)/g, '<span class="dst">$1</span>')).join('\n');
  C.highlight = (text, lang) => { const t = String(text || ''); if (t.length > 600000) return esc(t); try { return (HL[lang] || HL.txt)(t); } catch (e) { return esc(t); } };
  const CSS = '.dzc{display:flex;flex-direction:column;min-height:0;height:100%;border:1px solid #3c3c3c;border-radius:4px;overflow:hidden;font:12.5px/18px Consolas,"Cascadia Mono","Courier New",monospace}' +
    '.dzc-bar{display:flex;gap:6px;align-items:center;padding:3px 8px;font:12px Tahoma,Segoe UI,sans-serif;flex-wrap:wrap}.dzc-bar button,.dzc-bar input{font:11.5px Tahoma,Segoe UI,sans-serif;padding:2px 8px;border-radius:3px;cursor:pointer}.dzc.dark .dzc-bar button{background:#3a3d41;color:#e7e7e7;border:1px solid #555}.dzc.dark .dzc-bar button:hover{background:#45494e}.dzc.dark .dzc-bar input{background:#3c3c3c;color:#e7e7e7;border:1px solid #555}.dzc.light .dzc-bar button{background:#fff;color:#222;border:1px solid #bbb}.dzc.light .dzc-bar button:hover{background:#e8e8e8}.dzc-bar button[data-c=save]{background:#0e639c!important;color:#fff!important;border-color:#0e639c!important}.dzc-bar .dzc-t{font-weight:600;margin-right:auto;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:60%}' +
    '.dzc-body{flex:1;display:flex;min-height:0;position:relative}.dzc-g{padding:6px 8px 6px 4px;text-align:right;user-select:none;overflow:hidden;white-space:pre;min-width:38px}' +
    '.dzc-w{flex:1;position:relative;min-width:0}.dzc-w pre,.dzc-w textarea{position:absolute;inset:0;margin:0;padding:6px 10px;border:0;font:inherit;white-space:pre;overflow:auto;tab-size:2;-moz-tab-size:2;box-sizing:border-box;letter-spacing:0}' +
    '.dzc-w pre{pointer-events:none}.dzc-w textarea{background:transparent;color:transparent;resize:none;outline:none}.dzc.wrap .dzc-w pre,.dzc.wrap .dzc-w textarea{white-space:pre-wrap;word-break:break-all}' +
    '.dzc-s{display:flex;gap:14px;padding:2px 10px;font:11px Tahoma,Segoe UI,sans-serif}.dzc-s span:last-child{margin-left:auto}' +
    '.dzc.dark{background:#1e1e1e}.dzc.dark .dzc-bar{background:#252526;color:#ccc;border-bottom:1px solid #3c3c3c}.dzc.dark .dzc-g{background:#1e1e1e;color:#858585}.dzc.dark pre{color:#d4d4d4}.dzc.dark textarea{caret-color:#aeafad}.dzc.dark textarea::selection{background:rgba(38,79,120,.85);color:transparent}.dzc.dark .dzc-s{background:#007acc;color:#fff}' +
    '.dzc.dark .dcm{color:#6a9955}.dzc.dark .dst{color:#ce9178}.dzc.dark .dnu{color:#b5cea8}.dzc.dark .dun{color:#4ec9b0}.dzc.dark .dph{color:#d7ba7d}.dzc.dark .ddf{color:#c586c0;font-weight:600}.dzc.dark .dkw{color:#569cd6}.dzc.dark .dfn{color:#9cdcfe}' +
    '.dzc.light{background:#fff;border-color:#c8c8c8}.dzc.light .dzc-bar{background:#f3f3f3;color:#333;border-bottom:1px solid #ddd}.dzc.light .dzc-g{background:#fff;color:#237893}.dzc.light pre{color:#000}.dzc.light textarea{caret-color:#000}.dzc.light textarea::selection{background:rgba(173,214,255,.9);color:transparent}.dzc.light .dzc-s{background:#007acc;color:#fff}' +
    '.dzc.npp{background:#fff}.dzc.npp .dzc-bar{background:#f0f0f0;color:#000;border-bottom:1px solid #c0c0c0}.dzc.npp .dzc-g{background:#e4e4e4;color:#808080;border-right:1px solid #c0c0c0}.dzc.npp pre{color:#000;font-family:Consolas,"Courier New",monospace}.dzc.npp textarea{font-family:Consolas,"Courier New",monospace}.dzc.npp textarea::selection{background:rgba(192,192,192,.9);color:transparent}.dzc.npp .dcm{color:#008000!important}.dzc.npp .dst{color:#808080!important}.dzc.npp .dnu{color:#ff8000!important}.dzc.npp .dun{color:#8000ff!important}.dzc.npp .dph{color:#0080c0!important}.dzc.npp .ddf{color:#0000ff!important;font-weight:700}.dzc.npp .dkw{color:#0000ff!important;font-weight:700}.dzc.npp .dfn{color:#000080!important;font-weight:700}' +
    '.dzc.light .dcm{color:#008000}.dzc.light .dst{color:#a31515}.dzc.light .dnu{color:#098658}.dzc.light .dun{color:#267f99}.dzc.light .dph{color:#795e26}.dzc.light .ddf{color:#af00db;font-weight:600}.dzc.light .dkw{color:#0000ff}.dzc.light .dfn{color:#001080}' +
    '.dzc-w pre,.dzc-w textarea,.dzc-g{line-height:18px!important}.dzc-w pre.virt,.dzc-g.virt{overflow:hidden!important}.dzc-w pre.virt>div,.dzc-g.virt>div{will-change:transform}.dzc.dzc-full{position:fixed;inset:0;z-index:100005;height:100vh!important;border-radius:0}.dzc-big{position:absolute;inset:0;overflow:auto;outline:none}.dzc-big .dzc-sp{width:1px;height:1px}.dzc.ro textarea{cursor:default}.dzc-dirty{color:#e2c08d}';
  function css() { if (document.getElementById('dzcCss')) return; const s = document.createElement('style'); s.id = 'dzcCss'; s.textContent = CSS; document.head.appendChild(s); }
  let theme = 'dark'; try { theme = localStorage.getItem('swafl.codeTheme') || 'dark'; } catch (e) { }
  /* host: element; o: { text, name, lang, readOnly, onChange(text), onSave(text), extra: [[label, fn(text)]] } */
  C.editor = function (host, o) {
    css(); o = o || {}; let lang = o.lang || C.lang(o.name), text = String(o.text == null ? '' : o.text).replace(/\r\n/g, '\n'), orig = text, wrap = false;
    const th = o.theme || theme, cls = th === 'npp' ? 'light npp' : th;
    host.innerHTML = '<div class="dzc ' + cls + (o.readOnly ? ' ro' : '') + '"><div class="dzc-bar"><span class="dzc-t">' + esc(o.name || '') + ' <span class="dzc-dirty" data-c="dirty"></span></span>' +
      '<input data-c="find" placeholder="find (Ctrl+F)" style="width:130px"><button data-c="next" title="Next match (Enter)">&darr;</button><button data-c="wrap" title="Wrap long lines">wrap</button><button data-c="full" title="Full screen (Esc to leave)">&#x26F6; full screen</button><button data-c="theme" title="The colours: VS Code dark, VS Code light or Notepad++">' + 'colours' + '</button>' +
      (o.readOnly ? '' : '<button data-c="undo" title="Back to the text as it was opened">undo all</button>') + (o.extra || []).map((x, i) => '<button data-c="x' + i + '">' + esc(x[0]) + '</button>').join('') + (o.onSave ? '<button data-c="save" style="font-weight:600" title="Keep the changes (Ctrl+S)">Save changes</button>' : '') + '</div>' +
      '<div class="dzc-body"><div class="dzc-g" data-c="g"></div><div class="dzc-w"><pre data-c="pre"></pre><textarea data-c="ta" spellcheck="false" wrap="off"' + (o.readOnly ? ' readonly' : '') + '></textarea></div></div>' +
      '<div class="dzc-s"><span data-c="pos">Ln 1, Col 1</span><span data-c="info"></span><span data-c="lang">' + esc(C.LANGS[lang] || lang) + '</span></div></div>';
    const q = k => host.querySelector('[data-c="' + k + '"]'), box = host.firstChild, pre = q('pre'), g = q('g');
    /* a large file (above 250 kB) is shown by a viewer: a scrolling box with the height of the whole file and only the lines in view drawn, so that a log of
       several megabytes opens at once and scrolls smoothly (a text box holding the whole file is laid out in full by the browser, which took seconds).
       It is read-only; small files keep the full editor. */
    const BIGF = text.length > 250000; let ta, TX = text, lcTX = null, lastEnd = 0;
    if (BIGF) {
      const old = q('ta'), d = document.createElement('div'); d.setAttribute('data-c', 'ta'); d.className = 'dzc-big'; d.tabIndex = 0; d.innerHTML = '<div class="dzc-sp"></div>'; old.replaceWith(d);
      pre.parentNode.appendChild(pre); pre.style.cssText = 'pointer-events:auto;inset:0 17px 17px 0;user-select:text;cursor:text'; pre.addEventListener('wheel', e => { d.scrollTop += e.deltaY; d.scrollLeft += e.deltaX; e.preventDefault(); }, { passive: false });
      Object.defineProperties(d, { value: { get: () => TX, set: v => { TX = String(v); lcTX = null; } }, selectionStart: { get: () => 0 }, selectionEnd: { get: () => lastEnd } });
      d.setSelectionRange = (a, b) => { lastEnd = b; }; d.setRangeText = () => { }; ta = d; if (q('undo')) q('undo').style.display = 'none'; if (q('save')) q('save').style.display = 'none';
    } else ta = q('ta');
    ta.value = text; let raf = 0;
    /* only the lines in view are coloured and numbered (and 40 lines around them), so a log of several megabytes opens and scrolls at once;
       the text itself stays in the text box. With wrap on, a long file is shown whole only below 300 kB */
    const LH = 18, BIG = 300000; let lines = text.split('\n'), r0 = -1, r1 = -1, virt = true;
    const sizeSp = () => { if (!BIGF) return; let mx = 0; for (let i = 0; i < lines.length; i++) if (lines[i].length > mx) mx = lines[i].length; const sp = ta.firstChild; sp.style.height = ((lines.length + 2) * LH + 20) + 'px'; sp.style.width = (Math.min(mx, 6000) * 7.7 + 60) + 'px'; }; sizeSp();
    const nums = (a, b) => { let s0 = ''; for (let i = a + 1; i <= b; i++) s0 += i + '\n'; return s0; };
    const render = force => { if (!virt) return; const top = ta.scrollTop, h = ta.clientHeight || 600, v0 = Math.floor(top / LH), v1 = Math.ceil((top + h) / LH);
      if (force || v0 < r0 || v1 > r1 || r0 < 0) { r0 = Math.max(0, v0 - 40); r1 = Math.min(lines.length, v1 + 40); pre.innerHTML = '<div>' + hl(r0, r1) + '\n</div>'; g.innerHTML = '<div>' + nums(r0, r1) + '</div>'; }
      const y = r0 * LH - top; if (pre.firstChild) pre.firstChild.style.transform = 'translate(' + (-ta.scrollLeft) + 'px,' + y + 'px)'; if (g.firstChild) g.firstChild.style.transform = 'translateY(' + y + 'px)'; };
    // the colours of a slice of a log: the header of the log is coloured with it (and cut off again), so the numbers keep their colours
    const hl = (a, b) => { const chunk = lines.slice(a, b).join('\n'); if (lang !== 'dlf' || a === 0) return C.highlight(chunk, lang); let k = -1; for (let i = 0; i < Math.min(lines.length, 400); i++) if (/^-{5,}\s*$/.test(lines[i])) { k = i; break; } if (k < 0 || a <= k + 2) return C.highlight(lines.slice(0, b).join('\n'), lang).split('\n').slice(a).join('\n');
      const pre0 = lines.slice(0, k + 3), out = C.highlight(pre0.join('\n') + '\n' + chunk, lang).split('\n'); return out.slice(pre0.length).join('\n'); };
    const setVirt = on => { virt = on; pre.classList.toggle('virt', on); g.classList.toggle('virt', on); r0 = -1; };
    const gutter = () => { if (virt) return; const n = lines.length; g.textContent = nums(0, n); };
    const check = () => { const n = lines.length; let msg = n + ' lines'; if (lang === 'dai' && root.DaisyIO && root.DaisyIO.parseDai && ta.value.length < 300000) { try { const a = root.DaisyIO.parseDai(ta.value); msg += a.errors.length ? ' · ' + a.errors[0] : ' · brackets and quotes balanced'; } catch (e) { msg += ' · ' + e.message; } } if (lang === 'json') { try { JSON.parse(ta.value); msg += ' · valid JSON'; } catch (e) { msg += ' · ' + e.message; } } q('info').textContent = msg; q('dirty').textContent = ta.value !== orig ? '● edited' : ''; };
    const paint = () => { raf = 0; if (!BIGF) lines = ta.value.split('\n'); if (virt) render(true); else { pre.innerHTML = C.highlight(ta.value, lang) + '\n'; gutter(); pre.scrollTop = ta.scrollTop; pre.scrollLeft = ta.scrollLeft; g.scrollTop = ta.scrollTop; } check(); };
    let tmo = 0; const later = () => { if (ta.value.length > BIG) { clearTimeout(tmo); tmo = setTimeout(paint, 150); } else if (!raf) raf = requestAnimationFrame(paint); };
    setVirt(true); if (root.ResizeObserver) { const ro = new ResizeObserver(() => { if (!ta.isConnected) { ro.disconnect(); return; } render(true); }); ro.observe(ta); }
    const pos = () => { if (BIGF) { q('pos').textContent = 'Ln ' + (Math.floor(ta.scrollTop / LH) + 1) + ' of ' + lines.length; return; } const v = ta.value.slice(0, ta.selectionStart).split('\n'); q('pos').textContent = 'Ln ' + v.length + ', Col ' + (v[v.length - 1].length + 1) + (ta.selectionEnd > ta.selectionStart ? ' (' + (ta.selectionEnd - ta.selectionStart) + ' selected)' : ''); };
    let sraf = 0; ta.addEventListener('scroll', () => { if (virt) { if (!sraf) sraf = requestAnimationFrame(() => { sraf = 0; render(false); if (BIGF) pos(); }); return; } pre.scrollTop = ta.scrollTop; pre.scrollLeft = ta.scrollLeft; g.scrollTop = ta.scrollTop; }, { passive: true });
    ta.addEventListener('input', () => { later(); if (o.onChange) o.onChange(ta.value); });
    let praf = 0; ['keyup', 'click', 'select'].forEach(ev => ta.addEventListener(ev, () => { if (!praf) praf = requestAnimationFrame(() => { praf = 0; pos(); }); }));
    const find = back => { const f = q('find').value; if (!f) return; const v = BIGF ? (lcTX || (lcTX = TX.toLowerCase())) : ta.value.toLowerCase(), s = f.toLowerCase(); let i = v.indexOf(s, ta.selectionEnd); if (i < 0) i = v.indexOf(s); if (i < 0) { q('info').textContent = '"' + f + '" not found'; return; } ta.focus(); ta.setSelectionRange(i, i + f.length); const ln = ta.value.slice(0, i).split('\n').length; ta.scrollTop = Math.max(0, (ln - 5) * 18); pos(); };
    ta.addEventListener('keydown', e => {
      if (e.key === 'Tab' && !o.readOnly) { e.preventDefault(); const s = ta.selectionStart, en = ta.selectionEnd; ta.setRangeText('  ', s, en, 'end'); later(); if (o.onChange) o.onChange(ta.value); }
      else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') { e.preventDefault(); q('find').focus(); q('find').select(); }
      else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && o.onSave) { e.preventDefault(); save(); }
      else if (e.key === 'Enter' && !o.readOnly) { const s = ta.selectionStart, line = ta.value.slice(0, s).split('\n').pop(), ind = (line.match(/^\s*/) || [''])[0] + (/\([^()]*$/.test(line) && lang === 'dai' ? '  ' : ''); if (ind) { e.preventDefault(); ta.setRangeText('\n' + ind, s, ta.selectionEnd, 'end'); later(); if (o.onChange) o.onChange(ta.value); } }
      e.stopPropagation(); });
    q('find').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); find(); } e.stopPropagation(); });
    q('next').onclick = () => find(); q('wrap').onclick = () => { if (!wrap && ta.value.length > BIG) { q('info').textContent = 'wrap is off for files above 300 kB, so that they stay quick'; return; } wrap = !wrap; box.classList.toggle('wrap', wrap); ta.setAttribute('wrap', wrap ? 'soft' : 'off'); g.style.visibility = wrap ? 'hidden' : ''; setVirt(!wrap); paint(); };
    const esc0 = e => { if (e.key === 'Escape' && box.classList.contains('dzc-full')) { e.preventDefault(); e.stopPropagation(); full(false); } };
    const full = on => { box.classList.toggle('dzc-full', on); q('full').innerHTML = on ? '&#x2715; leave full screen' : '&#x26F6; full screen'; if (on) document.addEventListener('keydown', esc0, true); else document.removeEventListener('keydown', esc0, true); paint(); if (on) ta.focus(); };
    q('full').onclick = () => full(!box.classList.contains('dzc-full'));
    let cur = th; const nxt = t => t === 'dark' ? 'light' : t === 'light' ? 'npp' : 'dark', lab = t => ({ dark: 'VS Code dark', light: 'VS Code light', npp: 'Notepad++' })[nxt(t)];
    q('theme').textContent = lab(cur); q('theme').onclick = () => { cur = nxt(cur); theme = cur; try { localStorage.setItem('swafl.codeTheme', cur); } catch (e) { } box.classList.remove('dark', 'light', 'npp'); (cur === 'npp' ? ['light', 'npp'] : [cur]).forEach(c => box.classList.add(c)); q('theme').textContent = lab(cur); };
    const save = () => { orig = ta.value; check(); if (o.onSave) o.onSave(ta.value); };
    if (q('undo')) q('undo').onclick = () => { ta.value = orig; paint(); if (o.onChange) o.onChange(ta.value); };
    if (q('save')) q('save').onclick = save;
    (o.extra || []).forEach((x, i) => { q('x' + i).onclick = () => x[1](ta.value); });
    paint();
    return { get: () => ta.value, set: (t, nm) => { ta.value = orig = String(t || '').replace(/\r\n/g, '\n'); if (nm) { lang = C.lang(nm); host.querySelector('.dzc-t').firstChild.textContent = nm + ' '; q('lang').textContent = C.LANGS[lang] || lang; } ta.scrollTop = 0; paint(); }, destroy: () => { cancelAnimationFrame(raf); cancelAnimationFrame(sraf); clearTimeout(tmo); document.removeEventListener('keydown', esc0, true); },
      dirty: () => ta.value !== orig, focus: () => ta.focus(), goto: ln => { const L = ta.value.split('\n'); let p = 0; for (let i = 0; i < ln - 1 && i < L.length; i++) p += L[i].length + 1; ta.focus(); ta.setSelectionRange(p, p + (L[ln - 1] || '').length); ta.scrollTop = Math.max(0, (ln - 5) * 18); pos(); } };
  };
  root.DaisyCode = C;
})(typeof window !== 'undefined' ? window : globalThis);
